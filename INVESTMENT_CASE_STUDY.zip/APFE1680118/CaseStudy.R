##################################SPARK FUND INVESTMENT CASE STUDY######################################
setwd("D:/PGDDA/R DOWNLOAD/ASSIGNMENTS/CASESTUDY")
search()

################################  CHECK POINT 1 ########################################################

# Loading companies.txt  and rounds2.csv into R
companies <-read.delim("companies.txt",stringsAsFactors = FALSE)
rounds2 <- read.csv("rounds2.csv", stringsAsFactors = FALSE)
#Copied the Countries name given in the pdf format to a text file named  "EnglishCountries.txt". The file is 
# attached in the zip .Please put  the file in the  current working directory and import using below command
english_speaking_countries <-read.delim("EnglishCountries.txt",stringsAsFactors = FALSE) 
# Trimming any extra trailing and leading whitespace
english_speaking_countries$EnglishCountires<-trimws(english_speaking_countries$EnglishCountries)

# Using the default "countrycode"  package of R.
install.packages("countrycode")   
library(countrycode)
search()

# Analysis on Data Cleaning: On English Speaking countries:

#Checking the countries name present in country_data of R are matching with our English dataset
# After Analysis, we found that 4 countries names out of 59 are not matching like "The Bahamas" given in the pdf and
# "Bahamas" present in the countrycode's Package.So,we manually changed the name so that it matches with countrycode  dataset
Checking_Countries_names <- subset (countrycode_data ,countrycode_data$country.name %in%  english_speaking_countries$EnglishCountires)
# After matching the countires names .Taking out the standard "ISO" english countries codes
english_speaking_codes <- countrycode (Checking_Countries_names$cowc,"cowc", "iso3c")


# Analysis on Data Cleaning: On Unique companies analysis:

#Though it is given  that "permalink" describes the unique company however we found that same companies name appears more
#than once and company url is almost same hence "permalink" cannot determined a company uniquely . We have taken 
# "name" and "status" as combination to determine the  company uniquely.
 
company_unique_permalink <- unique(companies$permalink) #No of unique permalinks: 66368
company_unique_names <- unique(companies$name)  #No of unique name: 66103
#duplicated names of companies
duplicated_company_name <- companies$name[duplicated(companies$name)]
# check for any  duplicate companies name and analyse the figures like : "ZingBox" ,"Gusto"
try_duplicated_subset <- subset(companies ,name =="ZingBox")
#After analysis we found that, status and name are same for two companies in most cases, hence this combination  
# (name & status) cannot detemine uniquely instead "status and "permalink" can determine single row.
#Filtering  the companies name whose status is not closed ie they are funtional and active and obvious so because 
# why any investor would like to spend on company which is already closed.
Operational_company_dataset<- subset (companies , companies$status != "closed" )# Unique: 60130


# Analysis : Cleaning Companies data File:
# Filtering where country code is not empty & status not closed & category is not empty
closed_clean <- subset(companies ,status != "closed")
country_clean <- subset(closed_clean,country_code !="")
final_company_category_clean<- subset(country_clean,category_list != "")
# We Thought of deriving the country code from region/city  but what we found that wherever country name is missing , region/city was
# also missing, below data frame confims that 
country_missing_data <- subset (companies, country_code ==""  & state_code != "" & city != "" & region !="")#0

#Filtered by English Speaking countries : Final companies data set before merging
english_companies_FinalSet <- subset (final_company_category_clean , final_company_category_clean$country_code %in% english_speaking_codes)


#Cheking the data types of the various columns in the files
str(companies)
str(rounds2)
# Compairing the  companies file and rounds2 file for checking difference between companies , We found  zero diff
# ie , no all companies which are present in companies df are also present in rounds2 df
companies$permalink <- tolower(companies$permalink)
comapniesDifference <- setdiff(unique(rounds2$company_permalink) ,unique(companies$permalink))

#Cleaning  the data case and white spaces  of rounds2 and english_companies_FinalSet
rounds2$company_permalink<- tolower(rounds2$company_permalink)
rounds2$company_permalink <- trimws(rounds2$company_permalink)
english_companies_FinalSet$permalink <- tolower(english_companies_FinalSet$permalink)
english_companies_FinalSet$permalink <- trimws(english_companies_FinalSet$permalink)


#Merging the data of clean_company_dataset and rounds2  # 79852
master_frame <- merge (english_companies_FinalSet,rounds2, by.x="permalink" ,by.y="company_permalink")

summary(master_frame)





################################ CHECK POINT 2 ##############################

# Data cleaning of NA values and Out lier treatment :
# NA values count  
naValueCount <- length(which(is.na(master_frame$raised_amount_usd))) #11396

# Taking data set without NAs and clean permalink. As the amount cannot be predicted and as well count is less than 20%
master_without_NA <- subset (master_frame, is.na(master_frame$raised_amount_usd) == F) #68456

#plot for outliers
boxplot(master_frame$raised_amount_usd)
hist(rounds2$raised_amount_usd)

# Summary before NA populating values
summary(master_frame)

#Calculating the median and substituting 

master_frame$raised_amount_usd[which(is.na(master_frame$raised_amount_usd))]  <- median(master_without_NA$raised_amount_usd)

#REASON AND ANALYSIS FOR SELECTING MEDIAN FOR REPLACING NA VALUES :
# BELOW IS THE ANALYSIS :
#1.After replacing with median we found that individual funding type  Mean is 
# not getting changed much as compare to replacing with mean value :Observer column "With MEDIAN"  and "Excluding NA"
#2. We also found that there are lots of outliers for each funding type so as per central tendency stastitical
# rule we can replace with median , also we have to present  one single answer so we have replaced with full NON NA 
# data median instead of per funding type median.
#3. Also when we plot the histogram we can clearly seea skew plot suggesting to take medain over mean.
  
# Row Labels	      With Mean	  With MEDIAN	   With Mode	    Exluding NA	  with 0	       with category Average (same as excluding NA)
# angel	            $2,709,426	$1,081,033	   $890,780	      $875,690	    $700,526	     $875,690
# convertible_note  $3,368,979	$1,611,486	   $1,406,149	    $1,484,864	  $1,200,811	   $1,484,864
# debt_financing	  $16,477,434	$16,225,905	   $16,196,517	  $11,217,823	  $16,167,130	   $11,217,823
# equity_crowdfund	$6,856,630	$1,451,702	   $820,216	      $506,169	    $188,729	     $506,169
# grant	            $5,432,469	$5,158,579	   $5,126,579	    $5,016,422	  $5,094,579	   $5,016,422
# non_equity_assist $7,175,031  $1,548,247	   $890,839	      $719,750	    $233,432	     $719,750
# post_ipo_debt	    $134,919,437$134,919,437   $134,919,437	  $103,561,437	$134,919,437	 $103,561,437
# post_ipo_equity	  $63,318,779	$63,229,622	   $63,219,205	  $65,357,403	  $63,208,789	   $65,357,403
# private_equity	  $58,380,155	$57,499,550	   $57,396,664	  $60,746,437	  $57,293,778	   $60,746,437
# product_crowdfund.$2,058,573	$1,577,727	   $1,521,547	    $1,727,621	  $1,465,368	   $1,727,621
# secondary_market	$37,543,876	$31,645,069	   $30,955,880	  $72,741,317	  $30,266,691	   $72,741,317
# seed	            $2,806,823	$1,072,735	   $870,132	      $841,429	    $667,529	     $841,429
# undisclosed	      $11,781,147	$6,135,009	   $5,475,341	    $14,761,406	  $4,815,672	   $14,761,406
# venture	          $11,607,157	$11,068,645	   $11,005,728	  $11,832,678	  $10,942,811	   $11,832,678

#Final Sumary
summary(master_frame$raised_amount_usd)  # Central mean did not change much

# OVERALL IMPACT 

# ORIGINAL SUMMARY 
# Min.      1st Qu.    Median      Mean      3rd Qu.      Max.          NA's 
# 0.000e+00 4.684e+05  2.000e+06   1.056e+07 7.861e+06    2.127e+10     11396 

# After replacing  with mean  Summary
# 
# Min.      1st Qu.    Median      Mean      3rd Qu.      Max. 
# 0.000e+00 5.850e+05  3.000e+06   1.056e+07 1.056e+07    2.127e+10 
# 
# After replacing median Summary
# 
# Min.      1st Qu.    Median      Mean      3rd Qu.      Max. 
# 0.000e+00 5.850e+05  2.000e+06   9.338e+06 6.000e+06    2.127e+10 


##################### CHECK POINT 3: INVESTMENT ANALYSIS ########################


# Average Funding Venture Type  :: 11068645
venture_type <- subset(master_frame, funding_round_type =="venture")
ventureFundingTypeMean <- mean(venturetype$raised_amount_usd)
#Average Funding angel type ::  1081033
angel_type <- subset(master_frame, funding_round_type =="angel")
angelFundingTypeMean <- mean(angel_type$raised_amount_usd)

#Average Funding seed type::1072735
seed_type <- subset(master_frame, funding_round_type =="seed")
seedFundingTypeMean <- mean(seed_type$raised_amount_usd)

#Average Funding Private equity type :: 57499550
private_equity_type <- subset(master_frame, funding_round_type =="private_equity")
privateEquityFundingTypeMean <- mean(private_equity_type$raised_amount_usd)

# Conclusion; Venture Type analysis significant for spark funds as the value 11068645 falls between 
# their investment range
# From here onwards : "FT"  is "Venture"



##################### CHECK POINT 4: COUNTRY ANALYSIS ########################

VenturFundingGrouping <- aggregate(raised_amount_usd~country_code,venturetype,sum)
sortedFunding <- VenturFundingGrouping[order(VenturFundingGrouping$raised_amount_usd,decreasing = T),]
top9 <- sortedFunding[1:9,]

# Top countries for Venture Funnding are :  1. USA, 2.GBR, 3. IND


##################### CHECK POINT 5: SECTOR ANALYSIS -1  ########################

#Loaading mapping file
mapping <- read.csv("mapping_file.csv", stringsAsFactors = FALSE)
#Removing the unnecessary blank values
clean_mapping <- subset (mapping , category_list != "" & main_sector!= "")
#Checking duplication in mapping file
clean_mapping$category_list[!duplicated(clean_mapping$category_list)] # same length of clean_mapping,hence no duplication

# Function to return first primary sector from category list of  master_frame
primarySectorDist<- function(element){
  
  primary_sector<- unlist (strsplit(element,split = "|" ,fixed = TRUE))[1]
  return(primary_sector)
  
}

# Primary Sector list 
PrimarySectorDataList <- lapply (master_frame$category_list ,primarySectorDist)
#Removing the unnecessary leading and trailing spaces
trimws(PrimarySectorDataList)
# Making a copy of master frame so that further action does not impact the  original master data frame
master_frame_2 <- master_frame
#Add the Primary Sector column to the master frame copy
master_frame_2 <- data.frame(master_frame_2,primary_Sector =c(as.character(PrimarySectorDataList)))
#Merging the master frame copy and clean mappig file to map the primary sector to the Main sector of mapping file and 
# do the LEFT JOIN in order to retain all the master details including whose  primary sector mathcing with mapping file 
# ans also keeping those which are not matching. Certainly those unmatch primary sector , the main sector will appear as 'NA'
Final_merged_frame_4 <- merge (master_frame_2,clean_mapping,by.x="primary_Sector" ,by.y = "category_list", all.x = TRUE)


# Check for NA  values for  main sector
rowsna <- which(is.na(Final_merged_frame_4$main_sector)==TRUE)
nrow(Final_merged_frame_4[rowsna,]) # 51 NA values
# Replace the "NA"  with "Others"
Final_merged_frame_4$main_sector[which(is.na(Final_merged_frame_4$main_sector))]  <- "Others"



##################### CHECK POINT 6: SECTOR ANALYSIS -2  ########################



# D3  for IND investement

India_VentureFunding_Set  <- subset (Final_merged_frame_4 , country_code == "IND" & funding_round_type =="venture" & raised_amount_usd >= 5000000 & raised_amount_usd <= 15000000)


# Number of Investmets in India based on sectors
India_Round_Fund_Count <- aggregate(funding_round_permalink~main_sector ,India_VentureFunding_Set,FUN = length)
India_Round_Fund_Total <- aggregate(raised_amount_usd~main_sector,India_VentureFunding_Set ,FUN = sum)
TopSectorSet_IND <- subset(India_VentureFunding_Set,main_sector=="Social, Finance, Analytics, Advertising")
group_companies_IND <- aggregate(raised_amount_usd~name,TopSectorSet_IND,FUN=sum )
MergeInd <- merge (India_Round_Fund_Total,India_Round_Fund_Count,by.x="main_sector" ,by.y = "main_sector")
names(MergeInd)[2] <- "Total_Amount_Per_Main_Sector"
names(MergeInd)[3] <- "Count_Investment_Main_Sector"
sortedFundingCompany <- topCompany[order(topCompany$raised_amount_usd,decreasing = T),]
top3 <- sortedFundingCompany[1:3,]
D3 <- merge (India_VentureFunding_Set , MergeInd , by = "main_sector" ,all = FALSE) 


# D2   for GBR Investment
GBR_VentureFunding_Set  <- subset (Final_merged_frame_4 , country_code == "GBR" & funding_round_type =="venture" & raised_amount_usd >= 5000000 & raised_amount_usd <= 15000000)
GBR_Round_Fund_Count <- aggregate(funding_round_permalink~main_sector ,GBR_VentureFunding_Set,FUN = length)
GBR_Round_Fund_Total <- aggregate(raised_amount_usd~main_sector,GBR_VentureFunding_Set ,FUN = sum)

TopSectorSet_GBR <- subset(GBR_VentureFunding_Set,main_sector=="Social, Finance, Analytics, Advertising")
group_companies_GBR <- aggregate(raised_amount_usd~name,TopSectorSet_GBR,FUN=sum )

MergeGBR <- merge (GBR_Round_Fund_Total,GBR_Round_Fund_Count,by.x="main_sector" ,by.y = "main_sector")

names(MergeGBR)[2] <- "Total_Amount_Per_Main_Sector"
names(MergeGBR)[3] <- "Count_Investment_Main_Sector"
D2 <- merge (GBR_VentureFunding_Set , MergeGBR , by = "main_sector" ,all = FALSE) 


topCompanyBritain <-subset( GBR_VentureFunding_Set,main_sector =="Others")
sortedFundingCompany <- topCompany[order(topCompany$raised_amount_usd,decreasing = T),]
top3 <- sortedFundingCompany[1:3,]

# D1 for USA

USA_VentureFunding_Set  <- subset (Final_merged_frame_4 , country_code == "USA" & funding_round_type =="venture" & raised_amount_usd >= 5000000 & raised_amount_usd <= 15000000)
USA_Round_Fund_Count <- aggregate(funding_round_permalink~main_sector ,USA_VentureFunding_Set,FUN = length)

USA_VentureFunding_Set_chk  <- subset (Final_merged_frame_4 , country_code == "USA" & funding_round_type =="venture" )
USA_Round_Fund_Count_chk <- aggregate(funding_round_permalink~main_sector ,USA_VentureFunding_Set_chk,FUN = length)


USA_Round_Fund_Total <- aggregate(raised_amount_usd~main_sector,USA_VentureFunding_Set ,FUN = sum)

MergeUSA <- merge (USA_Round_Fund_Total,USA_Round_Fund_Count,by.x="main_sector" ,by.y = "main_sector")

names(MergeUSA)[2] <- "Total_Amount_Per_Main_Sector"
names(MergeUSA)[3] <- "Count_Investment_Main_Sector"
D1 <- merge (USA_VentureFunding_Set , MergeUSA , by = "main_sector" ,all = FALSE) 

TopSectorSet_USA <- subset(USA_VentureFunding_Set,main_sector=="Social, Finance, Analytics, Advertising")
group_companies_USA<- aggregate(raised_amount_usd~name,TopSectorSet_USA ,FUN=sum )
topCompanyUSA <-subset( USA_VentureFunding_Set,main_sector =="Others")


########################### CHECKPOINT 7  :GGlplots######################

# Libraries used for plotting

library(ggplot2)
library(ggthemes) 
library(scales)
library(plyr)


#Plot 1: Pie chart 

# Preparing data for the  plot 
#combining the  venture /seed / privateEquity data set
fund_type_frame <- rbind(venture_type,seed_type,private_equity_type)
# Using ddply funtion to calculate mean based on funding type and also return number of investments 
# String the data into variable fund_1
fund_1 <- ddply(fund_type_frame,.(funding_round_type),summarise,mean_usd =mean(raised_amount_usd),count_1 =length(funding_round_type))
# Formatting the value of raised amount usd to 1 point decimal accuracy , this will help in showing Mean value appropriately
fund_1 <- within(fund_1,{
          funding_round_type=factor(funding_round_type) 
          mean_usd = sprintf('%0.1f',mean_usd)
          })

# Defining the funtion for clean pie chart plot without any unwanted labels and axis text
blank_theme <- theme_minimal()+
  theme(
    axis.title.x = element_blank(),
    axis.title.y = element_blank(),
    panel.border = element_blank(),
    panel.grid=element_blank(),
    axis.ticks = element_blank(),
    plot.title=element_text(size=14, face="bold")
  )

 plot1 <- ggplot(fund_1,aes(x="",y=count_1))
 plot1 + geom_bar(aes(fill=funding_round_type),stat="identity",position="stack",width=1)+ geom_label(aes(label=mean_usd),vjust =-0.5) +coord_polar(theta="y",start=0)+blank_theme + theme(axis.text.x=element_blank()) +scale_fill_discrete(guide = guide_legend(title = "Funding Type")) 


# Useful Commands
help()

#Plot 2
# Preparing data 
VenturFunding <- aggregate(raised_amount_usd~country_code,venture_type,sum)
plot2 <- ggplot(VenturFunding,aes(x=as.factor(country_code),y=raised_amount_usd)) 
plot2 + geom_bar(width = 1,stat="identity",aes(col=ifelse(raised_amount_usd>10000000000, 'red','green')),fill="white") +scale_color_identity()+ labs(x="COUNTRY CODES",y="TOTAL AMOUNT OF INVESTMENTS") +scale_y_continuous(labels =comma)

# Plot3 
# Preparing data for plot 3 
# Top countries data from merged data frame in sector analysis
# USA Top  3 sectors
USA_countries_subset <- subset (Final_merged_frame_4,country_code =="USA" & funding_round_type =="venture")
SectorUSAFunding <- aggregate(raised_amount_usd~main_sector+country_code,USA_countries_subset,length)
sortedUSAFunding <- SectorUSAFunding[order(SectorUSAFunding$raised_amount_usd,decreasing = T),]
USA_3<- sortedUSAFunding [1:3,]
# GBR Top 3 Sectors
GBR_countries_subset <- subset (Final_merged_frame_4,country_code =="GBR" & funding_round_type =="venture")
SectorGBRFunding <- aggregate(raised_amount_usd~main_sector+country_code,GBR_countries_subset,length)
sortedGBRFunding <- SectorGBRFunding[order(SectorGBRFunding$raised_amount_usd,decreasing = T),]
GBR_3<- sortedGBRFunding [1:3,]
# GBR Top 3 Sectors
IND_countries_subset <- subset (Final_merged_frame_4,country_code =="IND"& funding_round_type =="venture")
SectorINDFunding <- aggregate(raised_amount_usd~main_sector+country_code,IND_countries_subset,length)
sortedINDFunding <- SectorINDFunding[order(SectorINDFunding$raised_amount_usd,decreasing = T),]
IND_3<- sortedINDFunding [1:3,]




# Combining all top sectors country  data
Top_country_data <- rbind(USA_3,GBR_3,IND_3)


# Plotting the ggplot
plot3 <- ggplot(Top_country_data,aes(x=factor(main_sector),y=raised_amount_usd)) 
plot3 + geom_bar(aes(fill =main_sector),stat="identity")+ facet_wrap(~ country_code) + geom_label(aes(label=raised_amount_usd))+theme(text = element_text(size=14),axis.text.x = element_text(angle=90, vjust=1)) +labs(x="MAIN SECTORS" , y="NUMBER OF INVESTMENTS")+  scale_fill_discrete(guide = guide_legend(title = " Top Main Sectors"))
    
######################## CASE STUDY ENDS #######################################

# Remove all the variables from R Session
rm(list=ls())
