
#################### NEURAL NETWORK ASSIGNMENT ###############


## Cleaning up existing variables 
rm(list=ls())

######### SETTING WORKING DIRECTORY ######################

setwd("D:/PGDDA/R DOWNLOAD/ASSIGNMENTS/NEURAL NETWORK ASSIGN")





##########  Data undertanding and Data preperation

## Loading the csv file
telecomDataSet <- read.csv("telecom_nn_train.csv")

## Structure of Telecom data set
str(telecomDataSet)


## Performing the  missing and outlier treatment

sum(is.na(telecomDataSet))  ## Total 6

sum(is.na(telecomDataSet$TotalCharges)) ## The Total charges column has 6 NA's

## Perform the outlier treatment 

boxplot.stats(telecomDataSet$TotalCharges) ## No Outlier present

boxplot.stats(telecomDataSet$MonthlyCharges) ## No Outlier present

boxplot.stats(telecomDataSet$tenure) ## No Outlier present

## Imputing the mean in mising values
telecomDataSet_Without_NA <- subset (telecomDataSet, is.na(telecomDataSet$TotalCharges) == F) 
telecomDataSet$TotalCharges[which(is.na(telecomDataSet$TotalCharges))]  <- mean(telecomDataSet_Without_NA$TotalCharges)



## Making Churn as factor of 0/1 type

levels(telecomDataSet$Churn)[1] <- 0 
levels(telecomDataSet$Churn)[2] <- 1 
levels(telecomDataSet$Churn)
## Creating training and test data 

## Here we are not creating the validation data set , as we are going to use
# nfold cross validation in h2o.deeplearning  call, it is always  better to
# use a multiple  dynamic cross test  for  better results instead of performing on 
# a static validation data set
set.seed(100)
library

## Splitting in to 70:30 ration of training and test data set
train.indices <- sample.split(telecomDataSet$Churn,SplitRatio = 0.70)

train_telecom <- telecomDataSet[train.indices == TRUE,]

test_telecom <- telecomDataSet[-train.indices == FALSE,]


# Shifting the Churn column as first in the data sets so that it will easy to 
# use the h2o.deeplearning call
trainsample <- train_telecom[,c(10,1:9,11:31)]
test_telecom <- test_telecom[,c(10,1:9,11:31)]
### Writng back the file for deep learning package import

write.csv(trainsample, file='Telecom_trainsample.csv', row.names=FALSE)

write.csv(test_telecom, file='Telecom_test.csv', row.names=FALSE)


# Initialize the h2o environment



library(h2o)
h2o.init()

set.seed(100)

churnLabel <- "Churn"
churnTrain <- h2o.importFile("Telecom_trainsample.csv")
churnTrain[,churnLabel]<-as.factor(churnTrain[,churnLabel])
churnTest <- h2o.importFile("Telecom_test.csv")
churnTest[,churnLabel]<-as.factor(churnTest[,churnLabel])
# Perform 50-fold cross-validation on the training_frame

## Selecting the single layer and number of neuron as 3 times the number of 
#  features  as per standard , will try to modify the hyperparameters if
# reults dos not comes out  good .

# NOTE : We have taken of nfold cross validation to 50, so as to model can able to 
#        generate the consistent metrices with  less variation, large number can also be taken but it will risk the
# performance of the algo and end up in memorizing the whole data , for 3400 records 50 is optimum

######### Checkpoint 1 - Model building without epoch ############
churn_1 <- h2o.deeplearning(x = 2:31,
                             y = 1,
                             training_frame = churnTrain,
                             distribution = "multinomial",
                             activation = "RectifierWithDropout",
                             hidden = c(100),standardize = TRUE,
                             hidden_dropout_ratio = c(0.1),
                             l1 = 1e-5,nfolds = 50
                             )

## Got below results on cross validation data (average of 50 folds)
#Accuracy: 0.76 
#sensitivity :0.81 on cross validate data  
# Specificity: 0.73
# Since as per business, number of customers churning is important hence
# sensitivity is quite a good measure to look for .

## Will try another model by increasing the complexity of the model by increasing the 
# number of layers ,this time keeping 25 in each layer and 4 layers ,
# while keeping the same drop out ratio and "multinomial" distribution 

churn_2 <- h2o.deeplearning(x = 2:31,
                          y = 1,
                          training_frame = churnTrain,
                          distribution = "multinomial",
                          activation = "RectifierWithDropout",
                          hidden = c(25,25,25,25),standardize = TRUE,
                          hidden_dropout_ratio = c(0.1,0.1,0.1,0.1),
                          l1 = 1e-5,nfolds = 50
)

## Results on the  cross validation data (average of 50 folds)

#Accuracy: 0.79 
#sensitivity :0.82 
# Specificity: 0.75

## We saw the figues accuracy and sensitivity improved  a bit increasing the 
# the number layers


##Let's check if further increasing   the layers increase the accuracy further on validation
# data set

churn_3 <- h2o.deeplearning(x = 2:31,
                            y = 1,
                            training_frame = churnTrain,
                            distribution = "multinomial",
                            activation = "RectifierWithDropout",
                            hidden = c(15,15,15,15,15,15),standardize = TRUE,
                            hidden_dropout_ratio = c(0.1,0.1,0.1,0.1,0.1,0.1),
                            l1 = 1e-5,nfolds = 50
)
## Results on cross validation set (average of 50 folds)
#Accuracy: 0.77 
#sensitivity :0.74 
# Specificity: 0.76



## From the above behaviour it look like the  instead of increasing the 
## accuracy , it  starts decreasing as we keep on increasing the layer

## From above reusults , model 'churn_2' gives an optimal result with
# decent  performance




############ Check point 2 - Model with epochs ##########


## We will take the above model and check with the value of the 
## epochs


## Seting epochs =10
churn_1_epoch <- h2o.deeplearning(x = 2:31,
                            y = 1,
                            training_frame = churnTrain,
                            distribution = "multinomial",
                            activation = "RectifierWithDropout",
                            hidden = c(25,25,25,25),standardize = TRUE,
                            hidden_dropout_ratio = c(0.1,0.1,0.1,0.1),
                            l1 = 1e-5,nfolds = 50 ,epochs = 10
)

## Results on cross validation set (average of 50 folds)
#Accuracy: 0.77 
#sensitivity :0.71 
# Specificity: 0.74

## The sensitivity reduced significantly let's try with another number

# epochs = 20

churn_2_epoch <- h2o.deeplearning(x = 2:31,
                            y = 1,
                            training_frame = churnTrain,
                            distribution = "multinomial",
                            activation = "RectifierWithDropout",
                            hidden = c(25,25,25,25),standardize = TRUE,
                            hidden_dropout_ratio = c(0.1,0.1,0.1,0.1),
                            l1 = 1e-5,nfolds = 50 ,epochs = 20
)

## Results on cross validation set (average of 50 folds)
#Accuracy: 0.77 
#sensitivity :0.71 
# Specificity: 0.78

## It appears that the accuracy and sensitivity does not increase , will try another 
# Model by reducing the  layers
# epochs = 10

churn_3_epoch <- h2o.deeplearning(x = 2:31,
                            y = 1,
                            training_frame = churnTrain,
                            distribution = "multinomial",
                            activation = "RectifierWithDropout",
                            hidden = c(100),standardize = TRUE,
                            hidden_dropout_ratio = c(0.1),
                            l1 = 1e-5,nfolds = 50 ,epochs = 10
)
## Results on cross validation set (average of 50 folds)
#Accuracy: 0.75
#sensitivity :0.81 
# Specificity: 0.74

## With the decent value figures ,lets try if increasing the epoch value
# increase accuracy

churn_4_epoch <- h2o.deeplearning(x = 2:31,
                            y = 1,
                            training_frame = churnTrain,
                            distribution = "multinomial",
                            activation = "RectifierWithDropout",
                            hidden = c(100),standardize = TRUE,
                            hidden_dropout_ratio = c(0.1),
                            l1 = 1e-5,nfolds = 50 ,epochs = 20
)
## Results on cross validation set (average of 50 folds)
#Accuracy: 0.77
#sensitivity :0.73 
#Specificity: 0.79

# Since the sensitivity decreased , we will take the less epochs value of 10 .
# and consider the model with low epoch 


############### Checkpoint 3 - Best model selection #################

# We got two model in the above two checkpoints : ie
# churn_2 and churn_3_epoch


# Let's try to test the model on the test data set
# Library for confusion matrix
library(caret)
# Model churn_2 
chunTest_Without_Churn <- churnTest[,-1]
churn_prediction_1 <-  h2o.predict(churn_2,chunTest_Without_Churn)
churn_prediction_df_1 <- as.data.frame(churn_prediction_1)
churnTest_df <-as.data.frame(churnTest)
confusionMatrix(churn_prediction_df_1[,1],churnTest_df[,1],positive = "1")

## Results obtained of churn_2 on test dataset:
#Sensitivity : 0.7448          
#Specificity : 0.7680 
#Balanced Accuracy : 0.7564  

# Model churn_3_epoch

churn_prediction_epoch <-  h2o.predict(churn_3_epoch,chunTest_Without_Churn)
churn_prediction_df_epoch <- as.data.frame(churn_prediction_epoch)
confusionMatrix(churn_prediction_df_epoch[,1],churnTest_df[,1],positive = "1")

## Results obtained of churn_3_epoch on test dataset::
#Sensitivity : 0.7708          
#Specificity : 0.7598 
#Balanced Accuracy : 0.7653 


## It' clear that the results are quite good for both model
## churn_2 and churn_3_epoch .
# We will select the  churn_3_epoch over churn_2  because of it simplistic
# topology of 1 layer and fair number of neurons which will make our 
# generic choice , the regularization in terms of drop out ratio and  batch size (epoch)
# is simplistic .It  likely to perfrom well  on the test data . One glimse we already seen
# in the above case with test data.


## Final Model

churn <- churn_3_epoch

## Performance matrix of the best churn model

h2o.performance(churn,churnTrain)


#MSE:  0.1206665
#RMSE:  0.3473709
#LogLoss:  0.376207
#Mean Per-Class Error:  0.1956044
#AUC:  0.8803099
#Gini:  0.7606198

#Confusion Matrix for F1-optimal threshold:
#         0    1    Error       Rate
#    0  2033  523   0.204617  =523/2556
#    1  167   728   0.186592   =167/895
#Totals 2200  1251  0.199942  =690/3451

# Maximum Metrics: Maximum metrics at their respective thresholds
#                         metric threshold    value idx
#1                       max f1  0.230984 0.678472 255
#2                       max f2  0.124497 0.779468 308
#3                 max f0point5  0.432296 0.672103 171
#4                 max accuracy  0.432296 0.827586 171
#5                max precision  0.911729 1.000000   0
#6                   max recall  0.001117 1.000000 397
#7              max specificity  0.911729 1.000000   0
#8             max absolute_mcc  0.304717 0.556329 221
#9   max min_per_class_accuracy  0.242337 0.800861 249
#10 max mean_per_class_accuracy  0.215820 0.807716 263


h2o.shutdown()


#############################  NEURAL ASSIGNMENT ENDS ######################