rm(list=ls())

########################################################
## CHECKPOINT 1: Data Cleaning and preparation ##
########################################################    

# Load the file loan.csv into data frame loan.
loan<-read.csv("loan.csv", stringsAsFactors = F)

summary(loan)

# Impute the NA values for all driver variables.

# Checking for invalid rows
which(loan$loan_status == "")

# Remove entries with loan_status as empty string
loan<-subset(loan, loan$loan_status != "")

summary(loan$annual_inc)         # 4 NA
summary(loan$loan_amnt)          # No NA
summary(loan$funded_amnt)        # No NA

# Remove % from int_rate
loan$int_rate<-gsub("%", "", loan$int_rate)
loan$int_rate<-as.integer(loan$int_rate)
summary(loan$int_rate)           # No NA

which(is.na(loan$grade))         # No NA
summary(loan$dti)                # No NA

# Remove non digit from emp_length
loan$emp_length<-gsub("[^0-9]", "", loan$emp_length)
loan$emp_length<-as.integer(loan$emp_length)
summary(loan$emp_length)         # 1112 NA

# Treatment of NAs in emp_length is done later while treating the data. Check line #87.

which(is.na(loan$purpose))            # No NA
which(is.na(loan$home_ownership))     # No NA
which(is.na(loan$loan_status))        # No NA

# NA TREATMENT
# Remove NA entries for annual_inc as they are negligiable (only 4)
loan<-subset(loan, !is.na(loan$annual_inc))

# Remove rows with loan_status  = "Fully Paid"
loan<-subset(loan, loan$loan_status != "Fully Paid")


# Create a new column named loan_status_1  with three levels current_new, default_new and late such that
# rows with loan_status as "current" or "in grace period" are tagged as  "current_new"
# rows with loan_status as " default" or "charged off" are tagged as "default_new"
# rows with loan_status as " late 16- 30 days" "late 31-120 days" are tagged as "late"
loan<-cbind(loan, data.frame(loan_status_1=""))
class(loan$loan_status_1)
levels(loan$loan_status_1)<-c("current_new", "default_new", "late")

unique(loan$loan_status)

# Remove loan entries with loan_status "Does not meet the credit policy. Status:Fully Paid" and 
# "Does not meet the credit policy. Status:Charged Off"
loan<-subset(loan, loan$loan_status!="Does not meet the credit policy. Status:Fully Paid")
loan<-subset(loan, loan$loan_status!="Does not meet the credit policy. Status:Charged Off")


# rows with loan_status as "current" or "in grace period" are tagged as  "current_new"
loan$loan_status_1[(which(loan$loan_status == "Current" | loan$loan_status == "In Grace Period"))]<- "current_new"

# rows with loan_status as " default" or "charged off" are tagged as "default_new"
loan$loan_status_1[which(loan$loan_status == "Default" | loan$loan_status == "Charged Off")]<-"default_new"

# rows with loan_status as " late 16- 30 days" "late 31-120 days" are tagged as "late"
loan$loan_status_1[which(loan$loan_status == "Late (31-120 days)" | loan$loan_status == "Late (16-30 days)")]<-"late"



# Create new bin variables for int_rate and emp_length respectively as follows:

# Create int_rate_grp such that int_rate < 10 is tagged "Low"; int_rate (10-18) is tagged 
# "Medium"; int_rate (>18) is tagged "High"
loan$int_rate_grp<-cut(as.double(loan$int_rate), c(0, 9, 18, Inf), labels = c("Low","Medium", "High"))

# Check NAs again in emp_length
summary(loan$emp_length)

# Treatment of NA in emp_length. We have 3.99% NAs. We can safely remove those.

# summary(loan$emp_length)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max.    NA's 
# 1.000   2.000   5.000   5.363  10.000  10.000     273 
loan<-subset(loan, !is.na(loan$emp_length))

# Create emp_len_grp such that emp_length (0-4) is tagged as "Junior"; emp_length (5-8) is
# tagged as "Mid-level"; emp_length (>8) is tagged as "Senior".
loan$emp_len_grp<-cut(loan$emp_length, c(0, 4, 8, Inf), labels = c("Junior", "Mid-level", "Senior"))


########################################################
## CHECKPOINT 2: Exploratory Data Analysis ##
########################################################    


############################
 ## Univariate Analysis ##
############################

# Univariate Analysis : This analysis will show the distribution of driver variables.
# This analysis shall include the following for all driver variables:   
#  Summary Statistics
#  Distribution plot
#  Outlier treatment

# annual_inc Annual Income of applicant
  #  Summary Statistics
  summary(loan$annual_inc)

  #  Distribution plot
  boxplot(loan$annual_inc, boxwex=0.2)

  #  Outlier treatment
  outlier<-boxplot.stats(loan$annual_inc)
  outlier

  loan<-subset(loan, (unlist(outlier[1])[1]<= loan$annual_inc) & (loan$annual_inc <= unlist(outlier[1])[5]))

# loan_amnt The listed amount of the loan applied for by the borrower
  #  Summary Statistics
  summary(loan$loan_amnt)

  #  Distribution plot
  boxplot(loan$loan_amnt, boxwex=0.2)

  #  Outlier treatment
  outlier<-boxplot.stats(loan$loan_amnt)
  outlier

  # out in boxplot.stat() output is not showing any outlier.
  # So, no need for outlier treatment.

          
# funded_amnt The total amount committed to that loan at that point in time
  # Summary Statistics
  summary(loan$funded_amnt)
  
  #  Distribution plot
  boxplot(loan$funded_amnt, boxwex=0.2)
  
  #  Outlier treatment
  outlier<-boxplot.stats(loan$funded_amnt)
  outlier
  
  loan<-subset(loan, (unlist(outlier[1])[1]<= loan$funded_amnt) & (loan$funded_amnt <= unlist(outlier[1])[5]))
  
            
# int_rate_grp is instead of int_rate_grp as directed in checkpoint 1.
# Interest Rate on the loan
  # Summary Statistics
  summary(loan$int_rate_grp)
  
  #  Distribution plot
  ggplot(loan, aes(x=int_rate_grp)) + geom_bar()
  
  #  Outlier treatment
  # Based on above analysis, no outlier treatment required here.
  
            
# grade LC assigned loan grade
  # Summary Statistics
  summary(loan$grade)
  unique(loan$grade)
  
  #  Distribution plot
  ggplot(loan, aes(x=as.factor(grade))) + geom_bar()

  #  Outlier treatment
  # Based on above analysis, no outlier treatment required here.

# dti	Debt to income ratio
  # Summary Statistics
  summary(loan$dti)
  
  #  Distribution plot
  boxplot(loan$dti, boxwex=0.2)
  
  #  Outlier treatment
  outlier<-boxplot.stats(loan$dti)
  outlier
  
  # out in boxplot.stat() output is not showing any outlier.
  # So, no need for outlier treatment.
  

# emp_len_grp is used instead of emp_length as directed in checkpoint 1.
# Employment length in years
  # Summary Statistics
  summary(loan$emp_len_grp)
  
  #  Distribution plot
  ggplot(loan, aes(x=emp_len_grp)) + geom_bar()
  
  #  Outlier treatment
  # Based on above analysis, no outlier treatment required here.
  

# Purpose	A category provided by the borrower for the loan request. 
  # Summary Statistics
  summary(loan$purpose)
  unique(loan$purpose)
  
  #  Distribution plot
  ggplot(loan, aes(x=as.factor(purpose))) + geom_bar()
  
  #  Outlier treatment
  # Based on above analysis, no outlier treatment required here.
  

# home_ownership	The home ownership status provided by the borrower during registration
  # Summary Statistics
  summary(loan$home_ownership)
  unique(loan$home_ownership)
  
  #  Distribution plot
  ggplot(loan, aes(x=as.factor(home_ownership))) + geom_bar()
  
  #  Outlier treatment
  # Based on above analysis, no outlier treatment required here.
  

# loan_status_1 is considered instead of loan_status. As we created this 
# field in checkpoint 1.
  # Summary Statistics
  summary(loan$loan_status_1)

  #  Distribution plot
  ggplot(loan, aes(x=loan_status_1)) + geom_bar()
  
  #  Outlier treatment
  # Based on above analysis, no outlier treatment required here.
  

################################
  ## Multivariate Analysis ##
###############################
  
# List of continuous variables:
# annual_inc
# loan_amnt
# funded_amnt
# dti
  
# We haven't taken emp_length and int_rate in analysis as we created
# emp_len_grp & int_rate_grp as categorical variable. And we have to use new variables
# as directed in checkpoint 1.

# Get all the continuous variable in separate data frame
loan_continuous<-data.frame("annual_inc" = loan$annual_inc, "loan_amnt"=loan$loan_amnt, "funded_amnt"=loan$funded_amnt, "dti"=loan$dti)

# Finding correlations for all different pairs of continuous
# variables for e.g. dti v/s annual_inc. 
cor(loan_continuous)

# Distribution of all the driver variables across different levels of two 
# categorical variables:

# 1. loan_status_1: Make plots to show how the continuous variables vary across
#    the three levels of loan_status_1; for e.g. how annual_inc is distributed across
#    the levels default_new, late and current_new.

# Plot for continuous variable: annual_inc
ggplot(loan, aes(x=annual_inc, col=loan_status_1)) + geom_point(stat = "count")

# Plot for continuous variable: loan_amnt
ggplot(loan, aes(x=loan_amnt, col=loan_status_1)) + geom_point(stat = "count")

# Plot for continuous variable: funded_amnt
ggplot(loan, aes(x=funded_amnt, col=loan_status_1)) + geom_point(stat = "count")

# Plot for continuous variable: dti
ggplot(loan, aes(x=dti, col=loan_status_1)) + geom_point(stat = "count")


#
# 2. int_rate_grp: Make plots to show how the continuous variables vary across the three
#    levels of int_rate_grp; for e.g. how annual_inc is distributed across the levels Low,
#    Medium and High

# Plot for continuous variable: annual_inc
ggplot(loan, aes(x=annual_inc, col=int_rate_grp)) + geom_point(stat = "count")

# Plot for continuous variable: loan_amnt
ggplot(loan, aes(x=loan_amnt, col=int_rate_grp)) + geom_point(stat = "count")

# Plot for continuous variable: funded_amnt
ggplot(loan, aes(x=funded_amnt, col=int_rate_grp)) + geom_point(stat = "count")

# Plot for continuous variable: dti
ggplot(loan, aes(x=dti, col=int_rate_grp)) + geom_point(stat = "count")



#######################################################
  ## CHECKPOINT 3:Hypothesis Testing ##
#######################################################

# List of continuous variables:
# annual_inc
# loan_amnt
# funded_amnt
# dti

# We haven't taken emp_length and int_rate in analysis as we created
# emp_len_grp & int_rate_grp as categorical variable. And we have to use new variables
# as directed in checkpoint 1.

# PLEASE CHECK Hypotheses Insight DOCUMENT FOR HYPOTHESES DETAIL ANALYSIS

# Test hypotheses (95 % conf. level) for two levels of loan_status_1 - default_new and current_new

# Create two data frame one for default_new and one for current_new
loan_default_new<-subset(loan, loan$loan_status_1 == "default_new")

loan_current_new<-subset(loan, loan$loan_status_1 == "current_new")

# t test for continuous variable: annual_inc
t.test(loan_default_new$annual_inc, loan_current_new$annual_inc, conf.level = 0.95)

# t test for continuous variable: loan_amnt
t.test(loan_default_new$loan_amnt, loan_current_new$loan_amnt, conf.level = 0.95)

# t test for continuous variable: funded_amnt
t.test(loan_default_new$funded_amnt, loan_current_new$funded_amnt, conf.level = 0.95)

# t test for continuous variable: dti
t.test(loan_default_new$dti, loan_current_new$dti, conf.level = 0.95)


# Test hypotheses (95 % conf. level) for two levels of int_rate_grp - high and low
# Create two data frame one for default_new and one for current_new
loan_intRate_high<-subset(loan, loan$int_rate_grp == "High")

loan_intRate_low<-subset(loan, loan$int_rate_grp == "Low")

# t test for continuous variable: annual_inc
t.test(loan_intRate_high$annual_inc, loan_intRate_low$annual_inc, conf.level = 0.95)

# t test for continuous variable: loan_amnt
t.test(loan_intRate_high$loan_amnt, loan_intRate_low$loan_amnt, conf.level = 0.95)

# t test for continuous variable: funded_amnt
t.test(loan_intRate_high$funded_amnt, loan_intRate_low$funded_amnt, conf.level = 0.95)

# t test for continuous variable: dti
t.test(loan_intRate_high$dti, loan_intRate_low$dti, conf.level = 0.95)


# Write the loan dataset to external file for analysis in Tableau
write.csv(loan, file="loan_final.csv", row.names = F)
