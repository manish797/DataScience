# Set Working Directory


# Install and Load the required packages
install.packages("MASS")
install.packages("car")
install.packages("e1071")
install.packages("caret")
install.packages("ROCR")
install.packages("class")
install.packages("caTools")
install.packages("klaR")
install.packages("Hmisc")
install.packages("kernlab")

library(MASS)
library(caret)
library(car)
library(e1071)
library(ROCR)
library(class)
library(caTools)
library(klaR)
library(Hmisc)
library(kernlab)
# Load the given files.

customer_data<-read.csv("customer_data.csv",header = T,stringsAsFactors = F)


churn_data<-read.csv("churn_data.csv",header = T,stringsAsFactors = F)


internet_data <- read.csv("internet_data.csv",header = T,stringsAsFactors = F)

# Collate the 3 files in a single file.

cust_churn <- merge(customer_data,churn_data,by.x ="customerID",by.y = "customerID")

churn <- merge(cust_churn,internet_data,by.x = "customerID",by.y = "customerID")

# Understand the structure of the collated file.

str(churn)

summary(churn)

###
## Removing customerId as its not required
###

churn <- churn[,-1]
View(churn)

# Make bar charts to find interesting relationships between variables.
##EDA

histogram(churn$TotalCharges)

histogram(churn$tenure)

histogram(churn$MonthlyCharges)

ggplot(churn,aes(x=Dependents,y=MonthlyCharges)) + geom_bar(stat="identity")

ggplot(churn,aes(x=TechSupport))+geom_bar(stat="count")

ggplot(churn,aes(x=PhoneService))+geom_bar(stat="count")

ggplot(churn,aes(x=Churn))+ geom_bar(stat="count")

ggplot(churn,aes(x=SeniorCitizen,y=Churn)) + geom_bar(stat="identity")

# Perform De-Duplication if required
sum(duplicated(churn))

## Found 22 duplicated data

which(duplicated(churn))

### Remove duplicated data
churn <- churn[!duplicated(churn),]

### Check if duplicated rows are removed
sum(duplicated(churn))

## Now check if any NA exist in data set
sum(is.na(churn))

sapply(churn, function(x) sum(is.na(x)))

## i see that TotalCharges has 11 na values.
## Replace NA with mean of TotalCharges

churn$TotalCharges[which(is.na(churn$TotalCharges))] <- mean(churn$TotalCharges,na.rm = T)

## Check now if NA values still exists

sum(is.na(churn))

# Bring the variables in the correct format

churn$SeniorCitizen <- as.character(churn$SeniorCitizen)

chr.churn <- subset(churn, select = -c(5,10,11))

factor.churn <- data.frame(sapply(chr.churn,function(x) as.factor(x)))

num.churn <- subset(churn, select = c(5,10,11))

## Convert int to numeric for uniformity
num.churn$tenure <- as.numeric(num.churn$tenure)

## scale the tenure
num.churn$tenure <- scale(num.churn$tenure)

##scale the MonthlyCharges
num.churn$MonthlyCharges <- scale(num.churn$MonthlyCharges)

##scale the TotalCharges
num.churn$TotalCharges <- scale(num.churn$TotalCharges)

##bind the factor data and numerical data
churn.data <- cbind(factor.churn,num.churn)

###CATEGORIC to NUMERIC : gender
churn.data$gender <- as.data.frame(model.matrix(~gender -1, data = churn.data))[,-1]

###CATEGORIC to NUMERIC : SeniorCitizen
churn.data$SeniorCitizen <- as.data.frame(model.matrix(~SeniorCitizen -1, data = churn.data))[,-1]

###CATEGORICAL to NUMERIC: Partner
churn.data$Partner <- as.data.frame(model.matrix(~Partner -1, data = churn.data))[,-1]

###CATEGORICAL to NUMERIC: Dependents
churn.data$Dependents <- as.data.frame(model.matrix(~Dependents -1, data = churn.data))[,-1]

###CATEGORICAL to NUMERIC: PhoneService
churn.data$PhoneService <- as.data.frame(model.matrix(~PhoneService -1, data = churn.data))[,-1]

###CATEGORICAL to NUMERIC: PaperlessBilling
churn.data$PaperlessBilling <- as.data.frame(model.matrix(~PaperlessBilling -1, data = churn.data))[,-1]

##data containing only 2 factors

churn.data_2_factors<- churn.data[,c(1,2,3,4,5,7,9)]

### select only the factor variables whose levels are more than 2
factor.churn <- factor.churn[,c(6,8,10,11,12,13,14,15,16,17)]

## Run sapply and convert chr type to factor in a single line 
dummies <- sapply(factor.churn, function(x) data.frame(model.matrix(~x -1 , data = factor.churn))[,-1])

## Bind the dummies data with int/num data
churn.data.X <- cbind(dummies,churn.data_2_factors,num.churn)

# Impute the missing values, and perform the outlier treatment (if required).

boxplot(churn.data.X$tenure)

boxplot(churn.data.X$MonthlyCharges)

boxplot(churn.data.X$TotalCharges)

### Train and test data
set.seed(100)

train.indices <- sample.split(churn.data.X$Churn,SplitRatio = 0.7)

train.X <- churn.data.X[train.indices == TRUE,]

test.X <- churn.data.X[-train.indices == FALSE,]

# K-NN Model:

# Bring the data in the correct format to implement K-NN model.
## We use the same model prepared above here as well

# Implement the K-NN model for optimal K.

##class label
cl <- train.X[,28]

## Training data without target variable
data_train <- train.X[,-28]
## Test data without target variable
data_test <- test.X[,-28]

### knn model optimal
model <- train(Churn~., data = train.X,method="knn",tuneGrid=expand.grid(.k=1:20),metric="Accuracy",
               trControl=trainControl(method='repeatedcv',number = 10,repeats = 5))

model

#plot the obtained model
plot(model)

## Now run the knn function to get KNN with obtained k value
impknn <- knn(data_train,data_test,cl,k=19,prob = TRUE)

prob_knn<-attr(impknn,"prob")
prob_knn <- 19 * ifelse(impknn == "Yes", prob_knn, 1-prob_knn) -18

## Confusion matrix for knn
confusionMatrix(impknn,test.X[,28],positive = "Yes")
pred <- prediction(prob_knn, test.X[,"Churn"])
pred_knn <- prediction(prob_knn, test.X[,"Churn"])
pred_knn <- performance(pred_knn,"tpr","fpr")

plot(pred_knn, avg="threshold", colorize=T,lwd=3,main="KNN-ROC Curve")

### Area under curve
auc <- performance(pred,"auc")
auc@y.values[[1]]

############################# END OF KNN##############################
# Naive Bayes Model:

# Implement the Naive Bayes algorithm.

naive_model <- NaiveBayes(Churn~., train.X)
test_data_features <- test.X[,-28]
predict_model <- as.data.frame(predict(naive_model, test_data_features))
confusionMatrix(predict_model$class,test.X$Churn,positive = "Yes")
## calculate the Area under curve
pred_nb <- prediction(predict_model$posterior.Yes, test.X[,"Churn"])
perf_nb <- performance(pred_nb,"tpr","fpr")
##plot the curve for NB
plot(perf_nb,avg="threshold", colorize=T,lwd=3,main="NaiveBayes-ROC Curve")
##
auc_nb <- performance(pred_nb,"auc")
auc_nb@y.values[[1]]


# Logistic Regression:

# Bring the data in the correct format to implement Logistic regression model.

model_1 <- glm(Churn~., family = binomial, data=train.X)
summary(model_1)
step <- stepAIC(model_1, direction = "both")
step

# Select the variables using VIF criterion. 
model_2 <- glm(formula = Churn ~ Contract.xOne.year + Contract.xTwo.year + 
                 PaymentMethod.xElectronic.check + MultipleLines.xNo.phone.service + 
                 MultipleLines.xYes + InternetService.xFiber.optic + InternetService.xNo + 
                 OnlineBackup.xYes + DeviceProtection.xYes + StreamingTV.xYes + 
                 StreamingMovies.xYes + Dependents + PaperlessBilling + tenure + 
                 MonthlyCharges + TotalCharges, family = binomial, data = train.X)

summary(model_2)

vif(model_2)


# Implement the Logistic regression algorithm and use stepwise selection to select final variables

## Removing MonthlyCharges
model_3 <- glm(formula = Churn ~ Contract.xOne.year + Contract.xTwo.year + 
                 PaymentMethod.xElectronic.check + MultipleLines.xNo.phone.service + 
                 MultipleLines.xYes + InternetService.xFiber.optic + InternetService.xNo + 
                 OnlineBackup.xYes + DeviceProtection.xYes + StreamingTV.xYes + 
                 StreamingMovies.xYes + Dependents + PaperlessBilling + tenure + 
                 TotalCharges, family = binomial, data = train.X)

summary(model_3)

vif(model_3)

## Removing TotalCharges
model_4 <- glm(formula = Churn ~ Contract.xOne.year + Contract.xTwo.year + 
                 PaymentMethod.xElectronic.check + MultipleLines.xNo.phone.service + 
                 MultipleLines.xYes + InternetService.xFiber.optic + InternetService.xNo + 
                 OnlineBackup.xYes + DeviceProtection.xYes + StreamingTV.xYes + 
                 StreamingMovies.xYes + Dependents + PaperlessBilling + tenure, family = binomial, data = train.X)

summary(model_4)

vif(model_4)

## Removing DeviceProtection.xYes
model_5 <- glm(formula = Churn ~ Contract.xOne.year + Contract.xTwo.year + 
                 PaymentMethod.xElectronic.check + MultipleLines.xNo.phone.service + 
                 MultipleLines.xYes + InternetService.xFiber.optic + InternetService.xNo + 
                 OnlineBackup.xYes + StreamingTV.xYes + 
                 StreamingMovies.xYes + Dependents + PaperlessBilling + tenure, family = binomial, data = train.X)

summary(model_5)

vif(model_5)

## Removing OnlineBackup.xYes
model_6 <- glm(formula = Churn ~ Contract.xOne.year + Contract.xTwo.year + 
                 PaymentMethod.xElectronic.check + MultipleLines.xNo.phone.service + 
                 MultipleLines.xYes + InternetService.xFiber.optic + InternetService.xNo + 
                 StreamingTV.xYes + StreamingMovies.xYes + Dependents + PaperlessBilling + tenure, family = binomial, data = train.X)

summary(model_6)

vif(model_6)

## Removing StreamingTV.xYes
model_7 <- glm(formula = Churn ~ Contract.xOne.year + Contract.xTwo.year + 
                 PaymentMethod.xElectronic.check + MultipleLines.xNo.phone.service + 
                 MultipleLines.xYes + InternetService.xFiber.optic + InternetService.xNo + 
                 StreamingMovies.xYes + Dependents + PaperlessBilling + tenure, family = binomial, data = train.X)
summary(model_7)

vif(model_7)

## Removing Dependents
model_8 <- glm(formula = Churn ~ Contract.xOne.year + Contract.xTwo.year + 
                 PaymentMethod.xElectronic.check + MultipleLines.xNo.phone.service + 
                 MultipleLines.xYes + InternetService.xFiber.optic + InternetService.xNo + 
                 StreamingMovies.xYes + PaperlessBilling + tenure, family = binomial, data = train.X)

summary(model_8)

vif(model_8)

# Make the final logistic regression model.

final_model <- model_8

predictions_data <- predict(final_model,newdata = test.X[,-28],type = "response")

pred_object <- prediction(predictions_data,test.X$Churn)

performance_measures <- performance(pred_object,measure = "tpr",x.measure = "fpr")

plot(performance_measures)

auc <- performance(pred_object,measure = "auc")

auc@y.values[[1]]

# c-statistics for train and test data
train.X$predicted_prob <- predict(final_model, type = "response")
rcorr.cens(train.X$predicted_prob,train.X$Churn)

test.X$predicted_prob <- predict(final_model,newdata = test.X,type="response")
rcorr.cens(test.X$predicted_prob,test.X$Churn)

### KS -Statistics for train and test
model_score <- prediction(train.X$predicted_prob,train.X$Churn)
model_perf <- performance(model_score,"tpr","fpr")
ks_table <- attr(model_perf, "y.values")[[1]] - (attr(model_perf,"x.values")[[1]])
ks = max(ks_table)
which(ks_table == ks)

model_score_test <- prediction(test.X$predicted_prob,test.X$Churn)
model_perf_test <- performance(model_score_test,"tpr","fpr")
ks_table_test <- attr(model_perf_test, "y.values")[[1]] - (attr(model_perf_test, "x.values")[[1]])
ks_test <- max(ks_table_test)
which(ks_table_test == ks_test)

# Selecting threshold value

# ROC curve
plot(model_perf,col = "red", lab = c(10,10,10))

#Threshold of 0.3
#confusion matrix
train.X$Churn <- as.factor(train.X$Churn)
train.X$Churn <- as.numeric(train.X$Churn) -1
levels(train.X$Churn)["Yes"] <- 1
levels(train.X$Churn)["No"] <- 0
confusionMatrix(as.numeric(train.X$predicted_prob > 0.3),train.X$Churn,positive = "1")

test.X$Churn <- as.factor(test.X$Churn)
test.X$Churn <- as.numeric(test.X$Churn) -1
levels(test.X$Churn)["Yes"] <- 1
levels(test.X$Churn)["No"] <- 0
confusionMatrix(as.numeric(test.X$predicted_prob > 0.3),test.X$Churn,positive = "1")

#Threshold of 0.5
#confusion matrix
confusionMatrix(as.numeric(train.X$predicted_prob > 0.5),train.X$Churn,positive = "1")

confusionMatrix(as.numeric(test.X$predicted_prob > 0.5),test.X$Churn,positive = "1")

#Threshold of 0.7
#confusion matrix
confusionMatrix(as.numeric(train.X$predicted_prob > 0.7),train.X$Churn,positive = "1")

confusionMatrix(as.numeric(test.X$predicted_prob > 0.7),test.X$Churn,positive = "1")


# SVM:

# Bring the data in the correct format to implement the SVM algorithm.
## for svm using tenure,monthlyCharges and Churn variables
svm_data <- churn[c(5,10,12)]
str(svm_data)

svm_data$Churn <- factor(svm_data$Churn)
set.seed(100)
train_indices_1 <- sample.split(svm_data$Churn,SplitRatio = 0.7)

train_svm <- svm_data[train_indices_1,]
test_svm <- svm_data[-train_indices_1,]

model.svm.0 <- svm(Churn~.,data=train_svm,kernel="linear",cost=0.1,scale = F)

plot(model.svm.0,train_svm)

summary(model.svm.0)

tune.svm <- tune(svm,Churn~.,data = train_svm,kernel="linear",ranges = list(cost=c(0.001,0.01,0.1,0.5,1,10,100)))

summary(tune.svm)

# Implement the SVM algorithm using the optimal cost.

best.mod <- tune.svm$best.model

best.mod

ypred <- predict(best.mod,test_svm)

table(predicted=ypred,truth=test_svm$Churn)

confusionMatrix(ypred,test_svm$Churn)

plot(best.mod,test_svm)

### AUC for SVM

model.svm.1 <- ksvm(Churn ~ .,data=svm_data,type="C-svc",C=10,prob.model=TRUE)

svm.pred <- as.data.frame(predict(model.svm.1, svm_data[,-3], type="probabilities"))

svm.prediction <- prediction(svm.pred$Yes, svm_data[,3])

svm.performance <- performance(svm.prediction,"auc")

svm.performance@y.values[[1]]