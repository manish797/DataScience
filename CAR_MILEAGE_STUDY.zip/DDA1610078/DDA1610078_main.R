rm(list=ls())
######### SETTING WORKING DIRECTORY ######################

setwd("D:/PGDDA/R DOWNLOAD/ASSIGNMENTS/CAR DREAM STUDY")

#####  LOADING DATA ###########

carmileage <- read.csv("carMPG.csv" ,stringsAsFactors = FALSE)

################### CHECKPOINT 2 ##############################




###### Data Understanding  #################

## View the data ##
View(carmileage)

## Structure of data set###

str(carmileage)

# Data Formatting

# Checking Uniqueness of data set 
nrow(carmileage)  # 398 Rows
nrow(unique(carmileage))  # 398 Rows , hence no Duplicated Rows


# Checking for correct data type of the variables
# Changing Horsepower to integer  

carmileage$Horsepower <- as.numeric(carmileage$Horsepower)

# Changing Cylinder from int to factor
carmileage$Cylinders <- as.factor(carmileage$Cylinders)

# Changing Model from int to Factor

carmileage$Model_year <- as.factor(carmileage$Model_year)

# Changing Origin  from int to factor
carmileage$Origin <- as.factor(carmileage$Origin)


# Changing Car Name  from char to factor
library(stringr)

# Taking out first name of the company Name or brand
carmileage$car_Name_1 <- word(carmileage$Car_Name,1)
# Convert into factor 
carmileage$car_Name_1 <- as.factor(carmileage$car_Name_1)


# Checking levels 
levels(carmileage$car_Name_1)
# Some  redundant car brand name as a variables so , correcting the car names
levels(carmileage$car_Name_1)[7]  <- "chevrolet"
levels(carmileage$car_Name_1)[16]  <- "mazda"
levels(carmileage$car_Name_1)[32]  <- "volkswagen"
levels(carmileage$car_Name_1)[34]  <- "volkswagen"
levels(carmileage$car_Name_1)[30]  <- "toyota"
levels(carmileage$car_Name_1)[17]  <- "mercedes-benz"
levels(carmileage$car_Name_1)[8]  <- "chevrolet"
levels(carmileage$car_Name_1)[6]  <- "ford"

# WE checked that levels reduced to 29
levels(carmileage$car_Name_1)

# Again looking at the structure of the data set, except "Car_Name" 

str(carmileage)
# Since Horse power column has some '?' values , after changing to Numeirc one, 'NAs' has been introduced ,
#we will take care of it into Data Cleaning section


# Excluding Car_Name column

carmileage<- carmileage[,-9]



#########  Dala cleaning ##########

## Checking Mising values 

sum(is.na(carmileage))  # Total 6 values , Let's treat them

## Checking column by column

sum(is.na(carmileage$MPG))  ## 0  Missing values in MPG
sum(is.na(carmileage$Cylinders))  ## 0  Missing values in Cylinders
sum(is.na(carmileage$Displacement)) ## Missing values in Displacement
sum(is.na(carmileage$Horsepower))  ## Got 6 Missing values hence only this column has missing values not any other column

##  Out of 398 observations we have 6 NAs hence we  discard those values.
#  Data without Missing values
carmileage <- subset (carmileage, is.na(carmileage$Horsepower) == F)


############ Checking  For outliers ############

## By using the quantile distribution, we will check for outliers

# Start with  MPG , we could see some marginal difference at 0 % and 99 %  but can it be decalred outlier ?
quantile(carmileage$MPG,probs = seq(0,1,0.01))
# To confirm lets box plot this 
boxplot.stats(carmileage$MPG) # Results shows no Outlier 



# For Displacement ,No Outlier
quantile(carmileage$Displacement,probs = seq(0,1,0.01)) 


# For Horsepower we do not see sudden jump in quantiles values
quantile(carmileage$Horsepower,probs = seq(0,1,0.01))  
boxplot.stats(carmileage$Horsepower)


# For Weight ,we do not see sudden jump in quantiles values
quantile(carmileage$Weight,probs = seq(0,1,0.01))  


# For Acceleration ,we do not see much variation suddenly  in quantiles values
quantile(carmileage$Acceleration,probs = seq(0,1,0.01))   



## Binning of data 
levels(carmileage$Cylinders)

#Binning the Cylinder category

#library(arules)
#y <- carmileage[,2]
#table(discretize(y, categories = 3))
# Results shows equal binning range 

levels(carmileage$Cylinders)
levels(carmileage$Cylinders)[1:2] <- "small"
levels(carmileage$Cylinders)[2:3] <- "medium"
levels(carmileage$Cylinders)[3] <- "bigger"
# Through binning levels reduced to 3 levels
levels(carmileage$Cylinders)


#Binning Model Category

hist(carmileage$Model_year)


#x <- carmileage[,7]
#table(discretize(x, categories = 3))
# Above shows  result as 
#[2003,2007) [2007,2011) [2011,2015] 
#118         128         152
#Hence we will divide into 3 categories based on the bin range as given above by table


levels(carmileage$Model_year)[1:4] <-"very old"
levels(carmileage$Model_year)[2:5]<- "old"
levels(carmileage$Model_year)[3:7]<- "New"
levels(carmileage$Model_year)

# levels reduced to 3 levels 

## Variable Transformation

# Creating dummy for Car Name

dummy_1 <- data.frame(model.matrix( ~car_Name_1, data = carmileage))
dummy_1<-dummy_1[,-1]

# Creating dummy variable for Cylinder

dummy_2 <- data.frame(model.matrix( ~Cylinders, data =carmileage ))
dummy_2<-dummy_2[,-1]

# Creating dummy variable for Model year

dummy_3 <- data.frame(model.matrix( ~Model_year, data =carmileage ))
dummy_3<-dummy_3[,-1]

# Creating dummy variable for Origin


dummy_4 <- data.frame(model.matrix( ~Origin, data =carmileage ))
dummy_4<-dummy_4[,-1]



# Combining the data set 
carmileage <- cbind( carmileage[,c(1,3,4,5,6)] , dummy_1,dummy_2,dummy_3,dummy_4) 

colnames(carmileage)
# Divide you data in 70:30 

set.seed(100)
indices= sample(1:nrow(carmileage), 0.7*nrow(carmileage))

train=carmileage[indices,]
test = carmileage[-indices,]


############### DATA PREPERATION ENDS ###############################

###################  MODELLING STARTS ############
library(MASS)
library(car)
## First model

model_1 <- lm(MPG~.,data = train)

summary(model_1)
## Seen lot of In significant values

step <- stepAIC(model_1 ,direction = "both")

step

model_2 <- lm(formula = MPG ~ Horsepower + Weight + car_Name_1datsun + car_Name_1fiat + 
                car_Name_1honda + car_Name_1nissan + car_Name_1oldsmobile + 
                car_Name_1pontiac + car_Name_1renault + car_Name_1toyota + 
                car_Name_1triumph + car_Name_1volkswagen + Cylindersmedium + 
                Model_yearold + Model_yearNew + car_Name_1ford, data = train)
# After summary , Adjusted r value is  commneted with summary to see the change
summary(model_2) #84.94


vif(model_2)# Seen high vif for Weight , horsepower but they are significant hence removing other
# insignificant variables

# Removing car_Name_1honda
model_3 <- lm(formula = MPG ~ Horsepower + Weight + car_Name_1datsun + car_Name_1fiat + 
                 car_Name_1nissan + car_Name_1oldsmobile + 
                car_Name_1pontiac + car_Name_1renault + car_Name_1toyota + 
                car_Name_1triumph + car_Name_1volkswagen + Cylindersmedium + 
                Model_yearold + Model_yearNew + car_Name_1ford, data = train)
summary(model_3)#0.8471
vif(model_3)

# Observed very little change for Horsepower and weight and they have high vifs , checking for correlation
cor(train$Horsepower,train$Weight) # came out to be 0.867 ,hence removing Horsepower as it having higher
#vif (5.25) than weight (5.066)

# Reamoving HorsePower

model_4 <- lm(formula = MPG ~ Weight + car_Name_1datsun + car_Name_1fiat + 
                car_Name_1nissan + car_Name_1oldsmobile + 
                car_Name_1pontiac + car_Name_1renault + car_Name_1toyota + 
                car_Name_1triumph + car_Name_1volkswagen + Cylindersmedium + 
                Model_yearold + Model_yearNew + car_Name_1ford, data = train)

summary(model_4) # 0.84

vif(model_4) # Every varibale is under 2 , so we can now remove the insignificant variables based on 
# P value


# Removing car_Name_1nissan

model_5 <- lm(formula = MPG ~ Weight + car_Name_1datsun + car_Name_1fiat + 
                 car_Name_1oldsmobile + 
                car_Name_1pontiac + car_Name_1renault + car_Name_1toyota + 
                car_Name_1triumph + car_Name_1volkswagen + Cylindersmedium + 
                Model_yearold + Model_yearNew + car_Name_1ford, data = train)

summary(model_5) # 0.84 ,No change

# Removing car_Name_1toyota
model_6 <- lm(formula = MPG ~ Weight + car_Name_1datsun + car_Name_1fiat + 
                car_Name_1oldsmobile + 
                car_Name_1pontiac + car_Name_1renault +  
                car_Name_1triumph + car_Name_1volkswagen + Cylindersmedium + 
                Model_yearold + Model_yearNew + car_Name_1ford, data = train)

summary(model_6) # 0.8398

# Removing car_Name_1triumph

model_7 <- lm(formula = MPG ~ Weight + car_Name_1datsun + car_Name_1fiat + 
                car_Name_1oldsmobile + 
                car_Name_1pontiac + car_Name_1renault +  
                car_Name_1volkswagen + Cylindersmedium + 
                Model_yearold + Model_yearNew + car_Name_1ford, data = train)

summary(model_7) # 0.8394

# Removing car_Name_1oldsmobile

model_8 <- lm(formula = MPG ~ Weight + car_Name_1datsun + car_Name_1fiat + 
                car_Name_1pontiac + car_Name_1renault +  
                car_Name_1volkswagen + Cylindersmedium + 
                Model_yearold + Model_yearNew + car_Name_1ford, data = train)

summary(model_8) # 0.8388

# Removing car_Name_1pontiac

model_9 <- lm(formula = MPG ~ Weight + car_Name_1datsun + car_Name_1fiat + 
                car_Name_1renault + car_Name_1volkswagen + Cylindersmedium + 
                Model_yearold + Model_yearNew + car_Name_1ford, data = train)

summary(model_9) # 0.838

vif(model_9) #All under 2 

# Removing car_Name_1fiat

model_10 <- lm(formula = MPG ~ Weight + car_Name_1datsun +  
                car_Name_1renault + car_Name_1volkswagen + Cylindersmedium + 
                Model_yearold + Model_yearNew + car_Name_1ford, data = train)

summary(model_10) # 0.8369

# Removing car_Name_1renault

model_11 <- lm(formula = MPG ~ Weight + car_Name_1datsun +  
                 car_Name_1volkswagen + Cylindersmedium + 
                 Model_yearold + Model_yearNew + car_Name_1ford, data = train)

summary(model_11) # 0.8355

# Removing car_Name_1ford

model_12 <- lm(formula = MPG ~ Weight + car_Name_1datsun +  
                 car_Name_1volkswagen + Cylindersmedium + 
                 Model_yearold + Model_yearNew , data = train)

summary(model_12) # 0.833

# Removing car_Name_1datsun

model_13 <- lm(formula = MPG ~ Weight +   
                 car_Name_1volkswagen + Cylindersmedium + 
                 Model_yearold + Model_yearNew , data = train)

summary(model_13) # 0.828


## This signifies the model we have is able to predict 82.8 % of data set with 5 independent variables ,Let's evaluate the  model
# agianst test data and also vif is under 2 complying with buiness rules.

#Coefficients:
# Estimate Std. Error t value Pr(>|t|)    
#(Intercept)          46.5101155  0.7665476  60.675  < 2e-16 ***
# Weight               -0.0061524  0.0002517 -24.447  < 2e-16 ***
#car_Name_1volkswagen  3.1494602  0.8877311   3.548 0.000459 ***
#Cylindersmedium      -2.1753142  0.5009040  -4.343    2e-05 ***
#Model_yearold        -4.9876943  0.5284657  -9.438  < 2e-16 ***
#Model_yearNew        -7.2660251  0.5087765 -14.281  < 2e-16 ***
#Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1

#Residual standard error: 3.304 on 268 degrees of freedom
#Multiple R-squared:  0.8312,	Adjusted R-squared:  0.828 
#F-statistic: 263.9 on 5 and 268 DF,  p-value: < 2.2e-16

##############MODEL DEVELOPMENT ENDS ################### 


########### MODEL EVALUATION STARTS #########################

Predict_1 <- predict(model_13,test[,-c(1)])


## Adding column to  test data set 

test$test_MPG <- Predict_1


cor(test$MPG,test$test_MPG)  # 0.90944
cor(test$MPG,test$test_MPG)^2 #0.827

# Hence we saw that the  final model model_13 is able to predict the  values with 82.70 % of accuracyy,
# and thus achieiving the objective

########### MODEL EVALUATION ENDS #########################

## PLOTS FOR PRESENTATION

library(ggplot2)


ggplot(test,aes(x= Weight, y = MPG )) + geom_point() +geom_smooth()
ggplot(test,aes(x= Weight, y = test_MPG )) + geom_point() +geom_smooth()
ggplot(test,aes(x=MPG))+geom_histogram(binwidth = 1)
ggplot(test,aes(x=test_MPG))+geom_histogram(binwidth = 1)

rm(list=ls())
############################ CASE STUDY ENDS  #####################
