################  TIME  SERIES ANALYSIS ###################

rm(list=ls())
######### SETTING WORKING DIRECTORY ######################

setwd("D:/PGDDA/R DOWNLOAD/ASSIGNMENTS/TIME SERIES CASE STUDY")

#### Reading the global store sales data 

globalStoreData <- read.csv("Global Superstore.csv", stringsAsFactors = FALSE)

## View data 
str(globalStoreData)

## No NA found in the data of important varibales
sum(is.na(globalStoreData$Segment))
sum(is.na(globalStoreData$Market))
sum(is.na(globalStoreData$Sales))
sum(is.na(globalStoreData$Profit))

## Converting MArket and  Segment into Factors

globalStoreData$Segment <-   as.factor(globalStoreData$Segment)
globalStoreData$Market <-   as.factor(globalStoreData$Market)

##### Step1 .   Data Preperation

### Split the data set into 21 data sets for Market and egment analyis

levels(globalStoreData$Market)
#  "Africa" "APAC"   "Canada" "EMEA"   "EU"     "LATAM"  "US" 

levels(globalStoreData$Segment)
# "Consumer"    "Corporate"   "Home Office"

Segment <- unlist(levels(globalStoreData$Segment))
Market <- unlist(levels(globalStoreData$Market))


library(lubridate)

## Converting date (Order Date) to month wise format 
#backup_globalStoreData <- globalStoreData

dates_globalStore <- as.POSIXct(rep(NA,length(globalStoreData$Order.Date)))

dates_globalStore[is.na(dates_globalStore)] <- do.call("dmy",list(globalStoreData$Order.Date [is.na(dates_globalStore)])) 

globalStoreData$Order.Date<- trunc(dates_globalStore, "day")

globalStoreData$Order.Date  <- as.Date(globalStoreData$Order.Date)

str(globalStoreData)

globalStoreData$Order.Date <-  strftime(globalStoreData$Order.Date, "%Y-%m")


## Calculating months
library(zoo)
globalStoreData$months <-12*as.numeric(as.yearmon(globalStoreData$Order.Date, "%Y-%m") - as.yearmon(as.Date("2010-12-1"), "%Y-%m"))


#####  Creating 21 combinations dataset of Segments and market . 

for(market in Market){
   
        for(segment in  Segment ){
          
          dataset_name  <- paste ("data",segment , market , sep = "_")  
          filtered_data_set <- subset(globalStoreData ,Market == market & Segment == segment) 
          assign(dataset_name ,filtered_data_set) 
        }
}

## Aggregating the sales, Quantity , Profit for the 21  segments.

# Data of  Consumer  Segment
#  Africa
aggr_Consumer_Africa = aggregate( cbind(Quantity ,Profit,Sales) ~ months,data= data_Consumer_Africa, FUN = sum)
# 1.319585
aggr_Consumer_Africa_cv_profit <- sd(aggr_Consumer_Africa$Profit)/mean(aggr_Consumer_Africa$Profit)
# "APAC"   


aggr_Consumer_APAC = aggregate( cbind(Quantity ,Profit,Sales) ~ months,data= data_Consumer_APAC, FUN = sum)
# 0.6321323
aggr_Consumer_APAC_cv_profit <- sd(aggr_Consumer_APAC$Profit)/mean(aggr_Consumer_APAC$Profit)


#"Canada" 
aggr_Consumer_Canada = aggregate( cbind(Quantity ,Profit,Sales) ~ months,data= data_Consumer_Canada, FUN = sum)
# 1.395312
aggr_Consumer_Canada_cv_profit <- sd(aggr_Consumer_Canada$Profit)/mean(aggr_Consumer_Canada$Profit)

# "EMEA"  
aggr_Consumer_EMEA = aggregate( cbind(Quantity ,Profit,Sales) ~ months,data= data_Consumer_EMEA, FUN = sum)
# 2.188271
aggr_Consumer_EMEA_cv_profit <- sd(aggr_Consumer_EMEA$Profit)/mean(aggr_Consumer_EMEA$Profit)

#  "EU"  
aggr_Consumer_EU = aggregate( cbind(Quantity ,Profit,Sales) ~ months,data= data_Consumer_EU, FUN = sum)
# 0.624
aggr_Consumer_EU_cv_profit <- sd(aggr_Consumer_EU$Profit)/mean(aggr_Consumer_EU$Profit)


# "LATAM" 
aggr_Consumer_LATAM = aggregate( cbind(Quantity ,Profit,Sales) ~ months,data= data_Consumer_LATAM, FUN = sum)
# 0.6614828
aggr_Consumer_LATAM_cv_profit <- sd(aggr_Consumer_LATAM$Profit)/mean(aggr_Consumer_LATAM$Profit)

#  "US"
aggr_Consumer_US = aggregate( cbind(Quantity ,Profit,Sales) ~ months,data= data_Consumer_US, FUN = sum)
# 1.01239
aggr_Consumer_US_cv_profit <- sd(aggr_Consumer_US$Profit)/mean(aggr_Consumer_US$Profit)

######### Segment  Corporate

# Africa
aggr_Corporate_Africa = aggregate( cbind(Quantity ,Profit,Sales) ~ months,data= data_Corporate_Africa, FUN = sum)
# 1.776105
aggr_Corporate_Africa_cv_profit <- sd(aggr_Corporate_Africa$Profit)/mean(aggr_Corporate_Africa$Profit)

#  "APAC" 
aggr_Corporate_APAC = aggregate( cbind(Quantity ,Profit,Sales) ~ months,data= data_Corporate_APAC, FUN = sum)
# 0.6980869
aggr_Corporate_APACa_cv_profit <- sd(aggr_Corporate_APAC$Profit)/mean(aggr_Corporate_APAC$Profit)

#"Canada" 
aggr_Corporate_Canada = aggregate( cbind(Quantity ,Profit,Sales) ~ months,data= data_Corporate_Canada, FUN = sum)
# 1.552775
aggr_Corporate_Canada_cv_profit <- sd(aggr_Corporate_Canada$Profit)/mean(aggr_Corporate_Canada$Profit)

# "EMEA"   
aggr_Corporate_EMEA = aggregate( cbind(Quantity ,Profit,Sales) ~ months,data= data_Corporate_EMEA, FUN = sum)
# 4.467102
aggr_Corporate_EMEA_cv_profit <- sd(aggr_Corporate_EMEA$Profit)/mean(aggr_Corporate_EMEA$Profit)

# "EU" 
aggr_Corporate_EU = aggregate( cbind(Quantity ,Profit,Sales) ~ months,data= data_Corporate_EU, FUN = sum)
# 0.7638072
aggr_Corporate_EU_cv_profit <- sd(aggr_Corporate_EU$Profit)/mean(aggr_Corporate_EU$Profit)

# "LATAM"
aggr_Corporate_LATAM = aggregate( cbind(Quantity ,Profit,Sales) ~ months,data= data_Corporate_LATAM, FUN = sum)
# 0.8111217
aggr_Corporate_LATAM_cv_profit <- sd(aggr_Corporate_LATAM$Profit)/mean(aggr_Corporate_LATAM$Profit)

# "US" 
aggr_Corporate_US = aggregate( cbind(Quantity ,Profit,Sales) ~ months,data= data_Corporate_US, FUN = sum)
# 1.002409
aggr_Corporate_US_cv_profit <- sd(aggr_Corporate_US$Profit)/mean(aggr_Corporate_US$Profit)

######################3 Home Office segement

#  "Africa"
aggr_HomeOffice_Africa = aggregate( cbind(Quantity ,Profit,Sales) ~ months,data= `data_Home Office_Africa`, FUN = sum)
# 1.789996
aggr_HomeOffice_Africa_cv_profit <- sd(aggr_HomeOffice_Africa$Profit)/mean(aggr_HomeOffice_Africa$Profit)

# "APAC" 
aggr_HomeOffice_APAC = aggregate( cbind(Quantity ,Profit,Sales) ~ months,data=`data_Home Office_APAC`, FUN = sum)
# 1.045978
aggr_HomeOffice_APAC_cv_profit <- sd(aggr_HomeOffice_APAC$Profit)/mean(aggr_HomeOffice_APAC$Profit)

# "Canada"
aggr_HomeOffice_Canada = aggregate( cbind(Quantity ,Profit,Sales) ~ months,data=`data_Home Office_Canada`, FUN = sum)
# 2.243461
aggr_HomeOffice_Canada_cv_profit <- sd(aggr_HomeOffice_Canada$Profit)/mean(aggr_HomeOffice_Canada$Profit)

# "EMEA"   
aggr_HomeOffice_EMEA = aggregate( cbind(Quantity ,Profit,Sales) ~ months,data=`data_Home Office_EMEA`, FUN = sum)
# 5.880747
aggr_HomeOffice_EMEA_cv_profit <- sd(aggr_HomeOffice_EMEA$Profit)/mean(aggr_HomeOffice_EMEA$Profit)

# "EU"
aggr_HomeOffice_EU = aggregate( cbind(Quantity ,Profit,Sales) ~ months,data=`data_Home Office_EU`, FUN = sum)
# 1.116507
aggr_HomeOffice_EU_cv_profit <- sd(aggr_HomeOffice_EU$Profit)/mean(aggr_HomeOffice_EU$Profit)

#    "LATAM" 
aggr_HomeOffice_LATAM = aggregate( cbind(Quantity ,Profit,Sales) ~ months,data=`data_Home Office_LATAM`, FUN = sum)
# 1.175698
aggr_HomeOffice_LATAM_cv_profit <- sd(aggr_HomeOffice_LATAM$Profit)/mean(aggr_HomeOffice_LATAM$Profit)

#   "US"
aggr_HomeOffice_US = aggregate( cbind(Quantity ,Profit,Sales) ~ months,data=`data_Home Office_US`, FUN = sum)
# 1.096147
aggr_HomeOffice_US_cv_profit <- sd(aggr_HomeOffice_US$Profit)/mean(aggr_HomeOffice_US$Profit)


### The top five consistenly profitable segements ie with low coff of variation are:
# 1.
aggr_Consumer_EU_cv_profit # 0.6243
# 2.
aggr_Consumer_APAC_cv_profit  # 0.6321323

# 3.
aggr_Consumer_LATAM_cv_profit  # 0.6614828
# 4.
aggr_Corporate_APACa_cv_profit # 0.6980869

# 5.
aggr_Corporate_EU_cv_profit # 0.7638072



######################## CHECKPOINT 2 - TIME SERIES MODELLING

library(forecast)
require(graphics)

#### For data set Consumer_EU_42_monthsdata

## Common variables for all segements 
example <- 1
xcol_months <- c(1)
ycol_quantity <- c(2)
ycol_sales <- c(2)
# For  quantity
#timeser_quantity_Consumer_EU <- ts(aggr_Consumer_EU[,ycol_quantity[example]])

#plot(timeser_quantity_Consumer_EU)
# Preparing data for train and test
# Sales data for Consumer_EU

train_sales_Consumer_EU <- subset(aggr_Consumer_EU[,c(1,4)] , months <=42)
test_sales_Consumer_EU <- subset(aggr_Consumer_EU[,c(1,4)] ,months >42)

timeser_train_sales_Consumer_EU <- ts(train_sales_Consumer_EU[,ycol_sales[example]])
# Plotting time series
plot(timeser_train_sales_Consumer_EU )

# Quantity data for Consumer_EU

train_Quantity_Consumer_EU <- subset(aggr_Consumer_EU[,c(1,2)] , months <=42)
test_Quantity_Consumer_EU <- subset(aggr_Consumer_EU[,c(1,2)] ,months >42)

timeser_train_Quantity_Consumer_EU <- ts(train_Quantity_Consumer_EU[,ycol_quantity[example]])
# Plotting time series
plot(timeser_train_Quantity_Consumer_EU )

### Smoothing and modelling the  series of sales of Consumer_EU


## Function which uses MA technique for smoothening the series, this function will be common to all
## series wherever required 

smoothen_series <- function(timeSeries , w){
  
smoothedseries <- filter(timeSeries, 
                           filter=rep(1/(2*w+1),(2*w+1)), 
                           method='convolution', sides=2)
  
diff <- smoothedseries[w+2] - smoothedseries[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries[i] <- smoothedseries[i+1] - diff
  }
n <- length(smoothedseries)
#timevals_Consumer_EU <- aggr_Consumer_EU_42_monthsdata[[xcol_months[example]]]
diff <- smoothedseries[n-w] - smoothedseries[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries[i] <- smoothedseries[i-1] + diff
}
  
return(smoothedseries)
  
  
}

## Calling  funtion for smoothening
smoothedseries_Consumer_EU_sales <- smoothen_series(timeser_train_sales_Consumer_EU,1)

## Checking the smoothen time  series for sales
lines(smoothedseries_Consumer_EU_sales, col="blue", lwd=2)

## Common to all the time series
timevals_Consumer_EU <- train_sales_Consumer_EU[[xcol_months[example]]]

## We tried with  keeping w to  1,3,5 and 1 seems to be  smoothing it well 
## and giving it a shape of sinosodal wave with  increasing amplitude showing increasing
#  trend ,hence additive linear model can be  fit with some tweaks in  the
#  amplitude values


## Fitting the linear regression model 

## Testing the plot 
plot(timeser_train_sales_Consumer_EU )
lines(smoothedseries_Consumer_EU_sales, col="blue", lwd=2)

# Modelling the  seasonality and trend
lmfit_Consumer_EU_sales <- lm(train_sales_Consumer_EU$Sales ~ sin(0.4*train_sales_Consumer_EU$months) * poly(train_sales_Consumer_EU$months,2)
                              + cos(0.4*train_sales_Consumer_EU$months) * poly(train_sales_Consumer_EU$months,2)
                              + train_sales_Consumer_EU$months, data=train_sales_Consumer_EU)

trend_Consumer_EU_sales <- predict(lmfit_Consumer_EU_sales, data.frame(x=timevals_Consumer_EU))
lines(timevals_Consumer_EU, trend_Consumer_EU_sales, col='red', lwd=2)


## Checking the  residue for pure noise 



resi_Consumer_EU_sales <- timeser_train_sales_Consumer_EU - trend_Consumer_EU_sales
hist(resi_Consumer_EU_sales)
plot(resi_Consumer_EU_sales, col='red')
acf(resi_Consumer_EU_sales)
acf(resi_Consumer_EU_sales, type="partial")
armafit_Consumer_EU_sales <- auto.arima(resi_Consumer_EU_sales)

library(tseries)
# Dickey-Fuller = -7.3814, Lag order = 3, p-value = 0.01 ,shows stationarity of data
adf.test(resi_Consumer_EU_sales)

##  armafit does shows ARIMA(0,0,0) values suggesting the best model we could model
armafit_Consumer_EU_sales

## Finding the  auto.arima fit direclty into the data set timeser_sales_Consumer_EU
autoarima_Consumer_EU_sales <- auto.arima(timeser_train_sales_Consumer_EU)
autoarima_Consumer_EU_sales
#tsdiag(autoarima_Consumer_EU_sales)
plot(autoarima_Consumer_EU$x, col="black")
lines(fitted(autoarima_Consumer_EU), col="red")

### Smoothing and modelling the  series of Quantity of Consumer_EU

## Data set
# : train_Quantity_Consumer_EU  and Time series: timeser_train_Quantity_Consumer_EU


## Checking the smoothen time  series 

plot(timeser_train_Quantity_Consumer_EU)
## Calling  funtion for smoothening
smoothedseries_Consumer_EU_quantity <- smoothen_series(timeser_train_Quantity_Consumer_EU,1)

## Checking the smoothen time  series for sales
lines(smoothedseries_Consumer_EU_quantity, col="blue", lwd=2)

## Common to all the time series
timevals_Consumer_EU <- train_Quantity_Consumer_EU[[xcol_months[example]]]



## It shows shape of sinosodal wave with  increasing amplitude showing increasing
#  trend just like sales,hence additive linear model can be  fit with some tweaks in  the
#  amplitude values


## Fitting the linear regression model 
# Testing the plot 
plot(timeser_train_Quantity_Consumer_EU)
lines(smoothedseries_Consumer_EU_quantity, col="blue", lwd=2)

# Modelling the  seasonality and trend
lmfit_Consumer_EU_quantity <- lm(train_Quantity_Consumer_EU$Quantity ~ sin(0.4*train_Quantity_Consumer_EU$months) * poly(train_Quantity_Consumer_EU$months,2) 
                                 + cos(0.4*train_Quantity_Consumer_EU$months) * poly(train_Quantity_Consumer_EU$months,2) 
                                 + train_Quantity_Consumer_EU$months, data=train_Quantity_Consumer_EU)
trend_Consumer_EU_quantity <- predict(lmfit_Consumer_EU_quantity, data.frame(x=timevals_Consumer_EU))
lines(timevals_Consumer_EU, trend_Consumer_EU_quantity, col='red', lwd=2)


## Checking the  residue for pure noise 

resi_Consumer_EU_quantity <- timeser_train_Quantity_Consumer_EU - trend_Consumer_EU_quantity
plot(resi_Consumer_EU_quantity, col='red')
acf(resi_Consumer_EU_quantity)
acf(resi_Consumer_EU_quantity, type="partial")
armafit_Consumer_EU_quantity <- auto.arima(resi_Consumer_EU_quantity)

tsdiag(armafit_Consumer_EU_quantity)

library(tseries)

hist(resi_Consumer_EU_quantity)
## adf test shows that the  resi_Consumer_EU_quantity is stationary
## with p = 0.01 , hence rejecting the null hypothesis
adf.test(resi_Consumer_EU_quantity,alternative="stationary")
# The histogram shows the normal distribtion showing the  stationary data 
hist(resi_Consumer_EU_quantity)


## Finding the  auto.arima fit direclty into the data set timeser_sales_Consumer_EU
autoarima_Consumer_EU_quantity <- auto.arima(timeser_train_Quantity_Consumer_EU)
autoarima_Consumer_EU_quantity

## After compairing the results , the manual model does pretty well compare to
## auto.arima  fit


########### Modelling the data  aggr_Consumer_APAC



# For  sales
train_sales_Consumer_APAC <- subset(aggr_Consumer_APAC[,c(1,4)] , months <=42)
test_sales_Consumer_APAC <- subset(aggr_Consumer_APAC[,c(1,4)] ,months >42)

timeser_train_sales_Consumer_APAC <- ts(train_sales_Consumer_APAC[,ycol_sales[example]])
# Plotting time series
plot(timeser_train_sales_Consumer_APAC )

# Quantity data for Consumer_APAC

train_Quantity_Consumer_APAC <- subset(aggr_Consumer_APAC[,c(1,2)] , months <=42)
test_Quantity_Consumer_APAC <- subset(aggr_Consumer_APAC[,c(1,2)] ,months >42)

timeser_train_Quantity_Consumer_APAC <- ts(train_Quantity_Consumer_APAC[,ycol_quantity[example]])
# Plotting time series
plot(timeser_train_Quantity_Consumer_APAC )


### Smoothing and modelling the  series of quantity of Consumer_APAC

smoothedseries_Consumer_APAC_quantity <- smoothen_series(timeser_train_Quantity_Consumer_APAC,1)
## Checking the smoothen time  series 
lines(smoothedseries_Consumer_APAC_quantity, col="blue", lwd=2)

## It shows shape of sinosodal wave with  wider amplitude showing increasing
#  trend ,hence additive linear model can be  fit with some tweaks in  the
#  amplitude values

timevals_Consumer_APAC <- train_Quantity_Consumer_APAC[[xcol_months[example]]]
## Fitting the linear regression model 

plot(timeser_train_Quantity_Consumer_APAC)
lines(smoothedseries_Consumer_APAC_quantity, col="blue", lwd=2)

# Modelling the  seasonality and trend
lmfit_Consumer_APAC_quantity <- lm(train_Quantity_Consumer_APAC$Quantity ~ 
                                sin(0.5*train_Quantity_Consumer_APAC$months) * poly(train_Quantity_Consumer_APAC$months,2) 
                                + cos(0.5*train_Quantity_Consumer_APAC$months) * poly(train_Quantity_Consumer_APAC$months,2) 
                                +train_Quantity_Consumer_APAC$months, data=train_Quantity_Consumer_APAC)
trend_Consumer_APAC_quantity <- predict(lmfit_Consumer_APAC_quantity, data.frame(x=timevals_Consumer_APAC))
lines(timevals_Consumer_APAC, trend_Consumer_APAC_quantity, col='red', lwd=2)


## Checking the  residue for pure noise 

resi_Consumer_APAC_quantity <- timeser_train_Quantity_Consumer_APAC - trend_Consumer_APAC_quantity
plot(resi_Consumer_APAC_quantity, col='red')
acf(resi_Consumer_APAC_quantity)
acf(resi_Consumer_APAC_quantity, type="partial")
armafit_Consumer_APAC_quantity <- auto.arima(resi_Consumer_APAC_quantity)

# ARIMA(0,0,0) with zero mean for armafit_Consumer_APAC_quantity

#tsdiag(armafit_Consumer_APAC_quantity)

library(tseries)

## adf test shows that the  resi_Consumer_EU_quantity is stationary
## with p = 0.01 , hence rejecting the null hypothesis
adf.test(resi_Consumer_APAC_quantity,alternative="stationary")
# The histogram shows the normal distribtion showing the  stationary data 
hist(resi_Consumer_APAC_quantity,probability = TRUE)
lines(density(resi_Consumer_APAC_quantity,adjust = 2),col="blue",lwd=2)


## Finding the  auto.arima fit direclty into the data set timeser_sales_Consumer_EU
autoarima_Consumer_APAC_quantity <- auto.arima(timeser_train_Quantity_Consumer_APAC)
autoarima_Consumer_APAC_quantity
## Auto arima direcly applyting on the data set shows 

#ARIMA(0,1,0)                    

#sigma^2 estimated as 25366:  log likelihood=-266.07
#AIC=534.14   AICc=534.24   BIC=535.85



###################


### Smoothing and modelling the  series of sales of Consumer_APAC
## DATA ; train_sales_Consumer_APAC , TS: timeser_train_sales_Consumer_APAC
plot(timeser_train_sales_Consumer_APAC)
smoothedseries_Consumer_APAC_sales <- smoothen_series(timeser_train_sales_Consumer_APAC,2)
## Checking the smoothen time  series 
lines(smoothedseries_Consumer_APAC_sales, col="blue", lwd=2)

## It shows shape of sinosodal wave with  wider amplitude showing increasing
#  trend ,hence additive linear model can be  fit with some tweaks in  the
#  amplitude values

timevals_Consumer_APAC <- train_sales_Consumer_APAC[[xcol_months[example]]]
## Fitting the linear regression model 

plot(timeser_train_sales_Consumer_APAC)
lines(smoothedseries_Consumer_APAC_sales, col="blue", lwd=2)

# Modelling the  seasonality and trend
lmfit_Consumer_APAC_sales <- lm(train_sales_Consumer_APAC$Sales ~ 
                                     sin(0.5*train_sales_Consumer_APAC$months) * poly(train_Quantity_Consumer_APAC$months,2) 
                                   + cos(0.5*train_sales_Consumer_APAC$months) * poly(train_Quantity_Consumer_APAC$months,2) 
                                   +train_sales_Consumer_APAC$months, data=train_sales_Consumer_APAC)
trend_Consumer_APAC_sales <- predict(lmfit_Consumer_APAC_sales, data.frame(x=timevals_Consumer_APAC))
lines(timevals_Consumer_APAC, trend_Consumer_APAC_sales, col='red', lwd=2)


## Checking the  residue for pure noise 

resi_Consumer_APAC_sales <- timeser_train_sales_Consumer_APAC - trend_Consumer_APAC_sales
plot(resi_Consumer_APAC_sales, col='red')
acf(resi_Consumer_APAC_sales)
acf(resi_Consumer_APAC_sales, type="partial")
armafit_Consumer_APAC_sales <- auto.arima(resi_Consumer_APAC_sales)

# ARIMA(0,0,0) with zero mean for armafit_Consumer_APAC_sales

#tsdiag(armafit_Consumer_APAC_quantity)

library(tseries)

## adf test shows that the  resi_Consumer_EU_quantity is stationary
## with p = 0.01 , hence rejecting the null hypothesis
adf.test(resi_Consumer_APAC_sales,alternative="stationary")
# The histogram shows the normal distribtion showing the  stationary data 
hist(resi_Consumer_APAC_sales,probability = TRUE)
lines(density(resi_Consumer_APAC_sales,adjust = 2),col="blue",lwd=2)



## Finding the  auto.arima fit directly into the data set timeser_sales_Consumer_APAC
autoarima_Consumer_APAC_sales <- auto.arima(timeser_train_sales_Consumer_APAC)
autoarima_Consumer_APAC_sales


########################### Modelling the data set  aggr_Consumer_LATAM #########


#plot(timeser_quantity_Consumer_EU)
# Preparing data for train and test
# Sales data for Consumer_EU

train_sales_Consumer_LATAM <- subset(aggr_Consumer_LATAM[,c(1,4)] , months <=42)
test_sales_Consumer_LATAM <- subset(aggr_Consumer_LATAM[,c(1,4)] ,months >42)

timeser_train_sales_Consumer_LATAM <- ts(train_sales_Consumer_LATAM[,ycol_sales[example]])
# Plotting time series
plot(timeser_train_sales_Consumer_LATAM )

# Quantity data for Consumer_EU

train_Quantity_Consumer_LATAM <- subset(aggr_Consumer_LATAM[,c(1,2)] , months <=42)
test_Quantity_Consumer_LATAM <- subset(aggr_Consumer_LATAM[,c(1,2)] ,months >42)

timeser_train_Quantity_Consumer_LATAM <- ts(train_Quantity_Consumer_LATAM[,ycol_quantity[example]])
# Plotting time series
plot(timeser_train_Quantity_Consumer_LATAM )


### Smoothing and modelling the  series of sales of Consumer_LATAM
## DATA ; train_sales_Consumer_LATAM , TS: timeser_train_sales_Consumer_LATAM
plot(timeser_train_sales_Consumer_LATAM)
smoothedseries_Consumer_LATAM_sales <- smoothen_series(timeser_train_sales_Consumer_LATAM,1)
## Checking the smoothen time  series 
lines(smoothedseries_Consumer_LATAM_sales, col="blue", lwd=2)

## It shows shape of sinosodal wave with  wider amplitude showing increasing
#  trend ,hence additive linear model can be  fit with some tweaks in  the
#  amplitude values

timevals_Consumer_LATAM <- train_sales_Consumer_LATAM[[xcol_months[example]]]
## Fitting the linear regression model 

plot(timeser_train_sales_Consumer_LATAM)
lines(smoothedseries_Consumer_LATAM_sales, col="blue", lwd=2)

# Modelling the  seasonality and trend
lmfit_Consumer_LATAM_sales <- lm(train_sales_Consumer_LATAM$Sales ~ 
                                  sin(0.6*train_sales_Consumer_LATAM$months) * poly(train_Quantity_Consumer_APAC$months,2) 
                                + cos(0.6*train_sales_Consumer_LATAM$months) * poly(train_Quantity_Consumer_APAC$months,2) 
                                +train_sales_Consumer_LATAM$months, data=train_sales_Consumer_LATAM)
trend_Consumer_LATAM_sales <- predict(lmfit_Consumer_LATAM_sales, data.frame(x=timevals_Consumer_APAC))
lines(timevals_Consumer_LATAM, trend_Consumer_LATAM_sales, col='red', lwd=2)


## Checking the  residue for pure noise 

resi_Consumer_LATAM_sales <- timeser_train_sales_Consumer_LATAM - trend_Consumer_LATAM_sales
plot(resi_Consumer_LATAM_sales, col='red')
acf(resi_Consumer_LATAM_sales)
acf(resi_Consumer_LATAM_sales, type="partial")
armafit_Consumer_LATAM_sales <- auto.arima(resi_Consumer_LATAM_sales)

# ARIMA(0,0,0) with zero mean for armafit_Consumer_LATAM_sales

#tsdiag(armafit_Consumer_APAC_quantity)

library(tseries)

## adf test shows that the  resi_Consumer_EU_quantity is stationary
## with p = 0.01 , hence rejecting the null hypothesis
adf.test(resi_Consumer_LATAM_sales,alternative="stationary")
# The histogram shows the normal distribtion showing the  stationary data 
hist(resi_Consumer_LATAM_sales,probability = TRUE)
lines(density(resi_Consumer_LATAM_sales,adjust = 2),col="blue",lwd=2)


## Finding the  auto.arima fit directly into the data set timeser_sales_Consumer_APAC
autoarima_Consumer_LATAM_sales <- auto.arima(timeser_train_sales_Consumer_LATAM)
autoarima_Consumer_LATAM_sales
tsdiag(autoarima_Consumer_LATAM_sales)



############ For  Consumer_LATAM_Quantity




### Smoothing and modelling the  series of sales of Consumer_LATAM
## DATA ; train_Quantity_Consumer_LATAM , TS: timeser_train_Quantity_Consumer_LATAM
plot(timeser_train_Quantity_Consumer_LATAM)
smoothedseries_Consumer_LATAM_Quantity <- smoothen_series(timeser_train_Quantity_Consumer_LATAM,1)
## Checking the smoothen time  series 
lines(smoothedseries_Consumer_LATAM_Quantity, col="blue", lwd=2)

## It shows shape of sinosodal wave with  wider amplitude showing increasing
#  trend ,hence additive linear model can be  fit with some tweaks in  the
#  amplitude values

timevals_Consumer_LATAM <- train_Quantity_Consumer_LATAM[[xcol_months[example]]]
## Fitting the linear regression model 

plot(timeser_train_Quantity_Consumer_LATAM)
lines(smoothedseries_Consumer_LATAM_Quantity, col="blue", lwd=2)

# Modelling the  seasonality and trend
lmfit_Consumer_LATAM_Quantity <- lm(train_Quantity_Consumer_LATAM$Quantity ~ 
                                   sin(0.7*train_Quantity_Consumer_LATAM$months) * poly(train_Quantity_Consumer_LATAM$months,3) 
                                 + cos(0.7*train_Quantity_Consumer_LATAM$months) * poly(train_Quantity_Consumer_LATAM$months,3) 
                                 +train_Quantity_Consumer_LATAM$months, data=train_Quantity_Consumer_LATAM)
trend_Consumer_LATAM_Quantity <- predict(lmfit_Consumer_LATAM_Quantity, data.frame(x=timevals_Consumer_APAC))
lines(timevals_Consumer_LATAM, trend_Consumer_LATAM_Quantity, col='red', lwd=2)


## Checking the  residue for pure noise 

resi_Consumer_LATAM_Quantity <- timeser_train_Quantity_Consumer_LATAM - trend_Consumer_LATAM_Quantity
plot(resi_Consumer_LATAM_Quantity, col='red')
acf(resi_Consumer_LATAM_Quantity)
acf(resi_Consumer_LATAM_Quantity, type="partial")
armafit_Consumer_LATAM_Quantity <- auto.arima(resi_Consumer_LATAM_Quantity)

# ARIMA(0,0,0) with zero mean for armafit_Consumer_LATAM_Quantity

#tsdiag(armafit_Consumer_APAC_quantity)

library(tseries)

## adf test shows that the  resi_Consumer_EU_quantity is stationary
## with p = 0.01 , hence rejecting the null hypothesis
adf.test(resi_Consumer_LATAM_Quantity,alternative="stationary")
# The histogram shows the normal distribtion showing the  stationary data 
hist(resi_Consumer_LATAM_Quantity,probability = TRUE)
lines(density(resi_Consumer_LATAM_Quantity,adjust = 2),col="blue",lwd=2)


## Finding the  auto.arima fit directly into the data set timeser_sales_Consumer_APAC
autoarima_Consumer_LATAM_Quantity <- auto.arima(timeser_train_Quantity_Consumer_LATAM)
autoarima_Consumer_LATAM_Quantity
tsdiag(autoarima_Consumer_LATAM_sales)



######################### Modelling the  aggr_Corporate_APAC


# For  sales
train_sales_Corporate_APAC <- subset(aggr_Corporate_APAC[,c(1,4)] , months <=42)
test_sales_Corporate_APAC <- subset(aggr_Corporate_APAC[,c(1,4)] ,months >42)

timeser_train_sales_Corporate_APAC <- ts(train_sales_Corporate_APAC[,ycol_sales[example]])
# Plotting time series
plot(timeser_train_sales_Corporate_APAC )

# Quantity data for Consumer_APAC

train_Quantity_Corporate_APAC <- subset(aggr_Corporate_APAC[,c(1,2)] , months <=42)
test_Quantity_Corporate_APAC <- subset(aggr_Corporate_APAC[,c(1,2)] ,months >42)

timeser_train_Quantity_Corporate_APAC <- ts(train_Quantity_Corporate_APAC[,ycol_quantity[example]])
# Plotting time series
plot(timeser_train_Quantity_Corporate_APAC )


### Smoothing and modelling the  series of quantity of Corporate_APAC

smoothedseries_Corporate_APAC_quantity <- smoothen_series(timeser_train_Quantity_Corporate_APAC,1)
## Checking the smoothen time  series 
lines(smoothedseries_Corporate_APAC_quantity, col="blue", lwd=2)

## It shows shape of sinosodal wave with  wider amplitude showing increasing
#  trend ,hence additive linear model can be  fit with some tweaks in  the
#  amplitude values

timevals_Corporate_APAC <- train_Quantity_Corporate_APAC[[xcol_months[example]]]
## Fitting the linear regression model 

plot(timeser_train_Quantity_Corporate_APAC)
lines(smoothedseries_Corporate_APAC_quantity, col="blue", lwd=2)

# Modelling the  seasonality and trend
lmfit_Corporate_APAC_quantity <- lm(train_Quantity_Corporate_APAC$Quantity ~ 
                                     sin(0.6*train_Quantity_Corporate_APAC$months) * poly(train_Quantity_Corporate_APAC$months,2) 
                                   + cos(0.6*train_Quantity_Corporate_APAC$months) * poly(train_Quantity_Corporate_APAC$months,2) 
                                   +train_Quantity_Corporate_APAC$months, data=train_Quantity_Corporate_APAC)
trend_Corporate_APAC_quantity <- predict(lmfit_Corporate_APAC_quantity, data.frame(x=timevals_Corporate_APAC))
lines(timevals_Corporate_APAC, trend_Corporate_APAC_quantity, col='red', lwd=2)


## Checking the  residue for pure noise 

resi_Corporate_APAC_quantity <- timeser_train_Quantity_Corporate_APAC - trend_Corporate_APAC_quantity
plot(resi_Corporate_APAC_quantity, col='red')
acf(resi_Corporate_APAC_quantity)
acf(resi_Corporate_APAC_quantity, type="partial")
armafit_Corporate_APAC_quantity <- auto.arima(resi_Corporate_APAC_quantity)

# ARIMA(0,0,0) with zero mean for armafit_Consumer_APAC_quantity

#tsdiag(armafit_Consumer_APAC_quantity)

library(tseries)

## adf test shows that the  resi_Consumer_EU_quantity is stationary
## with p = 0.01 , hence rejecting the null hypothesis
adf.test(resi_Corporate_APAC_quantity,alternative="stationary")
# The histogram shows the normal distribtion showing the  stationary data 
hist(resi_Corporate_APAC_quantity,probability = TRUE)
lines(density(resi_Corporate_APAC_quantity,adjust = 2),col="blue",lwd=2)


## Finding the  auto.arima fit direclty into the data set timeser_Quantity_Corporate_APAC
autoarima_Corporate_APAC_quantity <- auto.arima(timeser_train_Quantity_Corporate_APAC)
autoarima_Corporate_APAC_quantity



#### Modelling the sales data 
plot(timeser_train_sales_Corporate_APAC)
### Smoothing and modelling the  series of sales of Corporate_APAC
# Dataset : train_sales_Corporate_APAC , TS: timeser_train_sales_Corporate_APAC
smoothedseries_Corporate_APAC_sales <- smoothen_series(timeser_train_sales_Corporate_APAC,2)
## Checking the smoothen time  series 
lines(smoothedseries_Corporate_APAC_sales, col="blue", lwd=2)

## It shows shape of sinosodal wave with  wider amplitude showing increasing
#  trend ,hence additive linear model can be  fit with some tweaks in  the
#  amplitude values

timevals_Corporate_APAC <- train_sales_Corporate_APAC[[xcol_months[example]]]
## Fitting the linear regression model 

plot(timeser_train_sales_Corporate_APAC)
lines(smoothedseries_Corporate_APAC_sales, col="blue", lwd=2)

# Modelling the  seasonality and trend
lmfit_Corporate_APAC_sales <- lm(train_sales_Corporate_APAC$Sales ~ 
                                      sin(0.5*train_sales_Corporate_APAC$months) * poly(train_sales_Corporate_APAC$months,2) 
                                    + cos(0.5*train_sales_Corporate_APAC$months) * poly(train_sales_Corporate_APAC$months,2) 
                                    +train_sales_Corporate_APAC$months, data=train_sales_Corporate_APAC)
trend_Corporate_APAC_sales <- predict(lmfit_Corporate_APAC_sales, data.frame(x=timevals_Corporate_APAC))
lines(timevals_Corporate_APAC, trend_Corporate_APAC_sales, col='red', lwd=2)


## Checking the  residue for pure noise 

resi_Corporate_APAC_sales <- timeser_train_sales_Corporate_APAC - trend_Corporate_APAC_sales
plot(resi_Corporate_APAC_sales, col='red')
acf(resi_Corporate_APAC_sales)
acf(resi_Corporate_APAC_sales, type="partial")
armafit_Corporate_APAC_sales <- auto.arima(resi_Corporate_APAC_sales)

# ARIMA(0,0,0) with zero mean for armafit_Corporate_APAC_sales



library(tseries)

## adf test shows that the  resi_Consumer_EU_quantity is stationary
## with p = 0.01 , hence rejecting the null hypothesis
adf.test(resi_Corporate_APAC_quantity,alternative="stationary")
# The histogram shows the normal distribtion showing the  stationary data 
hist(resi_Corporate_APAC_sales,probability = TRUE)
lines(density(resi_Corporate_APAC_sales,adjust = 2),col="blue",lwd=2)


### Finding the  auto.arima fit direclty into the data set timeser_sales_Corporate_APAC

autoarima_Corporate_APAC_sales <-  auto.arima(timeser_train_sales_Corporate_APAC)
autoarima_Corporate_APAC_sales


## Finding the  auto.arima fit direclty into the data set timeser_Quantity_Corporate_APAC
autoarima_Corporate_APAC_quantity <- auto.arima(timeser_train_Quantity_Corporate_APAC)
autoarima_Corporate_APAC_quantity


##################  Modelling for the aggr_Corporate_EU

# For  sales
train_sales_Corporate_EU <- subset(aggr_Corporate_EU[,c(1,4)] , months <=42)
test_sales_Corporate_EU <- subset(aggr_Corporate_EU[,c(1,4)] ,months >42)

timeser_train_sales_Corporate_EU <- ts(train_sales_Corporate_EU[,ycol_sales[example]])
timeser_test_sales_Corporate_EU <- ts(test_sales_Corporate_EU[,ycol_sales[example]])
# Plotting time series
plot(timeser_train_sales_Corporate_EU )

# Quantity data for Consumer_APAC

train_Quantity_Corporate_EU <- subset(aggr_Corporate_EU[,c(1,2)] , months <=42)
test_Quantity_Corporate_EU <- subset(aggr_Corporate_EU[,c(1,2)] ,months >42)

timeser_train_Quantity_Corporate_EU <- ts(train_Quantity_Corporate_EU[,ycol_quantity[example]])
timeser_test_Quantity_Corporate_EU <- ts(test_Quantity_Corporate_EU[,ycol_quantity[example]])
# Plotting time series
plot(timeser_train_Quantity_Corporate_EU )


### Smoothing and modelling the  series of quantity of Corporate_EU

smoothedseries_Corporate_EU_quantity <- smoothen_series(timeser_train_Quantity_Corporate_EU,2)
## Checking the smoothen time  series 
lines(smoothedseries_Corporate_EU_quantity, col="blue", lwd=2)

## It shows shape of sinosodal wave with  wider amplitude showing increasing
#  trend ,hence additive linear model can be  fit with some tweaks in  the
#  amplitude values

timevals_Corporate_EU <- train_Quantity_Corporate_EU[[xcol_months[example]]]
## Fitting the linear regression model 

plot(timeser_train_Quantity_Corporate_EU)
lines(smoothedseries_Corporate_EU_quantity, col="blue", lwd=2)


# Modelling the  seasonality and trend
lmfit_Corporate_EU_quantity <- lm(train_Quantity_Corporate_EU$Quantity ~ 
                                      sin(0.6*train_Quantity_Corporate_EU$months) * poly(train_Quantity_Corporate_EU$months,2) 
                                    + cos(0.6*train_Quantity_Corporate_EU$months) * poly(train_Quantity_Corporate_EU$months,2) 
                                    +train_Quantity_Corporate_EU$months, data=train_Quantity_Corporate_EU)
trend_Corporate_EU_quantity <- predict(lmfit_Corporate_EU_quantity, data.frame(x=timevals_Corporate_EU))
lines(timevals_Corporate_EU, trend_Corporate_EU_quantity, col='red', lwd=2)


## Checking the  residue for pure noise 

resi_Corporate_EU_quantity <- timeser_train_Quantity_Corporate_EU - trend_Corporate_EU_quantity
plot(resi_Corporate_EU_quantity, col='red')
acf(resi_Corporate_EU_quantity)
acf(resi_Corporate_EU_quantity, type="partial")
armafit_Corporate_EU_quantity <- auto.arima(resi_Corporate_EU_quantity)

# ARIMA(0,0,1) with zero mean for armafit_Consumer_EU_quantity
# After seeing the AC,PACF the model seems to be doing well
#tsdiag(armafit_Consumer_APAC_quantity)

library(tseries)

## adf test shows that the  resi_Consumer_EU_quantity is stationary
## with p = 0.019 , hence rejecting the null hypothesis
adf.test(resi_Corporate_EU_quantity,alternative="stationary")
# The histogram shows the normal distribtion showing the  stationary data 
hist(resi_Corporate_EU_quantity,probability = TRUE)
lines(density(resi_Corporate_EU_quantity,adjust = 2),col="blue",lwd=2)


## Finding the  auto.arima fit direclty into the data set timeser_Quantity_Corporate_APAC
autoarima_Corporate_EU_quantity <- auto.arima(timeser_train_Quantity_Corporate_EU)
autoarima_Corporate_EU_quantity



############### Modelling the sales data of Corporate_EU
# Dataset:  train_sales_Corporate_EU ,TS: timeser_train_sales_Corporate_EU

plot(timeser_train_sales_Corporate_EU)
### Smoothing and modelling the  series of sales of Corporate_APAC
# Dataset : train_sales_Corporate_APAC , TS: timeser_train_sales_Corporate_APAC
smoothedseries_Corporate_EU_sales <- smoothen_series(timeser_train_sales_Corporate_EU,1)
## Checking the smoothen time  series 
lines(smoothedseries_Corporate_EU_sales, col="blue", lwd=2)

## It shows shape of sinosodal wave with  wider amplitude showing increasing
#  trend ,hence additive linear model can be  fit with some tweaks in  the
#  amplitude values

timevals_Corporate_EU <- train_sales_Corporate_EU[[xcol_months[example]]]
## Fitting the linear regression model 

plot(timeser_train_sales_Corporate_EU)
lines(smoothedseries_Corporate_EU_sales, col="blue", lwd=2)

# Modelling the  seasonality and trend
lmfit_Corporate_EU_sales <- lm(Sales ~ 
                                   sin(0.6*train_sales_Corporate_EU$months) * poly(train_sales_Corporate_EU$months,2) 
                                 + cos(0.6*train_sales_Corporate_EU$months) * poly(train_sales_Corporate_EU$months,2) 
                                 +train_sales_Corporate_EU$months, data=train_sales_Corporate_EU)
trend_Corporate_EU_sales <- predict(lmfit_Corporate_EU_sales, data.frame(x=timevals_Corporate_EU))
lines(timevals_Corporate_EU, trend_Corporate_EU_sales, col='red', lwd=2)


## Checking the  residue for pure noise 

resi_Corporate_EU_sales <- timeser_train_sales_Corporate_EU - trend_Corporate_EU_sales
plot(resi_Corporate_EU_sales, col='red')
acf(resi_Corporate_EU_sales)
acf(resi_Corporate_EU_sales, type="partial")
armafit_Corporate_EU_sales <- auto.arima(resi_Corporate_EU_sales)

# ARIMA(0,0,1) with zero mean for armafit_Corporate_EU_sales

#tsdiag(armafit_Consumer_APAC_quantity)

library(tseries)

## adf test shows that the  resi_Consumer_EU_quantity is stationary
## with p = 0.01 , hence rejecting the null hypothesis
adf.test(resi_Corporate_EU_sales,alternative="stationary")
# The histogram shows the normal distribtion showing the  stationary data 
hist(resi_Corporate_EU_sales,probability = TRUE)
lines(density(resi_Corporate_EU_sales,adjust = 2),col="blue",lwd=2)


## Finding the  auto.arima fit direclty into the data set timeser_Quantity_Corporate_APAC
autoarima_Corporate_EU_sales <- auto.arima(timeser_train_sales_Corporate_EU)
autoarima_Corporate_EU_sales


############# CHECKPOINT 3 - MODEL EVALUATIONS ########

############    MAPE evaluation for ARIMA MODEL GENERATED   #########################
#### NOTE TO EVALUATOR : The R shows error while  forecating or predicitng the  regression on a  manually generated model. 
#### Please take a look on this issue , Nobody in discussion  forum able to get this, We will not be able to predict using liner regression which is way better than
###  ARIMA model in terms of PACF,ACF in the results we have got , so the forecasting 
### is done based on the auto.arima() model


#1. aggr_Consumer_EU
# Sales
test_sales_Consumer_EU
# ARIMA Model (2,1,0)
autoarima_Consumer_EU_sales 
# Forecast
autoarima_Consumer_EU_sales_forecast <- forecast(autoarima_Consumer_EU_sales,h=6)
accuracy(autoarima_Consumer_EU_sales_forecast$mean,test_sales_Consumer_EU$Sales)

#MAPE: 28.9226

plot(autoarima_Consumer_EU_sales_forecast)


library(ggplot2)
curve(dnorm(x, mean=mean(foo), sd=sd(foo)), add=TRUE)
### Quantity

test_Quantity_Consumer_EU
# ARIMA (2,1,0) Model
autoarima_Consumer_EU_quantity

autoarima_Consumer_EU_quantity_forecast <- forecast(autoarima_Consumer_EU_quantity,h=6)
accuracy(autoarima_Consumer_EU_quantity_forecast$mean,test_Quantity_Consumer_EU$Quantity)
# MAPE: 30.13319
plot(autoarima_Consumer_EU_quantity_forecast)

#2. aggr_Consumer_APAC

# Sales
test_sales_Consumer_APAC
# Model (0,1,1)
autoarima_Consumer_APAC_sales

autoarima_Consumer_APAC_sales_forecast <- forecast(autoarima_Consumer_APAC_sales,h=6)
accuracy(autoarima_Consumer_APAC_sales_forecast$mean,test_sales_Consumer_APAC$Sales)
# MAPE: 27.68952

plot(autoarima_Consumer_APAC_sales_forecast)

# Quantity

test_Quantity_Consumer_APAC
# ARIMA Model (0,1,0)
autoarima_Consumer_APAC_quantity

autoarima_Consumer_APAC_quantity_forecast <- forecast(autoarima_Consumer_APAC_quantity,h=6)
accuracy(autoarima_Consumer_APAC_quantity_forecast$mean,test_Quantity_Consumer_APAC$Quantity)
# MAPE: 26.24458
plot(autoarima_Consumer_APAC_quantity_forecast)


#3. aggr_Consumer_LATAM

# Sales
test_sales_Consumer_LATAM
# ARIMA (0,1,0)
autoarima_Consumer_LATAM_sales

autoarima_Consumer_LATAM_sales_forecast <- forecast(autoarima_Consumer_LATAM_sales,h=6)
accuracy(autoarima_Consumer_LATAM_sales_forecast$mean,test_sales_Consumer_LATAM$Sales)
# MAPE: 33.96611
plot(autoarima_Consumer_LATAM_sales_forecast)

# Quantity

test_Quantity_Consumer_LATAM
# ARIMA Model( 0,1,0)
autoarima_Consumer_LATAM_Quantity

autoarima_Consumer_LATAM_quantity_forecast <- forecast(autoarima_Consumer_LATAM_Quantity,h=6)
accuracy(autoarima_Consumer_LATAM_quantity_forecast$mean,test_Quantity_Consumer_LATAM$Quantity)
# MAPE: 47.69576
plot(autoarima_Consumer_LATAM_quantity_forecast)

#4. aggr_Corporate_APAC

# Sales
test_sales_Corporate_APAC
# ARIMA Model (0,1,1)
autoarima_Corporate_APAC_sales

autoarima_Corporate_APAC_sales_forecast <- forecast(autoarima_Corporate_APAC_sales,h=6)
accuracy(autoarima_Corporate_APAC_sales_forecast$mean,test_sales_Corporate_APAC$Sales)
# MAPE : 27.97408
plot(autoarima_Corporate_APAC_sales_forecast)
# Quantity

test_Quantity_Corporate_APAC
# ARIMA Model (0,1,1)
autoarima_Corporate_APAC_quantity

autoarima_Corporate_APAC_quantity_forecast <- forecast(autoarima_Corporate_APAC_quantity,h=6)
accuracy(autoarima_Corporate_APAC_quantity_forecast$mean,test_Quantity_Corporate_APAC$Quantity)
# MAPE : 24.13219
plot(autoarima_Corporate_APAC_quantity_forecast)
#5. aggr_Corporate_EU

# Sales
test_sales_Corporate_EU

# ARIMA Model (2,1,0)
autoarima_Corporate_EU_sales

autoarima_Corporate_EU_sales_forecast <- forecast(autoarima_Corporate_EU_sales,h=6)
accuracy(autoarima_Corporate_EU_sales_forecast$mean,test_sales_Corporate_EU$Sales)
# MAPE : 36.35092
plot(autoarima_Corporate_EU_sales_forecast)

# Quantity

test_Quantity_Corporate_EU
# ARIMA Model (2,1,0)
autoarima_Corporate_EU_quantity

autoarima_Corporate_EU_quantity_forecast <- forecast(autoarima_Corporate_EU_quantity,h=6)
accuracy(autoarima_Corporate_EU_quantity_forecast$mean,test_Quantity_Corporate_EU$Quantity)
# MAPE : 47.54968

plot(autoarima_Corporate_EU_quantity_forecast)



############# Forecasting  for the next 6 months ####

## We will try to  forcaste for 49 - 54 months by applying the auto.arima to
## to  full data set 48 months as so  far we have applied it only 42 months
## and validate on 6 months however the objective is to forcast resource and
# revenue  for next 6 months , so if we include the test+train data and then 
## try to build the model then we can forcaste much better

## For aggr_Consumer_EU
# Sales
df_Consumer_EU_sales <-   data.frame(aggr_Consumer_EU[,c(1,4)])
ts_aggr_Consumer_EU_sales <- ts(df_Consumer_EU_sales[,ycol_sales[example]])

arima_full_Consumer_EU_sales   <-  auto.arima(ts_aggr_Consumer_EU_sales)
arima_full_Consumer_EU_sales_forecast <- forecast(arima_full_Consumer_EU_sales,h=6)
plot(arima_full_Consumer_EU_sales_forecast)

## Quantity

df_Consumer_EU_quantity <-   data.frame(aggr_Consumer_EU[,c(1,2)])
ts_aggr_Consumer_EU_quantity <- ts(df_Consumer_EU_quantity[,ycol_quantity[example]])

arima_full_Consumer_EU_quantity   <-  auto.arima(ts_aggr_Consumer_EU_quantity)
arima_full_Consumer_EU_quantity_forecast <- forecast(arima_full_Consumer_EU_quantity,h=6)
plot(arima_full_Consumer_EU_quantity_forecast)

## aggr_Consumer_APAC

# Sales
df_Consumer_APAC_sales <-   data.frame(aggr_Consumer_APAC[,c(1,4)])
ts_aggr_Consumer_APAC_sales <- ts(df_Consumer_APAC_sales[,ycol_sales[example]])

arima_full_Consumer_APAC_sales   <-  auto.arima(ts_aggr_Consumer_APAC_sales)
arima_full_Consumer_APAC_sales_forecast <- forecast(arima_full_Consumer_APAC_sales,h=6)
plot(arima_full_Consumer_APAC_sales_forecast)

## Quantity

df_Consumer_APAC_quantity <-   data.frame(aggr_Consumer_APAC[,c(1,2)])
ts_aggr_Consumer_APAC_quantity <- ts(df_Consumer_APAC_quantity[,ycol_quantity[example]])

arima_full_Consumer_APAC_quantity   <-  auto.arima(ts_aggr_Consumer_APAC_quantity)
arima_full_Consumer_APAC_quantity_forecast <- forecast(arima_full_Consumer_APAC_quantity,h=6)
plot(arima_full_Consumer_APAC_quantity_forecast)


### aggr_Consumer_LATAM

## Sales
df_Consumer_LATAM_sales <-   data.frame(aggr_Consumer_LATAM[,c(1,4)])
ts_aggr_Consumer_LATAM_sales <- ts(df_Consumer_LATAM_sales[,ycol_sales[example]])

arima_full_Consumer_LATAM_sales   <-  auto.arima(ts_aggr_Consumer_LATAM_sales)
arima_full_Consumer_LATAM_sales_forecast <- forecast(arima_full_Consumer_LATAM_sales,h=6)
plot(arima_full_Consumer_LATAM_sales_forecast)

## Quantity

df_Consumer_LATAM_quantity <-   data.frame(aggr_Consumer_LATAM[,c(1,2)])
ts_aggr_Consumer_LATAM_quantity <- ts(df_Consumer_LATAM_quantity[,ycol_quantity[example]])

arima_full_Consumer_LATAM_quantity   <-  auto.arima(ts_aggr_Consumer_LATAM_quantity)
arima_full_Consumer_LATAM_quantity_forecast <- forecast(arima_full_Consumer_LATAM_quantity,h=6)
plot(arima_full_Consumer_LATAM_quantity_forecast)


## For aggr_Corporate_APAC

## Sales
df_Corporate_APAC_sales <-   data.frame(aggr_Corporate_APAC[,c(1,4)])
ts_aggr_Corporate_APAC_sales <- ts(df_Corporate_APAC_sales[,ycol_sales[example]])

arima_full_Corporate_APAC_sales   <-  auto.arima(ts_aggr_Corporate_APAC_sales)
arima_full_Corporate_APAC_sales_forecast <- forecast(arima_full_Corporate_APAC_sales,h=6)
plot(arima_full_Corporate_APAC_sales_forecast)

## Quantity

df_Corporate_APAC_quantity <-   data.frame(aggr_Corporate_APAC[,c(1,2)])
ts_aggr_Corporate_APAC_quantity <- ts(df_Corporate_APAC_quantity[,ycol_quantity[example]])

arima_full_Corporate_APAC_quantity   <-  auto.arima(ts_aggr_Corporate_APAC_quantity)
arima_full_Corporate_APAC_quantity_forecast <- forecast(arima_full_Corporate_APAC_quantity,h=6)
plot(arima_full_Corporate_APAC_quantity_forecast)


## For aggr_Corporate_EU


## Sales
df_Corporate_EU_sales <-   data.frame(aggr_Corporate_EU[,c(1,4)])
ts_aggr_Corporate_EU_sales <- ts(df_Corporate_EU_sales[,ycol_sales[example]])

arima_full_Corporate_EU_sales   <-  auto.arima(ts_aggr_Corporate_EU_sales)
arima_full_Corporate_EU_sales_forecast <- forecast(arima_full_Corporate_EU_sales,h=6)
plot(arima_full_Corporate_EU_sales_forecast)

## Quantity

df_Corporate_EU_quantity <-   data.frame(aggr_Corporate_EU[,c(1,2)])
ts_aggr_Corporate_EU_quantity <- ts(df_Corporate_EU_quantity[,ycol_quantity[example]])

arima_full_Corporate_EU_quantity   <-  auto.arima(ts_aggr_Corporate_EU_quantity)
arima_full_Corporate_EU_quantity_forecast <- forecast(arima_full_Corporate_EU_quantity,h=6)
plot(arima_full_Corporate_EU_quantity_forecast)


###############################  CASE STUDY CODE ENDS######################################
