###############LOGISTIC REGRESSION STUDY#############


##  SETTING WORKING DIRECTORY
setwd("D:/PGDDA/R DOWNLOAD/ASSIGNMENTS/LOGISTIC REGRESSION STUDY")

# Download the data set as german_credit
german_credit <- read.csv("german.csv", stringsAsFactors = FALSE)

#  Data Understanding and Data Exploration



### DATA UNDERSTANDING 
str(german_credit)

summary(german_credit)
library(ggplot2)
# Credit Amount


boxplot(german_credit$Credit.amount)
boxplot.stats(german_credit$Credit.amount)

ggplot(data=default_customer_set, aes(x=Credit.amount))+geom_histogram()
# Exploratory Data Analysis for defaulting customers i.e. having Default_status =1 

default_customer_set <- subset(german_credit ,Default_status == 1)
## Univariate analysis of  variables , the plots  which shows some interesting  insights 
##  are described in the   docs.

#1. Age
summary(german_credit$Age.in.Years)


ggplot(data=default_customer_set, aes(x=factor(Age.in.Years)))+geom_bar()

ggplot(data=german_credit, aes(x=Age.in.Years))+geom_histogram()
boxplot(german_credit$Age.in.Years)

#3.Present Employment
summary(german_credit$Present.employment.since.)


ggplot(data=default_customer_set, aes(factor(Present.employment.since.)))+geom_bar()

#4 . Checking Account type

ggplot(data=default_customer_set, aes(factor(Status.of.existing.checking.account)))+geom_bar()


#5. Purpose

ggplot(data=default_customer_set, aes(factor(Purpose)))+geom_bar()


#6 .  Credit History

ggplot(data=default_customer_set, aes(factor(Credit.history)))+geom_bar()


# 7. Duration In month
ggplot(data=default_customer_set, aes(factor(Duration.in.month)))+geom_bar()


# 8. Job_status
ggplot(data=default_customer_set, aes(factor(Job_status)))+geom_bar()


#9. Savings.account.bonds
ggplot(data=default_customer_set, aes(factor(Savings.account.bonds)))+geom_bar()

# 10 . Installment.rate.in.percentage.of.disposable.income

ggplot(data=default_customer_set, aes(factor(Installment.rate.in.percentage.of.disposable.income)))+geom_bar()

# 11. Number.of.existing.credits.at.this.bank.
ggplot(data=default_customer_set, aes(factor(Number.of.existing.credits.at.this.bank.)))+geom_bar()


# 12. Personal.status.and.sex
ggplot(data=default_customer_set, aes(factor(Personal.status.and.sex)))+geom_bar()


# 13. Other.debtors...guarantors

ggplot(data=default_customer_set, aes(factor(Other.debtors...guarantors)))+geom_bar()




# Data prpeapartion and feature transformation

## Checking for '?' blank elements

'?' %in% german_credit   # Returns False

## Checking NAs in data set
sum(is.na(german_credit))  ## 0 hence no NA.


## Checking for outliers for Numrical variables

# Taking a look at numeric variables

str(german_credit)

#.1. Credit.amount , looks like only one continuous varibale qualifies for outlier treatment
 
credit_amount_outlier <-boxplot.stats(german_credit$Credit.amount)

# Got 72 values as outliers which .07 % of total observation hence we can discrad it

german_credit <- subset (german_credit ,Credit.amount <= 7882 )


month_outlier <- boxplot.stats(german_credit$Duration.in.month)
german_credit <- subset (german_credit ,Duration.in.month <= 42 )
#  german_credit_month Removing 44 observations as they are : 4% of total observation
## Transformation of variables into correct data type
## Age 
unique(german_credit$Age.in.Years)

colnames(german_credit)


german_credit$Status.of.existing.checking.account <- as.factor(german_credit$Status.of.existing.checking.account)
# unique(german_credit$Duration.in.month)
#  6 48 12 42 24 36 30 15  9 10  7 60 18 45 11 27  8 20 14 33 21 16  4 13 22 28  5 39 72 40
# We can do  binning of Duration of month
range(german_credit$Duration.in.month)  # 4 72

# We can ue the discretize  method
library(arules)

german_credit$Duration.in.month <- as.factor(german_credit$Duration.in.month)

levels(german_credit$Duration.in.month)
levels(german_credit$Duration.in.month)[1:9] <- "short Term"
levels(german_credit$Duration.in.month)[2:10] <- "Mid Term"
levels(german_credit$Duration.in.month)[3:10] <- "Long Term"
levels(german_credit$Duration.in.month)
## Age outliers

german_age <- boxplot.stats(german_credit$Age.in.Years)
german_credit <- subset (german_credit ,Age.in.Years <= 64 )

# Outlier are 2 % of the total observations , hence we can remove it 
levels(german_credit$Age.in.Years)
x <- german_credit[,13]
table(discretize(x, categories = 3))
#[19.0,37.7) [37.7,56.3) [56.3,75.0] 
#610         255          63 
german_credit$Age.in.Years <- as.factor(german_credit$Age.in.Years)

levels(german_credit$Age.in.Years)[1:17] <- "Young"
levels(german_credit$Age.in.Years)[2:16] <- "Mid Age"
levels(german_credit$Age.in.Years)[3:16] <- "Retire"
levels(german_credit$Age.in.Years)
str(german_credit)

german_credit$Status.of.existing.checking.account <- as.factor(german_credit$Status.of.existing.checking.account)
german_credit$Credit.history <- as.factor(german_credit$Credit.history)
german_credit$Purpose <- as.factor(german_credit$Purpose)
german_credit$Savings.account.bonds <- as.factor(german_credit$Savings.account.bonds)
german_credit$Present.employment.since. <- as.factor(german_credit$Present.employment.since.)
# No need to create factor as it i has to be taken numric ( As mentioned in data dictionary)
#german_credit$Installment.rate.in.percentage.of.disposable.income <- as.factor(german_credit$Installment.rate.in.percentage.of.disposable.income)
german_credit$Personal.status.and.sex <- as.factor(german_credit$Personal.status.and.sex)
german_credit$Other.debtors...guarantors <- as.factor(german_credit$Other.debtors...guarantors)
# No need to create factor as it i has to be taken numric ( As mentioned in data dictionary)
#german_credit$Present.residence.since <- as.factor(german_credit$Present.residence.since)
german_credit$Property <- as.factor(german_credit$Property)
german_credit$Other.installment.plans <- as.factor(german_credit$Other.installment.plans)
german_credit$Housing. <- as.factor(german_credit$Housing.)
german_credit$Job_status <- as.factor(german_credit$Job_status)
german_credit$Telephone. <- as.factor(german_credit$Telephone.)
german_credit$foreign.worker <- as.factor(german_credit$foreign.worker)
# No need to create factor as it i has to be taken numric ( As mentioned in data dictionary)
#german_credit$Number.of.existing.credits.at.this.bank. <- as.factor(german_credit$Number.of.existing.credits.at.this.bank.)
#german_credit$Default_status <- as.factor(german_credit$Default_status)
# No need to create factor as it i has to be taken numric ( As mentioned in data dictionary)
#german_credit$Number.of.people.being.liable.to.provide.maintenance.for. <- as.factor(german_credit$Number.of.people.being.liable.to.provide.maintenance.for.)

str(german_credit)



## Creating Dummy variables

## Variable Transformation

# Creating dummy for Status.of.existing.checking.account

dummy_1 <- data.frame(model.matrix( ~Status.of.existing.checking.account, data = german_credit))
dummy_1<-dummy_1[,-1]



dummy_2 <- data.frame(model.matrix( ~Duration.in.month, data =german_credit ))
dummy_2<-dummy_2[,-1]



dummy_3 <- data.frame(model.matrix( ~Credit.history, data =german_credit ))
dummy_3<-dummy_3[,-1]




dummy_4 <- data.frame(model.matrix( ~Purpose, data =german_credit ))
dummy_4<-dummy_4[,-1]


dummy_5 <- data.frame(model.matrix( ~Savings.account.bonds, data =german_credit ))
dummy_5<-dummy_5[,-1]

dummy_6 <- data.frame(model.matrix( ~Present.employment.since., data =german_credit ))
dummy_6<-dummy_6[,-1]
# No need to create dummy as it i has to be taken numric ( As mentioned in data dictionary)
#dummy_7 <- data.frame(model.matrix( ~Installment.rate.in.percentage.of.disposable.income, data =german_credit ))
#dummy_7<-dummy_7[,-1]

dummy_8 <- data.frame(model.matrix( ~Personal.status.and.sex, data =german_credit ))
dummy_8<-dummy_8[,-1]


dummy_9 <- data.frame(model.matrix( ~Other.debtors...guarantors, data =german_credit ))
dummy_9<-dummy_9[,-1]
# No need to create dummy as it i has to be taken numric ( As mentioned in data dictionary)
#dummy_10 <- data.frame(model.matrix( ~Present.residence.since, data =german_credit ))
#dummy_10<-dummy_10[,-1]

dummy_11 <- data.frame(model.matrix( ~Property, data =german_credit ))
dummy_11<-dummy_11[,-1]

dummy_12 <- data.frame(model.matrix( ~Age.in.Years, data =german_credit ))
dummy_12<-dummy_12[,-1]

dummy_13 <- data.frame(model.matrix( ~Other.installment.plans, data =german_credit ))
dummy_13<-dummy_13[,-1]

dummy_14 <- data.frame(model.matrix( ~Housing. , data =german_credit ))
dummy_14<-dummy_14[,-1]

# No need to create dummy as it i has to be taken numric ( As mentioned in data dictionary)
#dummy_15 <- data.frame(model.matrix( ~Number.of.existing.credits.at.this.bank., data =german_credit ))
#dummy_15<-dummy_15[,-1]

dummy_16 <- data.frame(model.matrix( ~Job_status, data =german_credit ))
dummy_16<-dummy_16[,-1]



levels(german_credit$Telephone.)
levels(german_credit$Telephone.)[1] <- "0"
levels(german_credit$Telephone.)[2] <- "1"
german_credit$Telephone. <- as.numeric(levels(german_credit$Telephone.))[1:2]
levels(german_credit$foreign.worker)
levels(german_credit$foreign.worker)[1] <- "0"
levels(german_credit$foreign.worker)[2] <-"1"
german_credit$foreign.worker <- as.numeric(levels(german_credit$foreign.worker))[1:2]

#german_credit$Default_status <- as.numeric(levels(german_credit$Default_status))[1:2]

str(german_credit)
############


library(arules)
# scaling the credit amount as its value is much higher than other variables
german_credit$Credit.amount <- scale(german_credit$Credit.amount)
################

# Without binning
#german_credit_1 <- cbind( german_credit[,c(2,5,8,11,13,16,18,19,20,21)] ,dummy_1,dummy_3,dummy_4 
#                     ,dummy_5,dummy_6,dummy_8,dummy_9,dummy_11,dummy_13,dummy_14,dummy_16)
                      
#With Binning
german_credit_1 <- cbind( german_credit[,c(5,8,11,16,18,19,20,21)] ,dummy_1,dummy_2,dummy_3,dummy_4 
                          ,dummy_5,dummy_6,dummy_8,dummy_9,dummy_11,dummy_12,dummy_13,dummy_14,dummy_16)



str(german_credit_1)

#install.packages("caTools")
library(caTools)
set.seed(100)
split_german = sample.split(german_credit_1$Default_status, SplitRatio = 0.7)
table(split_german)
german_train = german_credit_1[split_german,]
german_test = german_credit_1[!(split_german),]

# Initial Model with all variables
# 
initial_model = glm(Default_status ~ ., data = german_train, family = "binomial")
summary(initial_model)




# Stepwise selection

new_model <-  step(initial_model,direction = "both")


new_model_1 <- glm(formula = Default_status ~ Installment.rate.in.percentage.of.disposable.income + 
      Status.of.existing.checking.accountA12 + Status.of.existing.checking.accountA13 + 
      Status.of.existing.checking.accountA14 + Duration.in.monthLong.Term + 
      Credit.historyA32 + Credit.historyA33 + Credit.historyA34 + 
      PurposeA41 + PurposeA43 + PurposeA46 + PurposeA49 + Savings.account.bondsA64 + 
      Savings.account.bondsA65 + Present.employment.since.A73 + 
      Present.employment.since.A74 + Present.employment.since.A75 + 
      Personal.status.and.sexA93 + Other.debtors...guarantorsA103 + 
      Other.installment.plansA143, family = "binomial", data = german_train)

summary(new_model_1)

# Removing Credit.historyA33
new_model_2 <- glm(formula = Default_status ~ Installment.rate.in.percentage.of.disposable.income + 
                     Status.of.existing.checking.accountA12 + Status.of.existing.checking.accountA13 + 
                     Status.of.existing.checking.accountA14 + Duration.in.monthLong.Term + 
                     Credit.historyA32 + Credit.historyA34 + 
                     PurposeA41 + PurposeA43 + PurposeA46 + PurposeA49 + Savings.account.bondsA64 + 
                     Savings.account.bondsA65 + Present.employment.since.A73 + 
                     Present.employment.since.A74 + Present.employment.since.A75 + 
                     Personal.status.and.sexA93 + Other.debtors...guarantorsA103 + 
                     Other.installment.plansA143, family = "binomial", data = german_train)

summary(new_model_2)

# Removing PurposeA46
new_model_3 <- glm(formula = Default_status ~ Installment.rate.in.percentage.of.disposable.income + 
                     Status.of.existing.checking.accountA12 + Status.of.existing.checking.accountA13 + 
                     Status.of.existing.checking.accountA14 + Duration.in.monthLong.Term + 
                     Credit.historyA32 + Credit.historyA34 + 
                     PurposeA41 + PurposeA43 + PurposeA49 + Savings.account.bondsA64 + 
                     Savings.account.bondsA65 + Present.employment.since.A73 + 
                     Present.employment.since.A74 + Present.employment.since.A75 + 
                     Personal.status.and.sexA93 + Other.debtors...guarantorsA103 + 
                     Other.installment.plansA143, family = "binomial", data = german_train)

summary(new_model_3)

#  Removing Present.employment.since.A73 
new_model_4 <- glm(formula = Default_status ~ Installment.rate.in.percentage.of.disposable.income + 
                     Status.of.existing.checking.accountA12 + Status.of.existing.checking.accountA13 + 
                     Status.of.existing.checking.accountA14 + Duration.in.monthLong.Term + 
                     Credit.historyA32 + Credit.historyA34 + 
                     PurposeA41 + PurposeA43 + PurposeA49 + Savings.account.bondsA64 + 
                     Savings.account.bondsA65 + Present.employment.since.A74 + Present.employment.since.A75 + 
                     Personal.status.and.sexA93 + Other.debtors...guarantorsA103 + 
                     Other.installment.plansA143, family = "binomial", data = german_train)

summary(new_model_4)


# Removing Present.employment.since.A73 
new_model_5 <- glm(formula = Default_status ~ Installment.rate.in.percentage.of.disposable.income + 
                     Status.of.existing.checking.accountA12 + Status.of.existing.checking.accountA13 + 
                     Status.of.existing.checking.accountA14 + Duration.in.monthLong.Term + 
                     Credit.historyA32 + Credit.historyA34 + 
                     PurposeA41 + PurposeA43 + PurposeA49 + Savings.account.bondsA64 + 
                     Savings.account.bondsA65 +  Present.employment.since.A75 + 
                     Personal.status.and.sexA93 + Other.debtors...guarantorsA103 + 
                     Other.installment.plansA143, family = "binomial", data = german_train)

summary(new_model_5)


# Removing Present.employment.since.A75

new_model_6 <- glm(formula = Default_status ~ Installment.rate.in.percentage.of.disposable.income + 
                     Status.of.existing.checking.accountA12 + Status.of.existing.checking.accountA13 + 
                     Status.of.existing.checking.accountA14 + Duration.in.monthLong.Term + 
                     Credit.historyA32 + Credit.historyA34 + 
                     PurposeA41 + PurposeA43 + PurposeA49 + Savings.account.bondsA64 + 
                     Savings.account.bondsA65 +  Personal.status.and.sexA93 + Other.debtors...guarantorsA103 + 
                     Other.installment.plansA143, family = "binomial", data = german_train)

summary(new_model_6)

# Remove multicollinearity through VIF check

library(car)

vif(new_model_6)
# Every  variable is under 3

# c-statistic and KS -statistic


library(Hmisc)

# c-statistic
german_train$predicted_prob = predict(new_model_6,  type = "response")
rcorr.cens(german_train$predicted_prob,german_train$Default_status)

german_test$predicted_prob = predict(new_model_6, newdata = german_test,type = "response")
rcorr.cens(german_test$predicted_prob,german_test$Default_status)

#KS -statistic

library(ROCR)

model_score <- prediction(german_train$predicted_prob,german_train$Default_status)

model_perf <- performance(model_score, "tpr", "fpr")

ks_table <- attr(model_perf, "y.values")[[1]] - (attr(model_perf, "x.values")[[1]])

ks = max(ks_table)

which(ks_table == ks)   # 145 /604 = 0.24  , First bucket



#Test data set
model_score_test <- prediction(german_test$predicted_prob,german_test$Default_status)

model_perf_test <- performance(model_score_test, "tpr", "fpr")

ks_table_test <- attr(model_perf_test, "y.values")[[1]] - (attr(model_perf_test, "x.values")[[1]])

ks_test = max(ks_table_test)

which(ks_table_test == ks_test)  # 57 / 258  = 0.22


# Selecting threshold value

## To do
library(caret)
#confusion matrix

confusionMatrix(as.numeric(german_train$predicted_prob > 0.5),german_train$Default_status, positive = "1")

confusionMatrix(as.numeric(german_test$predicted_prob > 0.5),german_test$Default_status, positive = "1")


################  END  ###############

rm(ls=list())
