############################### CAPSTONE CredX RISK ANALYSIS ###############################
# Set Working Directory


# Install and Load the required packages
install.packages("MASS")
install.packages("car")
install.packages("e1071")
install.packages("caret")
install.packages("ROCR")
install.packages("class")
install.packages("caTools")
install.packages("Information")
install.packages("pROC")

library(MASS)
library(caret)
library(car)
library(e1071)
library(ROCR)
library(class)
library(caTools)
library(Information)
library(pROC)
library(ggplot2)
library(scales)
library(ggthemes)




# Load the given files.

## Removing all pre existing variables in memory
rm(list = ls())

# Import Demographic and credir bureau data
DemoGData<-read.csv("Demographic data.csv", stringsAsFactors = F, header = T)
CreditBData<-read.csv("Credit Bureau data.csv", stringsAsFactors = F)

##  Taking working set of Data 
DemoGData_2<-DemoGData
creditBData_2<-CreditBData

##################### DATA  CLEANING AND PREP FOR EDA ######################

##  EDA ON DEMOGRAPHIC DATA

# Check duplicate records
which(duplicated(DemoGData))   # no duplicate records found


# EDA on Bank data

# Demographic  Data cleaning
DemoGData_1<-DemoGData
str(DemoGData_1)
summary(DemoGData_1)

sum(is.na(DemoGData_1)) # Total NAs : 1428

# 1425 Performance tag NAs
DemoGData_1<-DemoGData_1[which(is.na(DemoGData_1$Performance.Tag) == FALSE),]

# 3 No. of dependents NAs
DemoGData_1<-DemoGData_1[which(is.na(DemoGData_1$No.of.dependents) == FALSE),]

nrow(DemoGData_1)
sum(is.na(DemoGData_1))

# Remove records with negative age
DemoGData_1<-DemoGData_1[which(DemoGData_1$Age > 0),]

# Divide the age into buckets
summary(DemoGData_1$Age)
DemoGData_1$Age<-round(DemoGData_1$Age)

boxplot(DemoGData_1$Age)
DemoGData_1$Age<-cut(DemoGData_1$Age, breaks=c(14 ,35, 45, Inf), labels = c("Young", "Mid Age", "High Age"))

DemoGData_1<-DemoGData_1[which(DemoGData_1$Gender != ""),]
unique(DemoGData_1$Gender)
DemoGData_1$Gender<-as.factor(DemoGData_1$Gender)

unique(DemoGData_1$Marital.Status..at.the.time.of.application.)
DemoGData_1<-DemoGData_1[which(DemoGData_1$Marital.Status..at.the.time.of.application. != ""),]
DemoGData_1$Marital.Status..at.the.time.of.application.<-as.factor(DemoGData_1$Marital.Status..at.the.time.of.application.)

unique(DemoGData_1$No.of.dependents)
DemoGData_1$No.of.dependents<-as.factor(DemoGData_1$No.of.dependents)

# Remove income in negative
DemoGData_1<-DemoGData_1[which(DemoGData_1$Income > 0),]
unique(DemoGData_1$Income)
summary(DemoGData_1$Income)
boxplot(DemoGData_1$Income)
DemoGData_1$Income<-cut(DemoGData_1$Income, breaks=c(1, 20, 40, Inf), labels = c("Low", "Mid", "High"), include.lowest = T)


unique(DemoGData_1$Education)
DemoGData_1<-DemoGData_1[which(DemoGData_1$Education != ""),]
DemoGData_1$Education<-as.factor(DemoGData_1$Education)

unique(DemoGData_1$Profession)
DemoGData_1<-DemoGData_1[which(DemoGData_1$Profession != ""),]
DemoGData_1$Profession<-as.factor(DemoGData_1$Profession)

unique(DemoGData_1$Type.of.residence)
DemoGData_1<-DemoGData_1[which(DemoGData_1$Type.of.residence != ""),]
DemoGData_1$Type.of.residence<-as.factor(DemoGData_1$Type.of.residence)

unique(DemoGData_1$No.of.months.in.current.company)
summary(DemoGData_1$No.of.months.in.current.company)
boxplot(DemoGData_1$No.of.months.in.current.company)
boxplot.stats(DemoGData_1$No.of.months.in.current.company)$out
DemoGData_1<-DemoGData_1[which(!(DemoGData_1$No.of.months.in.current.company %in% boxplot.stats(DemoGData_1$No.of.months.in.current.company)$out)),]
DemoGData_1$No.of.months.in.current.company<-cut(DemoGData_1$No.of.months.in.current.company, breaks=c(3, 20, 40, Inf), labels = c("Low", "Mid", "High"), include.lowest = T)

unique(DemoGData_1$No.of.months.in.current.residence)
summary(DemoGData_1$No.of.months.in.current.residence)
boxplot(DemoGData_1$No.of.months.in.current.residence)
DemoGData_1$No.of.months.in.current.residence<-cut(DemoGData_1$No.of.months.in.current.residence, breaks=c(6, 15, 40, Inf), labels = c("Low", "Mid", "High"), include.lowest = T)


unique(DemoGData_1$Performance.Tag)
DemoGData_1$Performance.Tag<-as.factor(DemoGData_1$Performance.Tag)

# Here we have cleaned and prepared data in DemoGData_1 data frame.
# Now we can do EDA on the demographic data
str(DemoGData_1)



# Age wise data distribution
ggplot(DemoGData_1, aes(x=DemoGData_1$Age)) + geom_bar()

# Age wise performance distribution
Age<-ggplot(data=DemoGData_1, aes(x=DemoGData_1$Age, fill=DemoGData_1$Performance.Tag), y=(..count../sum(..count..))) 
Age + geom_bar() + geom_text(aes(label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust=1, position = position_stack()) 
DemoGData_1$Performance.Tag


plot3 <- ggplot(DemoGData_1,aes(x=factor(Performance.Tag))) + geom_bar(aes(y = (..count..)/sum(..count..)))
plot3 + facet_wrap(~ Age) + theme(text = element_text(size=14),axis.text.x = element_text(angle=90, vjust=1)) +labs(x="Age" , y="count")+  scale_fill_discrete(guide = guide_legend(title = "Age distribution"))+scale_y_continuous(labels = percent)


# Gender wise data distribution
ggplot(DemoGData_1, aes(x=DemoGData_1$Gender)) + geom_bar()

# Gender wise performance distribution
Gender<-ggplot(data=DemoGData_1, aes(x=DemoGData_1$Gender, fill=DemoGData_1$Performance.Tag), y=(..count../sum(..count..))) 
Gender + geom_bar() + geom_text(aes(label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust=1, position = position_stack()) 

# Marital wise data distribution
ggplot(DemoGData_1, aes(x=DemoGData_1$Marital.Status..at.the.time.of.application.)) + geom_bar()

# Marital wise performance distribution
Marital<-ggplot(data=DemoGData_1, aes(x=DemoGData_1$Marital.Status..at.the.time.of.application., fill=DemoGData_1$Performance.Tag), y=(..count../sum(..count..))) 
Marital + geom_bar() + geom_text(aes(label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust=1, position = position_stack()) 


# Dependents wise data distribution
ggplot(DemoGData_1, aes(x=DemoGData_1$No.of.dependents)) + geom_bar()

# Dependents wise performance distribution
Dependents<-ggplot(data=DemoGData_1, aes(x=DemoGData_1$No.of.dependents, fill=DemoGData_1$Performance.Tag), y=(..count../sum(..count..))) 
Dependents + geom_bar() + geom_text(aes(label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust=1, position = position_stack()) 


# Income wise data distribution
ggplot(DemoGData_1, aes(x=DemoGData_1$Income)) + geom_bar()

# Income wise performance distribution
Income<-ggplot(data=DemoGData_1, aes(x=DemoGData_1$Income, fill=DemoGData_1$Performance.Tag), y=(..count../sum(..count..))) 
Income + geom_bar() + geom_text(aes(label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust=1, position = position_stack()) 


# Education wise data distribution
ggplot(DemoGData_1, aes(x=DemoGData_1$Education)) + geom_bar()

# Education wise performance distribution
Education<-ggplot(data=DemoGData_1, aes(x=DemoGData_1$Education, fill=DemoGData_1$Performance.Tag), y=(..count../sum(..count..))) 
Education + geom_bar() + geom_text(aes(label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust=1, position = position_stack()) 

# Profession wise data distribution
ggplot(DemoGData_1, aes(x=DemoGData_1$Profession)) + geom_bar()

# Profession wise performance distribution
Profession<-ggplot(data=DemoGData_1, aes(x=DemoGData_1$Profession, fill=DemoGData_1$Performance.Tag), y=(..count../sum(..count..))) 
Profession + geom_bar() + geom_text(aes(label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust=1, position = position_stack()) 


# Type.of.residence wise data distribution
ggplot(DemoGData_1, aes(x=DemoGData_1$Type.of.residence)) + geom_bar()

# Type.of.residence wise performance distribution
Residence<-ggplot(data=DemoGData_1, aes(x=DemoGData_1$Type.of.residence, fill=DemoGData_1$Performance.Tag), y=(..count../sum(..count..))) 
Residence + geom_bar() + geom_text(aes(label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust=1, position = position_stack()) 


# No.of.months.in.current.residence wise data distribution
ggplot(DemoGData_1, aes(x=DemoGData_1$No.of.months.in.current.residence)) + geom_bar()

# No.of.months.in.current.residence wise performance distribution
CurResidence<-ggplot(data=DemoGData_1, aes(x=DemoGData_1$No.of.months.in.current.residence, fill=DemoGData_1$Performance.Tag), y=(..count../sum(..count..))) 
CurResidence + geom_bar() + geom_text(aes(label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust=1, position = position_stack()) 


# No.of.months.in.current.company wise data distribution
ggplot(DemoGData_1, aes(x=DemoGData_1$No.of.months.in.current.company)) + geom_bar()

# No.of.months.in.current.company wise performance distribution
CurCompany<-ggplot(data=DemoGData_1, aes(x=DemoGData_1$No.of.months.in.current.company, fill=DemoGData_1$Performance.Tag), y=(..count../sum(..count..))) 
CurCompany + geom_bar() + geom_text(aes(label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust=1, position = position_stack()) 


## Checking the  Credit Bureau data set 
which(duplicated(creditBData_2))


### Renaming the Performance tag in both Demographic data and Credit bureau data
names(DemoGData_1)[12]<-"Performance.Tag.Demo"
names(creditBData_2)[19]<-"Performance.Tag.credit"


# Merge Demographic and credit bureau data based on application data for EDA
#MasterData<- merge(DemoGData_2, creditBData_2, by="Application.ID", all=T)

MasterData <- merge(DemoGData_1, creditBData_2, by="Application.ID", all=T)

nrow(MasterData)
which(duplicated(MasterData))
which(duplicated(MasterData$Application.ID)) # 9 application IDs are duplicate
MasterData<-MasterData[-which(duplicated(MasterData$Application.ID)),]
nrow(MasterData)


# Discard NAs
sum(is.na(MasterData))
MasterData<-MasterData[-which(is.na(MasterData$Performance.Tag.Demo)),]
MasterBackup <- MasterData

MasterData <- MasterBackup
MasterData<-MasterData[-which(is.na(MasterData$Avgas.CC.Utilization.in.last.12.months)),]
#MasterData<-MasterData[-which(is.na(MasterData$No.of.dependents)),]

sum(is.na(MasterData))

# Check if performance tag in two dataset are equal or not
identical(MasterData[['Performance.Tag.credit']], MasterData[['Performance.Tag.Demo']])
all(MasterData$Performance.Tag.Demo == MasterData$Performance.Tag.credit)


#sum(as.numeric(which(MasterData$Performance.Tag.Demo == MasterData$Performance.Tag.credit)))
# Performance tag in both dataset are equal, remove one of them.
names(MasterData)[30]
MasterData<-MasterData[,-30]
summary(MasterData)

MasterData$Performance.Tag.Demo<-as.factor(MasterData$Performance.Tag.Demo)
#MasterData$Performance.Tag.credit <- as.factor(MasterData$Performance.Tag.credit)
#row.names(MasterData)<-seq(1:nrow(MasterData))

# MAster data ready for eda#################################################

#quantile(MasterData$Income,seq(0,1,0.02))


#################### EDA ON MASTER DATA  - Multivariate analysis

plot3 <- ggplot(DemoGData_1,aes(x=factor(Performance.Tag.Demo))) + geom_bar(aes(y = (..count..)/sum(..count..)))
plot3 + facet_wrap(~ Age) + theme(text = element_text(size=14),axis.text.x = element_text(angle=90, vjust=1)) +labs(x="Age" , y="count")+  scale_fill_discrete(guide = guide_legend(title = "Age distribution"))+scale_y_continuous(labels = percent)





# Profession

plot_9 <-  qplot(Profession, Avgas.CC.Utilization.in.last.12.months, data=MasterData, geom=c("boxplot", "jitter"), 
                 fill=Profession, main="LIMIT_AMT by Education cat",xlab="", ylab="amount of ")
plot_9 + facet_wrap(~ Performance.Tag.Demo) 




# Profession , trades
Profession_plot <- ggplot(MasterData, aes(x = Profession, fill = No.of.trades.opened.in.last.12.months)) + geom_bar() +labs(x = 'Profession') +theme_excel()
Profession_plot + facet_wrap(~ Performance.Tag.Demo) 



# Performance vs all enquiries variables

## Deafulters have made more than 1 enquiry
enquiry <- ggplot(MasterData, aes(x= No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.)) +geom_bar() +labs(x = 'dpd') +theme_excel()
enquiry + facet_wrap(~ Performance.Tag.Demo) 

default_dataset <- subset (MasterData, Performance.Tag.Demo =='1')


# NA and Not NA data set 
boxplot(default_dataset$No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.)
summary(default_dataset$No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.)
boxplot(non_default_dataset$No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.)
summary(non_default_dataset$No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.)
non_default_dataset <- subset(MasterData,Performance.Tag.Demo=='0')
## Autolon and car loan

MasterData$Performance.Tag.Demo<-as.numeric(as.character(MasterData$Performance.Tag.Demo))
MasterData$Presence.of.open.auto.loan<- as.numeric(MasterData$Presence.of.open.auto.loan)
MasterData$Presence.of.open.home.loan<- as.numeric(MasterData$Presence.of.open.home.loan)

cor(MasterData$Presence.of.open.home.loan,MasterData$Presence.of.open.auto.loan) # No corelation

cor(MasterData$Presence.of.open.home.loan,MasterData$Performance.Tag.Demo) # No co relation

cor(MasterData$Presence.of.open.auto.loan,MasterData$Performance.Tag.Demo) # No co relation

MasterData$Performance.Tag.Demo <- as.factor(MasterData$Performance.Tag.Demo)



# Type of residence  , # No insight
residence_plot <- ggplot(MasterData, aes(x = Type.of.residence, fill = No.of.months.in.current.residence)) + geom_bar() +labs(x = 'residence') +theme_excel()
residence_plot + facet_wrap(~ Performance.Tag.Demo) 


# Profession


Profession_plot <- ggplot(MasterData, aes(x = Profession, fill = No.of.times.90.DPD.or.worse.in.last.12.months)) + geom_bar() +labs(x = 'Education') +theme_excel()
Profession_plot + facet_wrap(~ Performance.Tag.Demo) 



# Age and credit card utilization


age_plot <- ggplot(MasterData, aes(x = Age, fill = Avgas.CC.Utilization.in.last.12.months)) + geom_bar() +labs(x = 'Age') +theme_excel()
age_plot + facet_wrap(~ Performance.Tag.Demo)


#  Out standing balance vs Avg credit utilization vs default


cc_plot <- ggplot(MasterData, aes(x = Avgas.CC.Utilization.in.last.12.months, y =Outstanding.Balance )) + geom_bar(width = 1,stat="identity") +labs(x = 'AvgCC util') 
cc_plot + facet_wrap(~ Performance.Tag.Demo)


### Trades

trade_plot <- ggplot(MasterData, aes(x = Avgas.CC.Utilization.in.last.12.months, y =No.of.PL.trades.opened.in.last.12.months )) + geom_bar(width = 1,stat="identity") +labs(x = 'AvgCC util') 
trade_plot + facet_wrap(~ Performance.Tag.Demo)


## Insight : low income group have high defualt
balance_plot <-ggplot(MasterData, aes(x = Income , y =Outstanding.Balance )) + geom_bar(width = 1,stat="identity") +labs(x = 'Income group') 
balance_plot + facet_wrap(~ Performance.Tag.Demo)


## No.of.times.90.DPD.or.worse.in.last.12.months , performance tag directly proportional

MasterData$No.of.times.90.DPD.or.worse.in.last.12.months <- as.factor(MasterData$No.of.times.90.DPD.or.worse.in.last.12.months)


MasterData$No.of.times.90.DPD.or.worse.in.last.12.months <- as.numeric(as.character(MasterData$No.of.times.90.DPD.or.worse.in.last.12.months))

Low_incomedata <- subset(MasterData,Income =='Low')
Mid_incomedata <- subset(MasterData,Income =='Mid')
high_incomedata <- subset(MasterData,Income =='High')



hist(Low_incomedata$No.of.times.90.DPD.or.worse.in.last.12.months,col = "lightblue",freq  = 2,main = "Low Income 90 DPD",breaks = 10,xlab = "No of Times.", ylab = "Frequency")
plot(Low_incomedata$Performance.Tag.Demo)
hist(Mid_incomedata$No.of.times.90.DPD.or.worse.in.last.12.months,col = "lightblue",freq  = 2,main = "Mid Income 90 DPD",breaks = 10,xlab = "No of Times.", ylab = "Frequency")
plot(Mid_incomedata$Performance.Tag.Demo)
hist(high_incomedata$No.of.times.90.DPD.or.worse.in.last.12.months,col = "lightblue",freq  = 2,main = "High Income 90 DPD",breaks = 10,xlab = "No of Times.", ylab = "Frequency")
plot(high_incomedata$Performance.Tag.Demo)



plot(MasterData$Income)
plot(MasterData$No.of.times.90.DPD.or.worse.in.last.12.months)



## Low income high number default ratings

qplot(Income, No.of.times.30.DPD.or.worse.in.last.6.months, data=MasterData, geom=c("boxplot", "jitter"),fill=Performance.Tag.Demo, main="Income & 90 dpd 12 months & Performance in one plot ",xlab="Income group", ylab="Numberof times 90 dpd miss")


qplot(No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.,Income,data=MasterData, geom=c("boxplot", "jitter"),fill=Performance.Tag.Demo, main="LIMIT_AMT by Education cat",xlab="", ylab="amount of ")


 

female_data <- subset(MasterData,Gender=="F")
male_data <- subset(MasterData,Gender=="M")

plot(female_data$Outstanding.Balance)

########### EDA on rejected  applicant data -- Results provided in the pdf submitted #####################3

demographic_data <- DemoGData 
credit_bueau_data <- CreditBData
merge_dataset <- merge(demographic_data,credit_bueau_data,by.x = 'Application.ID', by.y = 'Application.ID',all = FALSE)


performTage_NA_dataset  <- merge_dataset[which(is.na(merge_dataset$Performance.Tag.x)==T),]
performTage_NOTNA_dataset  <- merge_dataset[which(is.na(merge_dataset$Performance.Tag.x)==F),]

summary(performTage_NA_dataset)
summary(performTage_NOTNA_dataset)

hist(performTage_NA_dataset$Income, col = "lightblue",freq  = 2,main = "NA 90dpd 12 months",breaks = 10,xlab = "Range", ylab = "Frequency")
hist(performTage_NOTNA_dataset$Income , col = "pink",freq  = 2,main = "NA 90dpd 12 months",breaks = 10,xlab = "Range", ylab = "Frequency")
hist(performTage_NA_dataset$Avgas.CC.Utilization.in.last.12.months, col = "lightblue",freq  = 2,main = "NA 90dpd 12 months",breaks = 10,xlab = "Range", ylab = "Frequency")
hist(performTage_NOTNA_dataset$Avgas.CC.Utilization.in.last.12.months, col = "pink",freq  = 2,main = "NA 90dpd 12 months",breaks = 10,xlab = "Range", ylab = "Frequency")

hist(performTage_NA_dataset$Age, col = "lightblue",freq  = 2,main = "NA 90dpd 12 months",breaks = 10,xlab = "Range", ylab = "Frequency")
hist(performTage_NOTNA_dataset$Age, col = "pink",freq  = 2,main = "NA 90dpd 12 months",breaks = 10,xlab = "Range", ylab = "Frequency")


hist(performTage_NA_dataset$No.of.PL.trades.opened.in.last.6.months, col = "lightblue",freq  = 2,main = "NA 90dpd 12 months",breaks = 10,xlab = "Range", ylab = "Frequency")
hist(performTage_NOTNA_dataset$No.of.PL.trades.opened.in.last.6.months, col = "pink",freq  = 2,main = "NA 90dpd 12 months",breaks = 10,xlab = "Range", ylab = "Frequency")


plot(performTage_NA_dataset$Presence.of.open.auto.loan , col = "lightblue",freq  = 2,main = "NA 90dpd 12 months",breaks = 10,xlab = "Range", ylab = "Frequency")
plot(performTage_NOTNA_dataset$Presence.of.open.auto.loan, col = "pink",freq  = 2,main = "NA 90dpd 12 months",breaks = 10,xlab = "Range", ylab = "Frequency" )



plot(performTage_NA_dataset$Presence.of.open.home.loan, col = "lightblue",freq  = 2,main = "NA 90dpd 12 months",breaks = 10,xlab = "Range", ylab = "Frequency")
plot(performTage_NOTNA_dataset$Presence.of.open.home.loan, col = "pink",freq  = 2,main = "NA 90dpd 12 months",breaks = 10,xlab = "Range", ylab = "Frequency")
hist(performTage_NOTNA_dataset$Total.No.of.Trades, col = "pink",freq  = 2,main = "NA 90dpd 12 months",breaks = 10,xlab = "Range", ylab = "Frequency")
hist(performTage_NA_dataset$Total.No.of.Trades, col = "lightblue",freq  = 2,main = "NA 90dpd 12 months",breaks = 10,xlab = "Range", ylab = "Frequency")

boxplot(performTage_NA_dataset$Total.No.of.Trades, col = "lightblue",freq  = 2,main = "NA 90dpd 12 months",breaks = 10,xlab = "Range", ylab = "Frequency")
boxplot(performTage_NOTNA_dataset$Total.No.of.Trades, col = "pink",freq  = 2,main = "NA 90dpd 12 months",breaks = 10,xlab = "Range", ylab = "Frequency")


qplot(Profession, Avgas.CC.Utilization.in.last.12.months, data=MasterData, geom=c("boxplot", "jitter"), 
      fill=Profession, main="LIMIT_AMT by Education cat",xlab="", ylab="amount of ")

hist(performTage_NA_dataset$No.of.times.90.DPD.or.worse.in.last.12.months,col = "purple",freq  = 2,main = "NA 90dpd 12 months",breaks = 10,xlab = "Range", ylab = "Frequency")

hist(performTage_NOTNA_dataset$No.of.times.90.DPD.or.worse.in.last.12.months,col = "purple",freq  = 2,main = "NOTNA 90 dpd 12 months",breaks = 10,xlab = "Range", ylab = "Frequency")
quantile(performTage_NA_dataset$Age)
quantile(performTage_NOTNA_dataset$Age)
performTage_NA_dataset$Presence.of.open.auto.loan <- as.factor(performTage_NA_dataset$Presence.of.open.auto.loan)
performTage_NOTNA_dataset$Presence.of.open.auto.loan <- as.factor(performTage_NOTNA_dataset$Presence.of.open.auto.loan)


ggplot(performTage_NA_dataset, aes(x =No.of.Inquiries.in.last.6.months..excluding.home...auto.loans.)) + geom_bar() +labs(x="NA dataset ")
ggplot(performTage_NOTNA_dataset, aes(x =No.of.Inquiries.in.last.6.months..excluding.home...auto.loans.)) + geom_bar() +labs(x="NOTNA dataset ")




boxplot(performTage_NA_dataset$Avgas.CC.Utilization.in.last.12.months)
boxplot(performTage_NOTNA_dataset$Avgas.CC.Utilization.in.last.12.months)

########### EDA on rejected  applicant data  Ends #######

########### EDA ON real merge data set #############


## Removing the  binning data set 
rm(DemoGData_2)
rm(creditBData_2)

DemoGData_2<-DemoGData
creditBData_2<-CreditBData

## Renaming the 
names(DemoGData_2)[12]<-"Performance.Tag.Demo"
names(creditBData_2)[19]<-"Performance.Tag.credit"
## 1. Creating the correct woe_datatable

##1.1 Take the merge dataset and let the woe pacakge determine the woe values and then we will replace it .

MasterData_woe <- merge(DemoGData_2, creditBData_2, by="Application.ID", all=T)

## Master data set for NA data set 
MasterData_woe_dum <- merge(DemoGData_2, creditBData_2, by="Application.ID", all=T)
#1.2 Remove the duplicate Application Id and rejected credit data

MasterData_woe<-MasterData_woe[-which(duplicated(MasterData_woe$Application.ID)),]
## New Feature  Introduced Debt to Income 
MasterData_woe$DTI <- MasterData_woe$Outstanding.Balance / MasterData_woe$Income
MasterData_woe_dum$DTI <- MasterData_woe_dum$Outstanding.Balance / MasterData_woe_dum$Income
## Removing the duplicate  data set 
MasterData_woe_dum<-MasterData_woe_dum[-which(duplicated(MasterData_woe_dum$Application.ID)),]



## Creating the NA data set 
MasterData__na<-MasterData_woe[which(is.na(MasterData_woe$Performance.Tag.Demo)==TRUE),]
MasterData__na<-MasterData_woe_dum[which(is.na(MasterData_woe_dum$Performance.Tag.Demo)==TRUE),]
MasterData__na<- MasterData__na[,-30]

sum(is.na(MasterData__na))# 1460


## Removing the NAs values from the data set 
MasterData_woe<-MasterData_woe[-which(is.na(MasterData_woe$Performance.Tag.Demo)),]





#1.3 Removing the Performance.Tag.credit 


## we have already seen the Performance.Tag.credit is eqaul to Performance.Tag.Demo in EDA hence we can remove it
## 

cor(MasterData_woe$Performance.Tag.credit,MasterData_woe$Performance.Tag.Demo) # 1
MasterData_woe<- MasterData_woe[,-30]



## Small EDA plots 
# some insights for EDA ,Income
plot_67<- ggplot(MasterData_woe,aes(x=Income,y=as.factor(MasterData_woe$Age)))
plot_67 +geom_point(aes(col=as.factor(MasterData_woe$Performance.Tag.Demo)))



## Auto loan insight
ggplot(MasterData_woe,aes(x=Outstanding.Balance,y=as.factor(MasterData_woe$Presence.of.open.auto.loan))) +geom_point(aes(col=as.factor(MasterData_woe$Performance.Tag.Demo)))


#### EDA end ####### 


######################################  WOE DATA SET ##############################################3

## We found that  all the varibales are int/num/ or character in nature, thus we can apply the woe  pacakge
## and calculate the woe values . The NA/outlier treatment /scaling is done by the woe package itself



#### WOE data frame creation an dimputation of outliers/NAs etc.
library(Information)
WOE_IV_data_bin_10 <- create_infotables(data=MasterData_woe, y="Performance.Tag.Demo", bins=10, parallel=TRUE)
WOE_IV_data_bin_10
# Check the WOE and IV in the WOE_IV_data_bin_10

# Back up of the 
Master_Sample_woe <- MasterData_woe





WOE_IV_data_DF <- data.frame(WOE_IV_data_bin_10$Summary)
## Forcing R to print floating number in normal decimal system not in exponential system
options("scipen"=100, "digits"=4)



## Taking the MasterData_woe from the backup frame as and when required because imputation of 
## woe may corrupt the data 

MasterData_woe <- Master_Sample_woe

## library needed for mapping values 
library(plyr)



## Imputing the woe values and creating data  frame


##WOE  Age values
sum(is.na(MasterData_woe$Age))
MasterData_woe$Age<-cut(MasterData_woe$Age, breaks=c(-3,31,36,39,42,45,48,51,54,58,Inf), labels = c(-0.041941665,0.034531539,0.069071901,0.068297625,-0.037941656,-0.003958667, -0.012629305,-0.136905430 ,0.043405263,-0.010013410),right = FALSE )
sum(is.na(MasterData_woe$Age))
##WOE  Gender values
sum(is.na(MasterData_woe$Gender))
MasterData_woe$Gender<- mapvalues(MasterData_woe$Gender,from = c("F","M"),to = c(0.03217430,-0.01010818))
sum(is.na(MasterData_woe$Gender))

##WOE  Gender values Marital.Status..at.the.time.of.application.
sum(is.na(MasterData_woe$Marital.Status..at.the.time.of.application.))
MasterData_woe$Marital.Status..at.the.time.of.application.<- mapvalues(MasterData_woe$Marital.Status..at.the.time.of.application.,from = c("Married","Single"),to = c(-0.003987254,0.023326708),warn_missing = TRUE)
sum(is.na(MasterData_woe$Marital.Status..at.the.time.of.application.))
##WOE  Gender values No.of.dependents
sum(is.na(MasterData_woe$No.of.dependents))
## There are 3 NAs in No of dependents with Performance tag '0' and OWE also 0 , hence discarded
MasterData_woe<-MasterData_woe[-which(is.na(MasterData_woe$No.of.dependents)),]
MasterData_woe$No.of.dependents<-mapvalues(MasterData_woe$No.of.dependents,from = c(1,2,3,4,5),to = c(0.04008522,-0.08522163,0.05415544,-0.02520439,0.00439087))
sum(is.na(MasterData_woe$No.of.dependents))


## WOE Income
sum(is.na(MasterData_woe$Income))
MasterData_woe$Income<-cut(MasterData_woe$Income, breaks=c(-0.5,6,11,17,22,27,32,37,42,49,Inf), labels = c(0.30246890,0.27575091,0.06608894,0.08080252,0.02506399,0.07864867,-0.15595501,-0.26368117,-0.17686352,-0.36078566),right = FALSE )

sum(is.na(MasterData_woe$Income))
## WOE Education
sum(is.na(MasterData_woe$Education))
MasterData_woe$Education<-mapvalues(MasterData_woe$Education,from = c("Bachelor","Masters","Others","Phd","Professional"),to = c(0.017313988,0.007948702,0.492621513,-0.029511963,-0.017931398))
sum(is.na(MasterData_woe$Education))

## WOE Profession
sum(is.na(MasterData_woe$Profession))
MasterData_woe$Profession<- mapvalues(MasterData_woe$Profession,from = c("SAL","SE","SE_PROF"),to = c(-0.02806688,0.09142405,-0.01329769),warn_missing = TRUE)
sum(is.na(MasterData_woe$Profession))

# WOE Type.of.residence
sum(is.na(MasterData_woe$Type.of.residence))
MasterData_woe$Type.of.residence<- mapvalues(MasterData_woe$Type.of.residence,from = c("Company provided","Living with Parents","Others","Owned","Rented"),to = c(0.080146599,0.067530440,-0.530542104,0.004148595,-0.004293999))
sum(is.na(MasterData_woe$Type.of.residence))


## WOE No.of.months.in.current.residence
sum(is.na(MasterData_woe$No.of.months.in.current.residence))
MasterData_woe$No.of.months.in.current.residence <-cut(MasterData_woe$No.of.months.in.current.residence, breaks=c(6,10,29,50,73,98,Inf), labels = c(-0.27219153,0.49872310,0.30118432,0.13401754,0.13948089,-0.07705956), right = FALSE)
sum(is.na(MasterData_woe$No.of.months.in.current.residence))

## WOE No.of.months.in.current.company
sum(is.na(MasterData_woe$No.of.months.in.current.company))
MasterData_woe$No.of.months.in.current.company <-cut(MasterData_woe$No.of.months.in.current.company, breaks=c(3,6,13,20,27,34,41,48,54,62,Inf), labels = c(0.09851585,0.17548049,0.20630691,0.03919674,-0.08567605,0.03079397,-0.17614850,-0.21792183,-0.21640008,0.06288591),right = FALSE )
sum(is.na(MasterData_woe$No.of.months.in.current.company))
## WOE No.of.times.90.DPD.or.worse.in.last.6.months

sum(is.na(MasterData_woe$No.of.times.90.DPD.or.worse.in.last.6.months))
MasterData_woe$No.of.times.90.DPD.or.worse.in.last.6.months <- mapvalues(MasterData_woe$No.of.times.90.DPD.or.worse.in.last.6.months,from = c(0,1,2,3),to = c(-0.2606781,0.6224550,0.6224550,0.6224550))
sum(is.na(MasterData_woe$No.of.times.90.DPD.or.worse.in.last.6.months))

## WOE No.of.times.60.DPD.or.worse.in.last.6.months
sum(is.na(MasterData_woe$No.of.times.60.DPD.or.worse.in.last.6.months))
MasterData_woe$No.of.times.60.DPD.or.worse.in.last.6.months <- mapvalues(MasterData_woe$No.of.times.60.DPD.or.worse.in.last.6.months,from = c(0,1,2,3,4,5),to = c(-0.3363664,0.6225361,0.6225361,0.6225361,0.6225361,0.6225361))
sum(is.na(MasterData_woe$No.of.times.60.DPD.or.worse.in.last.6.months))

## WOE No.of.times.30.DPD.or.worse.in.last.6.months
sum(is.na(MasterData_woe$No.of.times.30.DPD.or.worse.in.last.6.months))
MasterData_woe$No.of.times.30.DPD.or.worse.in.last.6.months <- mapvalues(MasterData_woe$No.of.times.30.DPD.or.worse.in.last.6.months,from = c(0,1,2,3,4,5,6,7),to = c(-0.3867918,0.4643187,0.7428448,0.7428448,0.7428448,0.7428448,0.7428448,0.7428448))
sum(is.na(MasterData_woe$No.of.times.30.DPD.or.worse.in.last.6.months))


## WOE No.of.times.90.DPD.or.worse.in.last.12.months
sum(is.na(MasterData_woe$No.of.times.90.DPD.or.worse.in.last.12.months))
MasterData_woe$No.of.times.90.DPD.or.worse.in.last.12.months <- mapvalues(MasterData_woe$No.of.times.90.DPD.or.worse.in.last.12.months,from = c(0,1,2,3,4,5),to = c(-0.3566331,0.5088234,0.7219824,0.7219824,0.7219824,0.7219824))
sum(is.na(MasterData_woe$No.of.times.90.DPD.or.worse.in.last.12.months))

## WOE No.of.times.60.DPD.or.worse.in.last.12.months
sum(is.na(MasterData_woe$No.of.times.60.DPD.or.worse.in.last.12.months))
MasterData_woe$No.of.times.60.DPD.or.worse.in.last.12.months <- mapvalues(MasterData_woe$No.of.times.60.DPD.or.worse.in.last.12.months,from = c(0,1,2,3,4,5,6,7),to = c(-0.3519211,0.2141538,0.6940858,0.6940858,0.6940858,0.6940858,0.6940858,0.6940858))
sum(is.na(MasterData_woe$No.of.times.60.DPD.or.worse.in.last.12.months))

## WOE No.of.times.30.DPD.or.worse.in.last.12.months
sum(is.na(MasterData_woe$No.of.times.30.DPD.or.worse.in.last.12.months))
MasterData_woe$No.of.times.30.DPD.or.worse.in.last.12.months <- mapvalues(MasterData_woe$No.of.times.30.DPD.or.worse.in.last.12.months,from = c(0,1,2,3,4,5,6,7,8,9),to = c(-0.3763960,0.2805525,0.2805525,0.7994935,0.7994935,0.7994935,0.7994935,0.7994935,0.7994935,0.7994935))
sum(is.na(MasterData_woe$No.of.times.30.DPD.or.worse.in.last.12.months))

## WOE Avgas.CC.Utilization.in.last.12.months

sum(is.na(MasterData_woe$Avgas.CC.Utilization.in.last.12.months))
MasterData_woe$Avgas.CC.Utilization.in.last.12.months[which(is.na(MasterData_woe$Avgas.CC.Utilization.in.last.12.months))]  <- 0.11147371
sum(is.na(MasterData_woe$Avgas.CC.Utilization.in.last.12.months))
MasterData_woe$Avgas.CC.Utilization.in.last.12.months <-cut(MasterData_woe$Avgas.CC.Utilization.in.last.12.months, breaks=c(0,5,7,9,12,15,22,38,52,72,Inf), labels = c(-0.80175843,-0.80150239,-0.79452312,-0.67240619,-0.46800192,-0.07900431,0.47504577,0.58458900,0.56373098,0.38134147),right = FALSE )
sum(is.na(MasterData_woe$Avgas.CC.Utilization.in.last.12.months))


# Keeping Avg data in numeric form


## WOE No.of.trades.opened.in.last.6.months

sum(is.na(MasterData_woe$No.of.trades.opened.in.last.6.months)) # 1 NA vaue with perfromance tag as 0 , hene removing
MasterData_woe<-MasterData_woe[-which(is.na(MasterData_woe$No.of.trades.opened.in.last.6.months)),]
MasterData_woe$No.of.trades.opened.in.last.6.months <- cut(MasterData_woe$No.of.trades.opened.in.last.6.months, breaks=c(0,1,2,3,4,5,Inf), labels = c(-0.6576285,-0.4795153,0.2328610,0.4351239,0.5242769,0.1368556 ),right = FALSE )
sum(is.na(MasterData_woe$No.of.trades.opened.in.last.6.months))


## WOE No.of.trades.opened.in.last.12.months
sum(is.na(MasterData_woe$No.of.trades.opened.in.last.12.months))
MasterData_woe$No.of.trades.opened.in.last.12.months <- cut(MasterData_woe$No.of.trades.opened.in.last.12.months, breaks=c(0,1,2,3,4,6,8,10,13,Inf), labels = c(-0.653462151,-1.019086045,-0.816468838,0.003598878,0.109294271,0.447981607,0.571340073,0.491781025,0.006306206),right = FALSE )
sum(is.na(MasterData_woe$No.of.trades.opened.in.last.12.months))

##   WOE No.of.PL.trades.opened.in.last.6.months
sum(is.na(MasterData_woe$No.of.PL.trades.opened.in.last.6.months))
MasterData_woe$No.of.PL.trades.opened.in.last.6.months <- cut(MasterData_woe$No.of.PL.trades.opened.in.last.6.months, breaks=c(0,1,2,3,Inf), labels = c(-0.6492118,0.1993619,0.4384356,0.3619618),right = FALSE )
sum(is.na(MasterData_woe$No.of.PL.trades.opened.in.last.6.months))

##   WOE No.of.PL.trades.opened.in.last.12.months
sum(is.na(MasterData_woe$No.of.PL.trades.opened.in.last.12.months))
MasterData_woe$No.of.PL.trades.opened.in.last.12.months <- cut(MasterData_woe$No.of.PL.trades.opened.in.last.12.months, breaks=c(0,1,2,3,4,5,6,Inf), labels = c(-0.8938108,-0.1310168,0.2513399,0.4122959,0.5000753,0.4261494,0.2431575),right = FALSE )
sum(is.na(MasterData_woe$No.of.PL.trades.opened.in.last.12.months))


## WOE No.of.Inquiries.in.last.6.months..excluding.home...auto.loans.
sum(is.na(MasterData_woe$No.of.Inquiries.in.last.6.months..excluding.home...auto.loans.))
MasterData_woe$No.of.Inquiries.in.last.6.months..excluding.home...auto.loans. <- cut(MasterData_woe$No.of.Inquiries.in.last.6.months..excluding.home...auto.loans.,breaks=c(0,1,2,3,5,Inf), labels = c(-0.71823049,0.17707210,0.21609676,0.50980053,0.01241548),right = FALSE )
sum(is.na(MasterData_woe$No.of.Inquiries.in.last.6.months..excluding.home...auto.loans.))


## woe No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.

sum(is.na(MasterData_woe$No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.))
MasterData_woe$No.of.Inquiries.in.last.12.months..excluding.home...auto.loans. <- cut(MasterData_woe$No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.,breaks=c(0,1,2,3,4,5,6,9,Inf), labels = c(-1.06753664,-0.06177455,0.14214469,0.16434931, 0.24810534,0.58818059,0.48413154,0.01370484),right = FALSE )
sum(is.na(MasterData_woe$No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.))


### WOE Presence.of.open.home.loan

sum(is.na(MasterData_woe$Presence.of.open.home.loan))
MasterData_woe$Presence.of.open.home.loan[which(is.na(MasterData_woe$Presence.of.open.home.loan))]  <- 0.003893111
sum(is.na(MasterData_woe$Presence.of.open.home.loan))
MasterData_woe$Presence.of.open.home.loan<- mapvalues(MasterData_woe$Presence.of.open.home.loan,from = c(0,1),to = c(0.07370543,-0.23665793))
sum(is.na(MasterData_woe$Presence.of.open.home.loan))


## WOE Outstanding.Balance
sum(is.na(MasterData_woe$Outstanding.Balance))
MasterData_woe$Outstanding.Balance[which(is.na(MasterData_woe$Outstanding.Balance))]  <- -0.3737974
sum(is.na(MasterData_woe$Outstanding.Balance))
MasterData_woe$Outstanding.Balance <- cut(MasterData_woe$Outstanding.Balance, breaks=c(0,6847,25522,386815,585423,774241,972456,1357399,2961005,3282409,Inf), labels = c(-0.7702840,-0.9203411,-0.1343423,0.2542645,0.4532364,0.4342640,0.4049624,-0.3824181,-0.8310260,0.2958682 ),right = FALSE )
sum(is.na(MasterData_woe$Outstanding.Balance))
## numeric conversion
## Due to some reasons NA are getting imputed , hence re imputing again
MasterData_woe$Outstanding.Balance <- as.numeric(as.character(MasterData_woe$Outstanding.Balance))
MasterData_woe$Outstanding.Balance[which(is.na(MasterData_woe$Outstanding.Balance))]  <- -0.3737974
sum(is.na(MasterData_woe$Outstanding.Balance))

## WOE  Total.No.of.Trades
sum(is.na(MasterData_woe$Total.No.of.Trades))
MasterData_woe$Total.No.of.Trades <- cut(MasterData_woe$Total.No.of.Trades, breaks=c(0,2,3,4,5,6,7,9,11,20,Inf), labels = c(-0.67304028,-1.01772550,-0.70202474,-0.44785257,-0.04880056,0.12930127,0.37936559,0.54394026,0.42717578,-0.06689796),right = FALSE )
sum(is.na(MasterData_woe$Total.No.of.Trades))


## WOE Presence.of.open.auto.loan
sum(is.na(MasterData_woe$Presence.of.open.auto.loan))
MasterData_woe$Presence.of.open.auto.loan  <- mapvalues(MasterData_woe$Presence.of.open.auto.loan,from = c(0,1),to = c(0.01198467,-0.13836752 ))
sum(is.na(MasterData_woe$Presence.of.open.auto.loan))


## WOE DTI 
sum(is.na(MasterData_woe$DTI))
MasterData_woe$DTI[which(is.na(MasterData_woe$DTI))]  <- -0.37379739 
sum(is.na(MasterData_woe$DTI))
MasterData_woe$DTI  <- cut(MasterData_woe$DTI, breaks=c(-7454876,218.78,1767.78,12863.98,23042.09,35982.75,56573.31,78136.47,111977.65,183321.71,Inf), labels = c(-0.77043065,-0.92019489,-0.17955374,0.32807817,0.34123250,0.14775437,-0.01623828,-0.10276040,0.29314203,0.16915951),right = FALSE )
sum(is.na(MasterData_woe$DTI))
# Removing  the NA as they have performance tag as '0' and number are 26 
MasterData_woe<-MasterData_woe[-which(is.na(MasterData_woe$DTI)),]


##  Then new data frame is created with the WOE value 
sum(is.na(MasterData_woe))  # Total 0's NA with 69837 values 

## Updating backup

Master_Sample_woe <- MasterData_woe



MasterData_woe_final<-MasterData_woe[,c(-2, -3, -4, -5, -7, -8, -9,  -26, -29)]
#MasterData_woe_final[]<-sapply(MasterData_woe_final, function(x) as.numeric(x))

sum(is.na(MasterData_woe_final))

#Income
MasterData_woe_final$Income <- as.numeric(as.character(MasterData_woe_final$Income))
# No.of.months.in.current.residence
MasterData_woe_final$No.of.months.in.current.residence <- as.numeric(as.character(MasterData_woe_final$No.of.months.in.current.residence))
# No.of.months.in.current.company
MasterData_woe_final$No.of.months.in.current.company <- as.numeric(as.character(MasterData_woe_final$No.of.months.in.current.company))
# Performance.Tag.Demo 
MasterData_woe_final$Performance.Tag.Demo <- as.factor(MasterData_woe_final$Performance.Tag.Demo)
# Avgas.CC.Utilization.in.last.12.months

MasterData_woe_final$Avgas.CC.Utilization.in.last.12.months <- as.numeric(as.character(MasterData_woe_final$Avgas.CC.Utilization.in.last.12.months))
# No.of.trades.opened.in.last.6.months

MasterData_woe_final$No.of.trades.opened.in.last.6.months <- as.numeric(as.character(MasterData_woe_final$No.of.trades.opened.in.last.6.months))
# No.of.trades.opened.in.last.12.months

MasterData_woe_final$No.of.trades.opened.in.last.12.months <- as.numeric(as.character(MasterData_woe_final$No.of.trades.opened.in.last.12.months))
# No.of.PL.trades.opened.in.last.6.months 

MasterData_woe_final$No.of.PL.trades.opened.in.last.6.months <- as.numeric(as.character(MasterData_woe_final$No.of.PL.trades.opened.in.last.6.months))
# No.of.PL.trades.opened.in.last.12.months
MasterData_woe_final$No.of.PL.trades.opened.in.last.12.months <- as.numeric(as.character(MasterData_woe_final$No.of.PL.trades.opened.in.last.12.months))
# No.of.Inquiries.in.last.6.months..excluding.home...auto.loans.

MasterData_woe_final$No.of.Inquiries.in.last.6.months..excluding.home...auto.loans. <- as.numeric(as.character(MasterData_woe_final$No.of.Inquiries.in.last.6.months..excluding.home...auto.loans.))
# No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.

MasterData_woe_final$No.of.Inquiries.in.last.12.months..excluding.home...auto.loans. <- as.numeric(as.character(MasterData_woe_final$No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.))
# Total.No.of.Trades
MasterData_woe_final$Total.No.of.Trades <- as.numeric(as.character(MasterData_woe_final$Total.No.of.Trades))

# Outstanding balance
MasterData_woe_final$Outstanding.Balance <- as.numeric(as.character(MasterData_woe_final$Outstanding.Balance))

# DTI 
MasterData_woe_final$DTI <- as.numeric(as.character(MasterData_woe_final$DTI))


###########  FINAL  DATA SET FOR APPROVED DATA SET #########
MasterData_woe_final


############### WOE  FOR THE REJECTRED DATA SET  ###### 

sum(is.na(MasterData__na$Age))
MasterData__na$Age<-cut(MasterData__na$Age, breaks=c(-3,31,36,39,42,45,48,51,54,58,Inf), labels = c(-0.041941665,0.034531539,0.069071901,0.068297625,-0.037941656,-0.003958667, -0.012629305,-0.136905430 ,0.043405263,-0.010013410),right = FALSE )
sum(is.na(MasterData__na$Age))
##WOE  Gender values
sum(is.na(MasterData__na$Gender))
MasterData__na$Gender<- mapvalues(MasterData__na$Gender,from = c("F","M"),to = c(0.03217430,-0.01010818))
sum(is.na(MasterData__na$Gender))

##WOE  Gender values Marital.Status..at.the.time.of.application.
sum(is.na(MasterData__na$Marital.Status..at.the.time.of.application.))
MasterData__na$Marital.Status..at.the.time.of.application.<- mapvalues(MasterData__na$Marital.Status..at.the.time.of.application.,from = c("Married","Single"),to = c(-0.003987254,0.023326708),warn_missing = TRUE)
sum(is.na(MasterData__na$Marital.Status..at.the.time.of.application.))
##WOE  Gender values No.of.dependents
sum(is.na(MasterData__na$No.of.dependents))
## There are 3 NAs in No of dependents with Performance tag '0' and OWE also 0 , hence discarded

MasterData__na$No.of.dependents<-mapvalues(MasterData__na$No.of.dependents,from = c(1,2,3,4,5),to = c(0.04008522,-0.08522163,0.05415544,-0.02520439,0.00439087))
sum(is.na(MasterData__na$No.of.dependents))


## WOE Income
sum(is.na(MasterData__na$Income))
MasterData__na$Income<-cut(MasterData__na$Income, breaks=c(-0.5,6,11,17,22,27,32,37,42,49,Inf), labels = c(0.30246890,0.27575091,0.06608894,0.08080252,0.02506399,0.07864867,-0.15595501,-0.26368117,-0.17686352,-0.36078566),right = FALSE )

sum(is.na(MasterData__na$Income))
## WOE Education
sum(is.na(MasterData__na$Education))
MasterData__na$Education<-mapvalues(MasterData__na$Education,from = c("Bachelor","Masters","Others","Phd","Professional"),to = c(0.017313988,0.007948702,0.492621513,-0.029511963,-0.017931398))
sum(is.na(MasterData__na$Education))

## WOE Profession
sum(is.na(MasterData__na$Profession))
MasterData__na$Profession<- mapvalues(MasterData__na$Profession,from = c("SAL","SE","SE_PROF"),to = c(-0.02806688,0.09142405,-0.01329769),warn_missing = TRUE)
sum(is.na(MasterData__na$Profession))

# WOE Type.of.residence
sum(is.na(MasterData__na$Type.of.residence))
MasterData__na$Type.of.residence<- mapvalues(MasterData__na$Type.of.residence,from = c("Company provided","Living with Parents","Others","Owned","Rented"),to = c(0.080146599,0.067530440,-0.530542104,0.004148595,-0.004293999))
sum(is.na(MasterData__na$Type.of.residence))


## WOE No.of.months.in.current.residence
sum(is.na(MasterData__na$No.of.months.in.current.residence))
MasterData__na$No.of.months.in.current.residence <-cut(MasterData__na$No.of.months.in.current.residence, breaks=c(6,10,29,50,73,98,Inf), labels = c(-0.27219153,0.49872310,0.30118432,0.13401754,0.13948089,-0.07705956), right = FALSE)
sum(is.na(MasterData__na$No.of.months.in.current.residence))

## WOE No.of.months.in.current.company
sum(is.na(MasterData__na$No.of.months.in.current.company))
MasterData__na$No.of.months.in.current.company <-cut(MasterData__na$No.of.months.in.current.company, breaks=c(3,6,13,20,27,34,41,48,54,62,Inf), labels = c(0.09851585,0.17548049,0.20630691,0.03919674,-0.08567605,0.03079397,-0.17614850,-0.21792183,-0.21640008,0.06288591),right = FALSE )
sum(is.na(MasterData__na$No.of.months.in.current.company))
## WOE No.of.times.90.DPD.or.worse.in.last.6.months

sum(is.na(MasterData__na$No.of.times.90.DPD.or.worse.in.last.6.months))
MasterData__na$No.of.times.90.DPD.or.worse.in.last.6.months <- mapvalues(MasterData__na$No.of.times.90.DPD.or.worse.in.last.6.months,from = c(0,1,2,3),to = c(-0.2606781,0.6224550,0.6224550,0.6224550))
sum(is.na(MasterData__na$No.of.times.90.DPD.or.worse.in.last.6.months))

## WOE No.of.times.60.DPD.or.worse.in.last.6.months
sum(is.na(MasterData__na$No.of.times.60.DPD.or.worse.in.last.6.months))
MasterData__na$No.of.times.60.DPD.or.worse.in.last.6.months <- mapvalues(MasterData__na$No.of.times.60.DPD.or.worse.in.last.6.months,from = c(0,1,2,3,4,5),to = c(-0.3363664,0.6225361,0.6225361,0.6225361,0.6225361,0.6225361))
sum(is.na(MasterData__na$No.of.times.60.DPD.or.worse.in.last.6.months))

## WOE No.of.times.30.DPD.or.worse.in.last.6.months
sum(is.na(MasterData__na$No.of.times.30.DPD.or.worse.in.last.6.months))
MasterData__na$No.of.times.30.DPD.or.worse.in.last.6.months <- mapvalues(MasterData__na$No.of.times.30.DPD.or.worse.in.last.6.months,from = c(0,1,2,3,4,5,6,7),to = c(-0.3867918,0.4643187,0.7428448,0.7428448,0.7428448,0.7428448,0.7428448,0.7428448))
sum(is.na(MasterData__na$No.of.times.30.DPD.or.worse.in.last.6.months))


## WOE No.of.times.90.DPD.or.worse.in.last.12.months
sum(is.na(MasterData__na$No.of.times.90.DPD.or.worse.in.last.12.months))
MasterData__na$No.of.times.90.DPD.or.worse.in.last.12.months <- mapvalues(MasterData__na$No.of.times.90.DPD.or.worse.in.last.12.months,from = c(0,1,2,3,4,5),to = c(-0.3566331,0.5088234,0.7219824,0.7219824,0.7219824,0.7219824))
sum(is.na(MasterData__na$No.of.times.90.DPD.or.worse.in.last.12.months))

## WOE No.of.times.60.DPD.or.worse.in.last.12.months
sum(is.na(MasterData__na$No.of.times.60.DPD.or.worse.in.last.12.months))
MasterData__na$No.of.times.60.DPD.or.worse.in.last.12.months <- mapvalues(MasterData__na$No.of.times.60.DPD.or.worse.in.last.12.months,from = c(0,1,2,3,4,5,6,7),to = c(-0.3519211,0.2141538,0.6940858,0.6940858,0.6940858,0.6940858,0.6940858,0.6940858))
sum(is.na(MasterData__na$No.of.times.60.DPD.or.worse.in.last.12.months))

## WOE No.of.times.30.DPD.or.worse.in.last.12.months
sum(is.na(MasterData__na$No.of.times.30.DPD.or.worse.in.last.12.months))
MasterData__na$No.of.times.30.DPD.or.worse.in.last.12.months <- mapvalues(MasterData__na$No.of.times.30.DPD.or.worse.in.last.12.months,from = c(0,1,2,3,4,5,6,7,8,9),to = c(-0.3763960,0.2805525,0.2805525,0.7994935,0.7994935,0.7994935,0.7994935,0.7994935,0.7994935,0.7994935))
sum(is.na(MasterData__na$No.of.times.30.DPD.or.worse.in.last.12.months))

## WOE Avgas.CC.Utilization.in.last.12.months

sum(is.na(MasterData__na$Avgas.CC.Utilization.in.last.12.months))
MasterData__na$Avgas.CC.Utilization.in.last.12.months[which(is.na(MasterData__na$Avgas.CC.Utilization.in.last.12.months))]  <- 0.11147371
sum(is.na(MasterData__na$Avgas.CC.Utilization.in.last.12.months))
MasterData__na$Avgas.CC.Utilization.in.last.12.months <-cut(MasterData__na$Avgas.CC.Utilization.in.last.12.months, breaks=c(0,5,7,9,12,15,22,38,52,72,Inf), labels = c(-0.80175843,-0.80150239,-0.79452312,-0.67240619,-0.46800192,-0.07900431,0.47504577,0.58458900,0.56373098,0.38134147),right = FALSE )
sum(is.na(MasterData__na$Avgas.CC.Utilization.in.last.12.months))


# Keeping Avg data in numeric form


## WOE No.of.trades.opened.in.last.6.months

sum(is.na(MasterData__na$No.of.trades.opened.in.last.6.months)) # 1 NA vaue with perfromance tag as 0 , hene removing
MasterData__na$No.of.trades.opened.in.last.6.months <- cut(MasterData__na$No.of.trades.opened.in.last.6.months, breaks=c(0,1,2,3,4,5,Inf), labels = c(-0.6576285,-0.4795153,0.2328610,0.4351239,0.5242769,0.1368556 ),right = FALSE )
sum(is.na(MasterData__na$No.of.trades.opened.in.last.6.months))


## WOE No.of.trades.opened.in.last.12.months
sum(is.na(MasterData__na$No.of.trades.opened.in.last.12.months))
MasterData__na$No.of.trades.opened.in.last.12.months <- cut(MasterData__na$No.of.trades.opened.in.last.12.months, breaks=c(0,1,2,3,4,6,8,10,13,Inf), labels = c(-0.653462151,-1.019086045,-0.816468838,0.003598878,0.109294271,0.447981607,0.571340073,0.491781025,0.006306206),right = FALSE )
sum(is.na(MasterData__na$No.of.trades.opened.in.last.12.months))

##   WOE No.of.PL.trades.opened.in.last.6.months
sum(is.na(MasterData__na$No.of.PL.trades.opened.in.last.6.months))
MasterData__na$No.of.PL.trades.opened.in.last.6.months <- cut(MasterData__na$No.of.PL.trades.opened.in.last.6.months, breaks=c(0,1,2,3,Inf), labels = c(-0.6492118,0.1993619,0.4384356,0.3619618),right = FALSE )
sum(is.na(MasterData__na$No.of.PL.trades.opened.in.last.6.months))

##   WOE No.of.PL.trades.opened.in.last.12.months
sum(is.na(MasterData__na$No.of.PL.trades.opened.in.last.12.months))
MasterData__na$No.of.PL.trades.opened.in.last.12.months <- cut(MasterData__na$No.of.PL.trades.opened.in.last.12.months, breaks=c(0,1,2,3,4,5,6,Inf), labels = c(-0.8938108,-0.1310168,0.2513399,0.4122959,0.5000753,0.4261494,0.2431575),right = FALSE )
sum(is.na(MasterData__na$No.of.PL.trades.opened.in.last.12.months))


## WOE No.of.Inquiries.in.last.6.months..excluding.home...auto.loans.
sum(is.na(MasterData__na$No.of.Inquiries.in.last.6.months..excluding.home...auto.loans.))
MasterData__na$No.of.Inquiries.in.last.6.months..excluding.home...auto.loans. <- cut(MasterData__na$No.of.Inquiries.in.last.6.months..excluding.home...auto.loans.,breaks=c(0,1,2,3,5,Inf), labels = c(-0.71823049,0.17707210,0.21609676,0.50980053,0.01241548),right = FALSE )
sum(is.na(MasterData__na$No.of.Inquiries.in.last.6.months..excluding.home...auto.loans.))


## woe No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.

sum(is.na(MasterData__na$No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.))
MasterData__na$No.of.Inquiries.in.last.12.months..excluding.home...auto.loans. <- cut(MasterData__na$No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.,breaks=c(0,1,2,3,4,5,6,9,Inf), labels = c(-1.06753664,-0.06177455,0.14214469,0.16434931, 0.24810534,0.58818059,0.48413154,0.01370484),right = FALSE )
sum(is.na(MasterData__na$No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.))


### WOE Presence.of.open.home.loan

sum(is.na(MasterData__na$Presence.of.open.home.loan))
#MasterData__na$Presence.of.open.home.loan[which(is.na(MasterData__na$Presence.of.open.home.loan))]  <- 0.003893111
sum(is.na(MasterData__na$Presence.of.open.home.loan))
MasterData__na$Presence.of.open.home.loan<- mapvalues(MasterData__na$Presence.of.open.home.loan,from = c(0,1),to = c(0.07370543,-0.23665793))
sum(is.na(MasterData__na$Presence.of.open.home.loan))


## WOE Outstanding.Balance
sum(is.na(MasterData__na$Outstanding.Balance))
#MasterData__na$Outstanding.Balance[which(is.na(MasterData__na$Outstanding.Balance))]  <- -0.3737974
sum(is.na(MasterData__na$Outstanding.Balance))
MasterData__na$Outstanding.Balance <- cut(MasterData__na$Outstanding.Balance, breaks=c(0,6847,25522,386815,585423,774241,972456,1357399,2961005,3282409,Inf), labels = c(-0.7702840,-0.9203411,-0.1343423,0.2542645,0.4532364,0.4342640,0.4049624,-0.3824181,-0.8310260,0.2958682 ),right = FALSE )
sum(is.na(MasterData__na$Outstanding.Balance))
## numeric conversion


## WOE  Total.No.of.Trades
sum(is.na(MasterData__na$Total.No.of.Trades))
MasterData__na$Total.No.of.Trades <- cut(MasterData__na$Total.No.of.Trades, breaks=c(0,2,3,4,5,6,7,9,11,20,Inf), labels = c(-0.67304028,-1.01772550,-0.70202474,-0.44785257,-0.04880056,0.12930127,0.37936559,0.54394026,0.42717578,-0.06689796),right = FALSE )
sum(is.na(MasterData__na$Total.No.of.Trades))


## WOE Presence.of.open.auto.loan
sum(is.na(MasterData__na$Presence.of.open.auto.loan))
MasterData__na$Presence.of.open.auto.loan  <- mapvalues(MasterData__na$Presence.of.open.auto.loan,from = c(0,1),to = c(0.01198467,-0.13836752 ))
sum(is.na(MasterData__na$Presence.of.open.auto.loan))

## WOE for DTI

sum(is.na(MasterData__na$DTI))
MasterData__na$DTI  <- cut(MasterData__na$DTI, breaks=c(-7454876,218.78,1767.78,12863.98,23042.09,35982.75,56573.31,78136.47,111977.65,183321.71,Inf), labels = c(-0.77043065,-0.92019489,-0.17955374,0.32807817,0.34123250,0.14775437,-0.01623828,-0.10276040,0.29314203,0.16915951),right = FALSE )
sum(is.na(MasterData__na$DTI))

sum(is.na(MasterData__na)) #1425

MasterData__na$Performance.Tag.Demo <- 1
sum(is.na(MasterData__na)) # 0
# Backup of data set
MasterData__na_backup <- MasterData__na
# Re take 
MasterData__na <- MasterData__na_backup
MasterData__na<-MasterData__na[,c( -2, -3, -4, -5, -7, -8, -9,  -26, -29)]


#Income
MasterData__na$Income <- as.numeric(as.character(MasterData__na$Income))
# No.of.months.in.current.residence
MasterData__na$No.of.months.in.current.residence <- as.numeric(as.character(MasterData__na$No.of.months.in.current.residence))
# No.of.months.in.current.company
MasterData__na$No.of.months.in.current.company <- as.numeric(as.character(MasterData__na$No.of.months.in.current.company))
# Performance.Tag.Demo 
MasterData__na$Performance.Tag.Demo <- as.factor(MasterData__na$Performance.Tag.Demo)
# Avgas.CC.Utilization.in.last.12.months

MasterData__na$Avgas.CC.Utilization.in.last.12.months <- as.numeric(as.character(MasterData__na$Avgas.CC.Utilization.in.last.12.months))
# No.of.trades.opened.in.last.6.months

MasterData__na$No.of.trades.opened.in.last.6.months <- as.numeric(as.character(MasterData__na$No.of.trades.opened.in.last.6.months))
# No.of.trades.opened.in.last.12.months

MasterData__na$No.of.trades.opened.in.last.12.months <- as.numeric(as.character(MasterData__na$No.of.trades.opened.in.last.12.months))
# No.of.PL.trades.opened.in.last.6.months 

MasterData__na$No.of.PL.trades.opened.in.last.6.months <- as.numeric(as.character(MasterData__na$No.of.PL.trades.opened.in.last.6.months))
# No.of.PL.trades.opened.in.last.12.months
MasterData__na$No.of.PL.trades.opened.in.last.12.months <- as.numeric(as.character(MasterData__na$No.of.PL.trades.opened.in.last.12.months))
# No.of.Inquiries.in.last.6.months..excluding.home...auto.loans.

MasterData__na$No.of.Inquiries.in.last.6.months..excluding.home...auto.loans. <- as.numeric(as.character(MasterData__na$No.of.Inquiries.in.last.6.months..excluding.home...auto.loans.))
# No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.

MasterData__na$No.of.Inquiries.in.last.12.months..excluding.home...auto.loans. <- as.numeric(as.character(MasterData__na$No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.))
# Total.No.of.Trades
MasterData__na$Total.No.of.Trades <- as.numeric(as.character(MasterData__na$Total.No.of.Trades))

# Outstanding balance
MasterData__na$Outstanding.Balance <- as.numeric(as.character(MasterData__na$Outstanding.Balance))

# DTI 
MasterData__na$DTI <- as.numeric(as.character(MasterData__na$DTI))

#######  FINAL MODEL CREATD FOR THE   na DATA SET 

MasterData__na

##############################  MODELLING  ###########################3


# Starting  with logictic regression 

set.seed(2)
train.indices = sample(1:nrow(MasterData_woe_final), 0.7*nrow(MasterData_woe_final))

train = MasterData_woe_final[train.indices, ]
test = MasterData_woe_final[-train.indices, ]
#Logistics reggression using highly significant values from the VIF outcome#
logistic_1<-glm(formula=train$Performance.Tag.Demo ~ Avgas.CC.Utilization.in.last.12.months+
                  No.of.trades.opened.in.last.12.months+No.of.PL.trades.opened.in.last.12.months
                +No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.+
                  Outstanding.Balance+No.of.times.30.DPD.or.worse.in.last.6.months+
                  Total.No.of.Trades+No.of.PL.trades.opened.in.last.6.months+
                  No.of.times.90.DPD.or.worse.in.last.12.months+
                  No.of.times.60.DPD.or.worse.in.last.6.months+
                  No.of.Inquiries.in.last.6.months..excluding.home...auto.loans.+
                  No.of.times.30.DPD.or.worse.in.last.12.months+
                  No.of.trades.opened.in.last.6.months+
                  No.of.times.60.DPD.or.worse.in.last.12.months+
                  No.of.times.90.DPD.or.worse.in.last.6.months+DTI+
                  No.of.months.in.current.residence+Income+
                  No.of.months.in.current.company, family = "binomial", data = train)
predictions_logit_1 <- predict(logistic_1, test, type = "response")

#Logistic regression using the variables find wtih P value less than 0.10 as more significant values#
logistic_2<-glm(formula=train$Performance.Tag.Demo ~ Avgas.CC.Utilization.in.last.12.months+
                  No.of.trades.opened.in.last.12.months+
                  No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.+
                  Outstanding.Balance+No.of.times.30.DPD.or.worse.in.last.6.months+
                  No.of.times.90.DPD.or.worse.in.last.12.months+
                  No.of.times.30.DPD.or.worse.in.last.12.months+
                  No.of.times.90.DPD.or.worse.in.last.6.months+Income+
                  No.of.months.in.current.company, family = "binomial", data = train)

predictions_logit_2 <- predict(logistic_2, test, type = "response")
# Cut off 0.0455 is calculated below 
predicted_response_2 <- factor(ifelse(predictions_logit_2 >= 0.0455, "1", "0"))


confusionMatrix(predicted_response_2, test$Performance.Tag.Demo, positive = "1")

#Confusion Matrix and Statistics

#Reference
#Prediction     0     1
#            0 12267   326
#            1  7814   545

#Accuracy : 0.611              
#95% CI : (0.605, 0.618)     
#No Information Rate : 0.958              
#P-Value [Acc > NIR] : 1                  

#Kappa : 0.046              
#Mcnemar's Test P-Value : <0.0000000000000002

#Sensitivity : 0.6257             
#Specificity : 0.6109             
#Pos Pred Value : 0.0652             
#Neg Pred Value : 0.9741             
#Prevalence : 0.0416             
#Detection Rate : 0.0260             
#Detection Prevalence : 0.3990             
#Balanced Accuracy : 0.6183             

#'Positive' Class : 1  



###  Finding the optimal cut off fo rthe model 
perform_fn <- function(cutoff) 
{
  predicted_response <- factor(ifelse(predictions_logit_2 >= cutoff, "1", "0"))
  conf <- confusionMatrix(predicted_response, test$Performance.Tag.Demo, positive = "1")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  out <- t(as.matrix(c(sens, spec, acc))) 
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  return(out)
}


s = seq(.01,.99,length=100)

OUT = matrix(0,100,3)


for(i in 1:100)
{
  OUT[i,] = perform_fn(s[i])
} 


# plotting cutoffs 
plot(s, OUT[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)
axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
lines(s,OUT[,2],col="darkgreen",lwd=2)
lines(s,OUT[,3],col=4,lwd=2)

box()
legend(0,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))


## Fiidng the absolute  cut off  
cutoff <- s[which(abs(OUT[,1]-OUT[,2])<0.075)] # 0.049
## NOTE : Ideally we should used the cut off 0.049 but when we check with 0.045
## we got better  accuracy/sensitivty/specitivity
# above methods and  cut off plot gave us good insight to get the cut off


### Plotting the AUC and finding the  optimal value
pred<-prediction(predictions_logit_2,test$Performance.Tag.Demo)

#evaluation of accuracy of model#
eval<-performance(pred,"acc")
plot(eval)
abline(h=0.95, v=0.098)

#finding the maximum probability for high accuracy or sensitivity#
max<-which.max(slot(eval, "y.values")[[1]])
acc<-slot(eval,"y.values")[[1]][max]
cut<-slot(eval,"x.values")[[1]][max]

#plotting ROC curve#
roc<-performance(pred,'tpr','fpr')
plot(roc)
abline(a=0,b=1)
plot(roc, colorize=T,ylab="Sensitivity",xlab="1-specificity")

#Finding the auc of the curve to find if the model is good enough to predict#
auc<-performance(pred,'auc')
auc<-unlist(slot(auc,"y.values"))
auc<-round(auc,4)
auc<-unlist(slot(auc,"y.values"))
legend(0.6,0.4,auc,title="AUC")
auc<-round(auc,4)
#0.6643

## Hence the AUC value  is 0.6643 , signifies the goodness of fit of the model 



########## Validation of logistic on NA / Rejected data set 


predictions_logit_na <- predict(logistic_2, MasterData__na, type = "response")

predicted_response_na <- factor(ifelse(predictions_logit_na >= 0.0455, "1", "0"))


summary(predicted_response_na)
#0    1 
#10 1415

## Hence the  logictic modle able to predict 99.29 % accuracy that customer will be defaulted 


###################### END OF LOGICTIC MODEL ########################



############################ RANDOM FOREST MODEL ######################

# Modeling using RandomForest 
str(MasterData_woe)

# Remove the variables with IV lower that 0.02
MasterData_woe_final_1<-MasterData_woe[,c(-1, -2, -3, -4, -5, -7, -8, -9,  -26, -29)]
#Income
MasterData_woe_final_1$Income <- as.numeric(as.character(MasterData_woe_final$Income))
# No.of.months.in.current.residence
MasterData_woe_final_1$No.of.months.in.current.residence <- as.numeric(as.character(MasterData_woe_final$No.of.months.in.current.residence))
# No.of.months.in.current.company
MasterData_woe_final_1$No.of.months.in.current.company <- as.numeric(as.character(MasterData_woe_final$No.of.months.in.current.company))
# Performance.Tag.Demo 
MasterData_woe_final_1$Performance.Tag.Demo <- as.factor(MasterData_woe_final$Performance.Tag.Demo)
# Avgas.CC.Utilization.in.last.12.months

MasterData_woe_final_1$Avgas.CC.Utilization.in.last.12.months <- as.numeric(as.character(MasterData_woe_final$Avgas.CC.Utilization.in.last.12.months))
# No.of.trades.opened.in.last.6.months

MasterData_woe_final_1$No.of.trades.opened.in.last.6.months <- as.numeric(as.character(MasterData_woe_final$No.of.trades.opened.in.last.6.months))
# No.of.trades.opened.in.last.12.months

MasterData_woe_final_1$No.of.trades.opened.in.last.12.months <- as.numeric(as.character(MasterData_woe_final$No.of.trades.opened.in.last.12.months))
# No.of.PL.trades.opened.in.last.6.months 

MasterData_woe_final_1$No.of.PL.trades.opened.in.last.6.months <- as.numeric(as.character(MasterData_woe_final$No.of.PL.trades.opened.in.last.6.months))
# No.of.PL.trades.opened.in.last.12.months
MasterData_woe_final_1$No.of.PL.trades.opened.in.last.12.months <- as.numeric(as.character(MasterData_woe_final$No.of.PL.trades.opened.in.last.12.months))
# No.of.Inquiries.in.last.6.months..excluding.home...auto.loans.

MasterData_woe_final_1$No.of.Inquiries.in.last.6.months..excluding.home...auto.loans. <- as.numeric(as.character(MasterData_woe_final$No.of.Inquiries.in.last.6.months..excluding.home...auto.loans.))
# No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.

MasterData_woe_final_1$No.of.Inquiries.in.last.12.months..excluding.home...auto.loans. <- as.numeric(as.character(MasterData_woe_final$No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.))
# Total.No.of.Trades
MasterData_woe_final_1$Total.No.of.Trades <- as.numeric(as.character(MasterData_woe_final$Total.No.of.Trades))

# Outstanding balance
MasterData_woe_final_1$Outstanding.Balance <- as.numeric(as.character(MasterData_woe_final$Outstanding.Balance))

# DTI 
MasterData_woe_final_1$DTI <- as.numeric(as.character(MasterData_woe_final$DTI))



library(caTools)

# Split the data into train and test data set
set.seed(100)
split_data<-sample.split(MasterData_woe_final_1$Performance.Tag.Demo, SplitRatio = 0.7)
table(split_data)
MasterData_train<-MasterData_woe_final_1[split_data,]
MasterData_test<-MasterData_woe_final_1[!(split_data),]

library(randomForest)
library(caret)
library(e1071)
library(ROSE)
install.packages("ROSE")
library(pROC)
install.packages("DMwR")
library(DMwR)

# Building a classifier using the data as it is, would in most cases give us a prediction model
# that always returns the majority class. The classifier would be biased.

# BUILDING WITH DEFAULT DATA

# Build random forest model
RFmodel_original<-randomForest(Performance.Tag.Demo ~ ., data = MasterData_train, do.trace=100)

# > RFmodel_original
# 
# Call:
#   randomForest(formula = Performance.Tag.Demo ~ ., data = MasterData_train,      do.trace = 100) 
# Type of random forest: classification
# Number of trees: 500
# No. of variables tried at each split: 4
# 
# OOB estimate of  error rate: 4.22%
# Confusion matrix:
#   0 1  class.error
# 0 46821 2 4.271405e-05
# 1  2063 0 1.000000e+00


RFmodel_original_predict<-predict(RFmodel_original, MasterData_test[,-4])

confusionMatrix(RFmodel_original_predict, MasterData_test[,4], positive = '1')

# Confusion Matrix and Statistics
# 
# Reference
# Prediction     0     1
# 0 20067   884
# 1     0     0
# 
# Accuracy : 0.9578         
# 95% CI : (0.955, 0.9605)
# No Information Rate : 0.9578         
# P-Value [Acc > NIR] : 0.5089         
# 
# Kappa : 0              
# Mcnemar's Test P-Value : <2e-16         
# 
# Sensitivity : 0.00000        
# Specificity : 1.00000        
# Pos Pred Value :     NaN        
# Neg Pred Value : 0.95781        
# Prevalence : 0.04219        
# Detection Rate : 0.00000        
# Detection Prevalence : 0.00000        
# Balanced Accuracy : 0.50000        
# 
# 'Positive' Class : 1                         

auc(MasterData_test[,4], as.numeric(RFmodel_original_predict))
#Area under the curve: 0.5

plot.roc(roc(MasterData_test[,4], as.numeric(RFmodel_original_predict)))

# ====================================================================================

# UNDERSAMPLE THE MAJORITY CLASS

# Get the number of minority observations
rows_minority <- sum(MasterData_train$Performance.Tag.Demo == "1")

# Get the majority and minority observations separately
training_data_minority <- MasterData_train[MasterData_train$Performance.Tag.Demo == "1", ]
training_data_majority <- MasterData_train[MasterData_train$Performance.Tag.Demo == "0", ] 

# randomly select the observation of majority class eual to number of observation of minority class
indices <- sample(nrow(training_data_majority), rows_minority)
training_data_majority <- training_data_majority[indices, ]

# Combine the majority and minority class to create final unsersample dataset
training_data <- rbind(training_data_minority, training_data_majority)

RFmodel_undersample<-randomForest(Performance.Tag.Demo ~ ., data = training_data,
                                  do.trace=100, sampsize = c(nrow(training_data_minority), nrow(training_data_minority)))

RFmodel_undersample

# Call:
#   randomForest(formula = Performance.Tag.Demo ~ ., data = training_data,      do.trace = 100, sampsize = c(nrow(training_data_minority),          nrow(training_data_minority))) 
# Type of random forest: classification
# Number of trees: 500
# No. of variables tried at each split: 4
# 
# OOB estimate of  error rate: 37.23%
# Confusion matrix:
#   0    1 class.error
# 0 1207  856   0.4149297
# 1  680 1383   0.3296171

RFmodel_undersample_predict <- predict(RFmodel_undersample, MasterData_test[,-4])
confusionMatrix(RFmodel_undersample_predict, MasterData_test[,4], positive = '1')

# Confusion Matrix and Statistics
# 
# Reference
# Prediction     0     1
# 0 11485   311
# 1  8582   573
# 
# Accuracy : 0.5755          
# 95% CI : (0.5688, 0.5822)
# No Information Rate : 0.9578          
# P-Value [Acc > NIR] : 1               
# 
# Kappa : 0.0403          
# Mcnemar's Test P-Value : <2e-16          
# 
# Sensitivity : 0.64819         
# Specificity : 0.57233         
# Pos Pred Value : 0.06259         
# Neg Pred Value : 0.97364         
# Prevalence : 0.04219         
# Detection Rate : 0.02735         
# Detection Prevalence : 0.43697         
# Balanced Accuracy : 0.61026         
# 
# 'Positive' Class : 1                

auc(MasterData_test[,4], as.numeric(RFmodel_undersample_predict))
# Area under the curve: 0.6103

plot.roc(roc(MasterData_test[,4], as.numeric(RFmodel_undersample_predict)))

# ====================================================================================

# OVERSAMPLE THE MINORITY CLASS 

# =========================== OVERSAMPLING USING SMOTE Algorithm =====================

summary(MasterData_train$Performance.Tag.Demo)

training_data_smote<-SMOTE(Performance.Tag.Demo ~ ., MasterData_train)
summary(training_data_smote$Performance.Tag.Demo)

RFmodel_smote<-randomForest(Performance.Tag.Demo ~ ., data = training_data_smote, do.trace=10)
RFmodel_smote

# Call:
#   randomForest(formula = Performance.Tag.Demo ~ ., data = training_data_smote,      do.trace = 10) 
# Type of random forest: classification
# Number of trees: 500
# No. of variables tried at each split: 4
# 
# OOB estimate of  error rate: 13.72%
# Confusion matrix:
#   0    1 class.error
# 0 7957  295  0.03574891
# 1 1686 4503  0.27241881

RFmodel_smote_predict <- predict(RFmodel_smote, MasterData_test[,-4])
confusionMatrix(RFmodel_smote_predict, MasterData_test[,4], positive = '1')

# Confusion Matrix and Statistics
# 
# Reference
# Prediction     0     1
# 0 19230   817
# 1   837    67
# 
# Accuracy : 0.9211          
# 95% CI : (0.9173, 0.9247)
# No Information Rate : 0.9578          
# P-Value [Acc > NIR] : 1.0000          
# 
# Kappa : 0.0337          
# Mcnemar's Test P-Value : 0.6404          
# 
# Sensitivity : 0.075792        
# Specificity : 0.958290        
# Pos Pred Value : 0.074115        
# Neg Pred Value : 0.959246        
# Prevalence : 0.042194        
# Detection Rate : 0.003198        
# Detection Prevalence : 0.043148        
# Balanced Accuracy : 0.517041        
# 
# 'Positive' Class : 1     

auc(MasterData_test[,4], as.numeric(RFmodel_smote_predict))
# Area under the curve: 0.517

plot.roc(roc(MasterData_test[,4], as.numeric(RFmodel_smote_predict)))

# =========================== OVERSAMPLING USING ROSE Algorithm =====================

summary(MasterData_train$Performance.Tag.Demo)
training_data_rose<-ovun.sample(Performance.Tag.Demo ~ ., data=MasterData_train, method = "over", seed = 2)$data
summary(training_data_rose$Performance.Tag.Demo)

RFmodel_rose<-randomForest(Performance.Tag.Demo ~ ., data = training_data_rose, do.trace=10)
RFmodel_rose

# Call:
#   randomForest(formula = Performance.Tag.Demo ~ ., data = training_data_rose,      do.trace = 10) 
# Type of random forest: classification
# Number of trees: 500
# No. of variables tried at each split: 4
# 
# OOB estimate of  error rate: 1.1%
# Confusion matrix:
#   0     1 class.error
# 0 46366   457 0.009760161
# 1   573 46448 0.012186045

RFmodel_rose_predict <- predict(RFmodel_rose, MasterData_test[,-4])
confusionMatrix(RFmodel_rose_predict, MasterData_test[,4], positive = '1')

# Confusion Matrix and Statistics
# 
# Reference
# Prediction     0     1
# 0 19853   876
# 1   214     8
# 
# Accuracy : 0.948           
# 95% CI : (0.9449, 0.9509)
# No Information Rate : 0.9578          
# P-Value [Acc > NIR] : 1               
# 
# Kappa : -0.0025         
# Mcnemar's Test P-Value : <2e-16          
# 
# Sensitivity : 0.0090498       
# Specificity : 0.9893357       
# Pos Pred Value : 0.0360360       
# Neg Pred Value : 0.9577404       
# Prevalence : 0.0421937       
# Detection Rate : 0.0003818       
# Detection Prevalence : 0.0105962       
# Balanced Accuracy : 0.4991927       
# 
# 'Positive' Class : 1       

auc(MasterData_test[,4], as.numeric(RFmodel_rose_predict))
# Area under the curve: 0.4992

plot.roc(roc(MasterData_test[,4], as.numeric(RFmodel_rose_predict)))


# ====================================================================================

# RF MODELING WITH CROSS-VALIDATION OF DATASET WHILE TRAINING

mtry <- sqrt(ncol(MasterData_train))
control <- trainControl(method="repeatedcv", number=10, repeats=3)
metric <- "Accuracy"
tunegrid <- expand.grid(.mtry=mtry)

library(devtools)

# Work around for bug in caret's train function

require(caret); library(doParallel); 
cl <- makePSOCKcluster(detectCores()); 
clusterEvalQ(cl, library(foreach)); registerDoParallel(cl)

RFmodel_cv <- train(Performance.Tag.Demo ~ ., data = MasterData_train, method="rf", metric=metric, tuneGrid=tunegrid, trControl=control)

RFmodel_cv
# Random Forest 
# 
# 48886 samples
# 19 predictor
# 2 classes: '0', '1' 
# 
# No pre-processing
# Resampling: Cross-Validated (10 fold, repeated 3 times) 
# Summary of sample sizes: 43998, 43997, 43997, 43998, 43997, 43998, ... 
# Resampling results:
#   
#   Accuracy   Kappa        
# 0.9577657  -6.787916e-05
# 
# Tuning parameter 'mtry' was held constant at a value of 4.472136

RFmodel_cv_predict <- predict(RFmodel_cv, MasterData_test[,-4])
confusionMatrix(RFmodel_cv_predict, MasterData_test[,4], positive='1')

# Confusion Matrix and Statistics
# 
# Reference
# Prediction     0     1
# 0 20066   884
# 1     1     0
# 
# Accuracy : 0.9578          
# 95% CI : (0.9549, 0.9604)
# No Information Rate : 0.9578          
# P-Value [Acc > NIR] : 0.5226          
# 
# Kappa : -1e-04          
# Mcnemar's Test P-Value : <2e-16          
# 
# Sensitivity : 0.000e+00       
# Specificity : 1.000e+00       
# Pos Pred Value : 0.000e+00       
# Neg Pred Value : 9.578e-01       
# Prevalence : 4.219e-02       
# Detection Rate : 0.000e+00       
# Detection Prevalence : 4.773e-05       
# Balanced Accuracy : 5.000e-01       
# 
# 'Positive' Class : 1

auc(MasterData_test[,4], as.numeric(RFmodel_cv_predict))
# Area under the curve: 0.5

plot.roc(roc(MasterData_test[,4], as.numeric(RFmodel_cv_predict)))

stopCluster(cl);

# =======================================================================================

# RF MODELING WITH TUNING HYPER-PARAMETERS
library(randomForest)
RFmodel_hyper<-randomForest(Performance.Tag.Demo ~ ., data = MasterData_train, do.trace=10, sampsize=c('0'=500, '1'=500), strata = as.factor(MasterData_train$Performance.Tag.Demo))

RFmodel_hyper_predict <- predict(RFmodel_hyper, MasterData_test[,-4])
confusionMatrix(RFmodel_hyper_predict, MasterData_test[,4], positive = '1')

# Confusion Matrix and Statistics
# 
# Reference
# Prediction     0     1
# 0 12224   311
# 1  7843   573
# 
# Accuracy : 0.6108          
# 95% CI : (0.6042, 0.6174)
# No Information Rate : 0.9578          
# P-Value [Acc > NIR] : 1               
# 
# Kappa : 0.0507          
# Mcnemar's Test P-Value : <2e-16          
#                                           
#             Sensitivity : 0.64819         
#             Specificity : 0.60916         
#          Pos Pred Value : 0.06808         
#          Neg Pred Value : 0.97519         
#              Prevalence : 0.04219         
#          Detection Rate : 0.02735         
#    Detection Prevalence : 0.40170         
#       Balanced Accuracy : 0.62867         
#                                           
#        'Positive' Class : 1     

auc(MasterData_test[,4], as.numeric(RFmodel_hyper_predict))
# Area under the curve: 0.6287

plot.roc(roc(MasterData_test[,4], as.numeric(RFmodel_hyper_predict)))

varImpPlot(RFmodel_hyper)

# =====================================================================================================

# MODELING USING DEMOGRAPHIC DATASET

# Create the WOE dataset for Demographic dataset
str(DemoGData)
str(MasterData_woe)

DemoGData_WOE<-MasterData_woe[,1:12]
str(DemoGData_WOE)

# remove ApplicationId from the dataset
DemoGData_WOE_final<-DemoGData_WOE[,-1]
DemoGData_WOE_final[]<-sapply(DemoGData_WOE_final, function(x) as.numeric(x))

sum(is.na(DemoGData_WOE_final))

#remove NAs
DemoGData_WOE_final<-DemoGData_WOE_final[-which(is.na(DemoGData_WOE_final$Education)),]
DemoGData_WOE_final<-DemoGData_WOE_final[-which(is.na(DemoGData_WOE_final$Profession)),]
DemoGData_WOE_final<-DemoGData_WOE_final[-which(is.na(DemoGData_WOE_final$Type.of.residence)),]
DemoGData_WOE_final<-DemoGData_WOE_final[-which(is.na(DemoGData_WOE_final$Marital.Status..at.the.time.of.application.)),]
DemoGData_WOE_final<-DemoGData_WOE_final[-which(is.na(DemoGData_WOE_final$Gender)),]

# Split the data into train and test data set
set.seed(101)
DemoSplit_data<-sample.split(DemoGData_WOE_final$Performance.Tag.Demo, SplitRatio = 0.7)
table(DemoSplit_data)
Demo_train<-DemoGData_WOE_final[DemoSplit_data,]
Demo_test<-DemoGData_WOE_final[!(DemoSplit_data),]

# Logistic Regression
Demologistic_1<-glm(Performance.Tag.Demo ~ ., family = "binomial", data=Demo_train )

summary(Demologistic_1)

library(MASS)
library(car)

# Using stepwise algorithm for removing insignificant variables 
stepAIC(Demologistic_1, direction = "both")

Demologistic_2<-glm(formula = Performance.Tag.Demo ~ No.of.dependents + Income + 
                      Profession + No.of.months.in.current.residence + No.of.months.in.current.company, 
                    family = "binomial", data = Demo_train)

# checking vif for logistic_2 
vif(Demologistic_2)

summary(Demologistic_2)

Demologistic_3<-glm(formula = Performance.Tag.Demo ~ No.of.dependents + Income + 
                      No.of.months.in.current.residence + No.of.months.in.current.company, 
                    family = "binomial", data = Demo_train)

# checking vif for Demologistic_3 
vif(Demologistic_3)

summary(Demologistic_3)

# Check for multi-corlinearity. 
cor(Demo_train$No.of.dependents, Demo_train$No.of.months.in.current.residence)

predictions_logit <- predict(Demologistic_3, newdata = Demo_test, type = "response")
summary(predictions_logit)

# Let's find out the optimal probalility cutoff 
perform_fn <- function(cutoff) 
{
  predicted_response <- factor(ifelse(predictions_logit >= cutoff, "1", "0"))
  conf <- confusionMatrix(predicted_response, Demo_test$Performance.Tag.Demo, positive = "1")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  out <- t(as.matrix(c(sens, spec, acc))) 
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  return(out)
}

# Creating cutoff values from 0.01 to 0.99 for plotting and initiallizing a matrix of 1000 X 4.

s = seq(.01,.99,length=100)

OUT = matrix(0,100,3)


for(i in 1:100)
{
  OUT[i,] = perform_fn(s[i])
} 

# plotting cutoffs 
plot(s, OUT[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)
axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
lines(s,OUT[,2],col="darkgreen",lwd=2)
lines(s,OUT[,3],col=4,lwd=2)

box()
legend(0,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))


cutoff <- s[which(abs(OUT[,1]-OUT[,2])<0.4)]
cutoff # 0.39

# predicted response on TEST data

predicted_response <- factor(ifelse(predictions_logit >= 0.042, "1", "0"))

confusionMatrix(predicted_response, Demo_test$Performance.Tag.Demo, positive = "1")
# 
# Confusion Matrix and Statistics
# 
# Reference
# Prediction     0     1
# 0 10833   401
# 1  9192   482
# 
# Accuracy : 0.5412         
# 95% CI : (0.5344, 0.548)
# No Information Rate : 0.9578         
# P-Value [Acc > NIR] : 1              
# 
# Kappa : 0.0151         
# Mcnemar's Test P-Value : <2e-16         
# 
# Sensitivity : 0.54587        
# Specificity : 0.54097        
# Pos Pred Value : 0.04982        
# Neg Pred Value : 0.96430        
# Prevalence : 0.04223        
# Detection Rate : 0.02305        
# Detection Prevalence : 0.46269        
# Balanced Accuracy : 0.54342        
# 
# 'Positive' Class : 1       


# ================ RF modeling on demographic data ====================
# As seen erlier we have the best model by tuning sampsize hyper parameter.
# We will try the same model.

# change the response variable to factor
Demo_train_RF<-Demo_train
Demo_test_RF<-Demo_test

Demo_train_RF$Performance.Tag.Demo <- as.factor(Demo_train_RF$Performance.Tag.Demo)
Demo_test_RF$Performance.Tag.Demo <- as.factor(Demo_test_RF$Performance.Tag.Demo)

RFmodel_DemoG<-randomForest(Performance.Tag.Demo ~ ., data = Demo_train_RF, do.trace=10, sampsize=c('0'=100, '1'=100), strata = as.factor(Demo_train_RF$Performance.Tag.Demo))

RFmodel_DemoG_predict <- predict(RFmodel_DemoG, Demo_test_RF[,-11])
confusionMatrix(RFmodel_DemoG_predict, Demo_test_RF[,11], positive = '1')
# 
# Confusion Matrix and Statistics
# 
# Reference
# Prediction     0     1
# 0 12296   397
# 1  7729   486
# 
# Accuracy : 0.6113         
# 95% CI : (0.6047, 0.618)
# No Information Rate : 0.9578         
# P-Value [Acc > NIR] : 1              
# 
# Kappa : 0.0331         
# Mcnemar's Test P-Value : <2e-16         
# 
# Sensitivity : 0.55040        
# Specificity : 0.61403        
# Pos Pred Value : 0.05916        
# Neg Pred Value : 0.96872        
# Prevalence : 0.04223        
# Detection Rate : 0.02324        
# Detection Prevalence : 0.39291        
# Balanced Accuracy : 0.58221        
# 
# 'Positive' Class : 1             

auc(Demo_test_RF[,11], as.numeric(RFmodel_DemoG_predict))
# Area under the curve: 0.5822

plot.roc(roc(Demo_test_RF[,11], as.numeric(RFmodel_DemoG_predict)))

varImpPlot(RFmodel_DemoG)

# ===================================================================================


###### VALIDATION OF RANDOM FOREST ON THE NA DATA SET ##

RFmodel_predict <- predict(RFmodel_hyper, MasterData__na[,-5])

MasterData__na$randomForestPredict <- RFmodel_predict

#summary(MasterData__na$randomForestPredict)
#0    1 
#6 1419 

# Random forest predict with 99.57 in rejected data set 


#############  SELECTION BETWEEN THE RANDOM FOREST AND LOGISTIC MODEL #####################
 
# Logictic model
#AUC : 0.6643

# Random Forest
# Area under the curve: 0.6287

#The sensitivity /Specificity / accuracy almost same of the logicitc and random forest model
# As per rule of accuracy /stability / Discrimination power / generalizibility 
## We find LOGISTIC" as a better model since 
# it has better AUC, determines the robustness and good ness of fit 
# and  random forest has high chances of over fitting ,
# and we also got the important factors /predicitng factors in logistic


#####################################################################


###### SCORE CARD VALIDATION AND CUT OFF 

## Scorecard:

#How to calibrate log(odds) to scores?
#Score = Offset + ( Factor * log(odds) )
#Factor=PDO/ln(2)
#Offset=Base Score-(Factor*log(odds))

#In our case, PDO = 20, Base Score=400 & odds = 10
#Factor=20/ln(2)=28.8539
#Offset=400 -(28.8539*log(10))

#Final Formula:
#  Score = 333.5614 + 28.8539*log(odds)
#Where log(odds) = log(odds(good)) = log(probability(0)/probability(1))


test$defaultPrediction <- predictions_logit_2
test$non_default_predict <- 1-predictions_logit_2

test$oddsForGood <- test$non_default_predict/ test$defaultPrediction

test$LogoddsForGood <- log(test$oddsForGood, base = exp(1))


test$score <- 333.5614 + 28.8539*(test$LogoddsForGood)

### After getting the cut off  in the logistic 0.0455 we map the the score card and
##  evaluate it , we found it to be 421.4 
testBad <- subset (test, score < 421.4)
testgood <- subset (test, score >= 421.4)

### 
summary(testBad$Performance.Tag.Demo)
#0     1 
#7819  545 
# summary(test$Performance.Tag.Demo)
#0       1 
#20081   871 

## We found that as  per score 62 % percnet has been identified as defaulters
#i.e.  545 / 871  ~ 62 %


####################### SCORE CARD ANALYSIS ON REJECTED DATA SET ###########

MasterData__na$defaultPrediction <- predictions_logit_na
MasterData__na$non_default_predict <- 1-predictions_logit_na

MasterData__na$oddsForGood <- MasterData__na$non_default_predict/ MasterData__na$defaultPrediction

MasterData__na$LogoddsForGood <- log(MasterData__na$oddsForGood, base = exp(1))


MasterData__na$score <- 333.5614 + 28.8539*(MasterData__na$LogoddsForGood)


# Number of score less than 421.4

lessScoreRejectedData <- subset(MasterData__na,score <= 421.4)

nrow(lessScoreRejectedData) # 1415 hence out of 1425 shows as bad customer hecne
# the modle is validated 

############################  SCORE CARD VALIDATED  ENDS##################



###################   MODELIING ON DEMOGRAPHIC DATA SET ##########


# MODELING USING DEMOGRAPHIC DATASET

# Create the WOE dataset for Demographic dataset
str(DemoGData)
str(MasterData_woe)

DemoGData_WOE<-MasterData_woe[,1:12]
str(DemoGData_WOE)

# remove ApplicationId from the dataset
DemoGData_WOE_final<-DemoGData_WOE[,-1]
#DemoGData_WOE_final[]<-sapply(DemoGData_WOE_final, function(x) as.numeric(x))
#Gender
DemoGData_WOE_final$Gender <- as.numeric(DemoGData_WOE_final$Gender)
# Age
DemoGData_WOE_final$Age <- as.numeric(as.character(DemoGData_WOE_final$Age))
# Marital.Status..at.the.time.of.application.
DemoGData_WOE_final$Marital.Status..at.the.time.of.application. <- as.numeric(DemoGData_WOE_final$Marital.Status..at.the.time.of.application.)
# Income 
DemoGData_WOE_final$Income <- as.numeric(as.character(DemoGData_WOE_final$Income))
# Age
DemoGData_WOE_final$Age <- as.numeric(as.character(DemoGData_WOE_final$Age))
# Education
DemoGData_WOE_final$Education <- as.numeric(DemoGData_WOE_final$Education)
# Profession
DemoGData_WOE_final$Profession <- as.numeric(DemoGData_WOE_final$Profession)
# Type.of.residence
DemoGData_WOE_final$Type.of.residence <- as.numeric(DemoGData_WOE_final$Type.of.residence)
# No.of.months.in.current.residence

DemoGData_WOE_final$No.of.months.in.current.residence <- as.numeric(as.character(DemoGData_WOE_final$No.of.months.in.current.residence))
# No.of.months.in.current.company
DemoGData_WOE_final$No.of.months.in.current.company <- as.numeric(as.character(DemoGData_WOE_final$No.of.months.in.current.company))

DemoGData_WOE_final$Performance.Tag.Demo <- as.factor(DemoGData_WOE_final$Performance.Tag.Demo)
sum(is.na(DemoGData_WOE_final))

#remove NAs
DemoGData_WOE_final<-DemoGData_WOE_final[-which(is.na(DemoGData_WOE_final$Education)),]
DemoGData_WOE_final<-DemoGData_WOE_final[-which(is.na(DemoGData_WOE_final$Profession)),]
DemoGData_WOE_final<-DemoGData_WOE_final[-which(is.na(DemoGData_WOE_final$Type.of.residence)),]
DemoGData_WOE_final<-DemoGData_WOE_final[-which(is.na(DemoGData_WOE_final$Marital.Status..at.the.time.of.application.)),]
DemoGData_WOE_final<-DemoGData_WOE_final[-which(is.na(DemoGData_WOE_final$Gender)),]

# Split the data into train and test data set
set.seed(101)
DemoSplit_data<-sample.split(DemoGData_WOE_final$Performance.Tag.Demo, SplitRatio = 0.7)
table(DemoSplit_data)
Demo_train<-DemoGData_WOE_final[DemoSplit_data,]
Demo_test<-DemoGData_WOE_final[!(DemoSplit_data),]

# Logistic Regression
Demologistic_1<-glm(Performance.Tag.Demo ~ ., family = "binomial", data=Demo_train )

summary(Demologistic_1)

library(MASS)
library(car)

# Using stepwise algorithm for removing insignificant variables 
stepAIC(Demologistic_1, direction = "both")

Demologistic_2<-glm(formula = Performance.Tag.Demo ~ No.of.dependents + Income + 
                      Profession + No.of.months.in.current.residence + No.of.months.in.current.company, 
                    family = "binomial", data = Demo_train)

# checking vif for logistic_2 
vif(Demologistic_2)

summary(Demologistic_2)

Demologistic_3<-glm(formula = Performance.Tag.Demo ~ No.of.dependents + Income + 
                      No.of.months.in.current.residence + No.of.months.in.current.company, 
                    family = "binomial", data = Demo_train)

# checking vif for Demologistic_3 
vif(Demologistic_3)

summary(Demologistic_3)

# Check for multi-corlinearity. 
cor(Demo_train$No.of.dependents, Demo_train$No.of.months.in.current.residence)

predictions_logit <- predict(Demologistic_3, newdata = Demo_test, type = "response")
summary(predictions_logit)

# Let's find out the optimal probalility cutoff 
perform_fn <- function(cutoff) 
{
  predicted_response <- factor(ifelse(predictions_logit >= cutoff, "1", "0"))
  conf <- confusionMatrix(predicted_response, Demo_test$Performance.Tag.Demo, positive = "1")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  out <- t(as.matrix(c(sens, spec, acc))) 
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  return(out)
}

# Creating cutoff values from 0.01 to 0.99 for plotting and initiallizing a matrix of 1000 X 4.

s = seq(.01,.99,length=100)

OUT = matrix(0,100,3)


for(i in 1:100)
{
  OUT[i,] = perform_fn(s[i])
} 

# plotting cutoffs 
plot(s, OUT[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)
axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
lines(s,OUT[,2],col="darkgreen",lwd=2)
lines(s,OUT[,3],col=4,lwd=2)

box()
legend(0,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))


cutoff_demo <- s[which(abs(OUT[,1]-OUT[,2])<0.3)]
cutoff_demo # 0.39

# predicted response on TEST data

predicted_response <- factor(ifelse(predictions_logit >= 0.042, "1", "0"))

confusionMatrix(predicted_response, Demo_test$Performance.Tag.Demo, positive = "1")
# 
#Confusion Matrix and Statistics

##Reference
#Prediction     0     1
#             0 11648   354
#             1  8377   529

#Accuracy : 0.582              
#95% CI : (0.576, 0.589)     
#No Information Rate : 0.958              
#P-Value [Acc > NIR] : 1                  

#Kappa : 0.034              
#Mcnemar's Test P-Value : <0.0000000000000002

#Sensitivity : 0.5991             
#Specificity : 0.5817             
#Pos Pred Value : 0.0594             
#Neg Pred Value : 0.9705             
#Prevalence : 0.0422             
#Detection Rate : 0.0253             
#Detection Prevalence : 0.4260             
#Balanced Accuracy : 0.5904             

#'Positive' Class : 1                  

     


# ================ RF modeling on demographic data ====================
# As seen erlier we have the best model by tuning sampsize hyper parameter.
# We will try the same model.

# change the response variable to factor
Demo_train_RF<-Demo_train
Demo_test_RF<-Demo_test

Demo_train_RF$Performance.Tag.Demo <- as.factor(Demo_train_RF$Performance.Tag.Demo)
Demo_test_RF$Performance.Tag.Demo <- as.factor(Demo_test_RF$Performance.Tag.Demo)

RFmodel_DemoG<-randomForest(Performance.Tag.Demo ~ ., data = Demo_train_RF, do.trace=10, sampsize=c('0'=100, '1'=100), strata = as.factor(Demo_train_RF$Performance.Tag.Demo))

RFmodel_DemoG_predict <- predict(RFmodel_DemoG, Demo_test_RF[,-11])
confusionMatrix(RFmodel_DemoG_predict, Demo_test_RF[,11], positive = '1')
# 
# Confusion Matrix and Statistics
# 
# Reference
# Prediction     0     1
# 0 12296   397
# 1  7729   486
# 
# Accuracy : 0.6113         
# 95% CI : (0.6047, 0.618)
# No Information Rate : 0.9578         
# P-Value [Acc > NIR] : 1              
# 
# Kappa : 0.0331         
# Mcnemar's Test P-Value : <2e-16         
# 
# Sensitivity : 0.55040        
# Specificity : 0.61403        
# Pos Pred Value : 0.05916        
# Neg Pred Value : 0.96872        
# Prevalence : 0.04223        
# Detection Rate : 0.02324        
# Detection Prevalence : 0.39291        
# Balanced Accuracy : 0.58221        
# 
# 'Positive' Class : 1             

auc(Demo_test_RF[,11], as.numeric(RFmodel_DemoG_predict))
# Area under the curve: 0.5822

plot.roc(roc(Demo_test_RF[,11], as.numeric(RFmodel_DemoG_predict)))

varImpPlot(RFmodel_DemoG)


##########################################  CAPSTONE   R CODE ENDS ##################


########## REMOVING VARIABLES :
rm(list = ls())