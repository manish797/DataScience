######################### UBER CASE STUDY  #########################\
rm(list=ls())
# setting working directory
setwd("D:/PGDDA/R DOWNLOAD/ASSIGNMENTS/UBER_CASE_STUDY")
## loading data frame

uberData <- read.csv("Uber request data.csv", stringsAsFactors = FALSE)

naValueCount <- length(which(is.na(master_frame$raised_amount_usd))) 

uberdriverNA <- length(which(is.na(uberData$Driver.id))) 



uberData$Hour<-as.numeric(levels(uberData$Hour))[uberData$Hour]
# using ggplot

library(ggplot2)
library(lubridate)


# Plot 1
HourTime<- function(element){
  
  hrlist<- unlist (strsplit(element,split = ":" ,fixed = TRUE))[1]
  return(hrlist)
  
}
#SectorGBRFunding <- aggregate(raised_amount_usd~main_sector+country_code,GBR_countries_subset,length)
# Primary Sector list 
TrimmedHour <- as.character( lapply (uberData$Request.time ,HourTime))
uberData <- data.frame(uberData,Hour =c(as.character(TrimmedHour)))
sort(uberData$Hour, na.last = NA, decreasing = FALSE)
uber_request <- ggplot(uberData,aes(x=factor(Hour),fill = factor(Pickup.point)))

uber_request +geom_bar(width = 1,position = "dodge")


#Plot 2

uberData <- data.frame(uberData,Time_Slot =c(as.character("")))
uberData$Hour<- as.character(uberData$Hour)
uberData$Hour<- as.numeric(uberData$Hour)
uberData$Time_Slot <-as.character(uberData$Time_Slot)

uberData$Time_Slot[which(uberData$Hour >=2 & uberData$Hour < 4)] <- "Pre_Morning"
uberData$Time_Slot[which(uberData$Hour >=4 & uberData$Hour < 10)] <- "Morning_Rush"
uberData$Time_Slot[which(uberData$Hour >=10 & uberData$Hour < 17)] <- "Day_Time"
uberData$Time_Slot[which(uberData$Hour >=17 & uberData$Hour < 22)] <- "Evening_Rush"
uberData$Time_Slot[which(uberData$Hour >=22 | uberData$Hour < 2)] <- "Late_Night"


## Faulty if else loop
NewColumnCategory<- function(element){
  
  timeslot <-   as.integer(element)
  if( timeslot >=2 & timeslot < 4)
     newCategory ="Pre_Morning"
  else if (timeslot >=4 & timeslot < 10)
    newCategory ="Morning_Rush"
  else if (timeslot >=10 & timeslot < 17)
    newCategory ="Day_Time"
  else if (timeslot >=17 & timeslot < 22)
    newCategory ="Evening_Rush"
  else
    newCategory ="Late_Night"
  return(newCategory)
  
}

#category_list <- lapply (uberData$Hour ,NewColumnCategory)
#uberData <- data.frame(uberData,Time_Slot =c(as.character(category_list)))
tripMade <- aggregate(Request.id~Status+Time_Slot,uberData,length)

#Plot for trip completed
uber_identify <- ggplot(tripMade[tripMade$Status=="Trip Completed",],aes(x=factor(Time_Slot),y=Request.id))
uber_identify + geom_bar(stat="identity") +geom_text(aes(label=Request.id),vjust=-0.5)



#Plot for all Time_Slots
uber_TimeSlots <- ggplot(tripMade,aes(x=factor(Time_Slot),y=Request.id,fill=factor(Status)))
uber_TimeSlots + geom_bar(stat="identity") 



# Problem 1: Morning rush trip cancelled

library(scales)

pickUpPlot <- ggplot(uberData[uberData$Time_Slot=="Morning_Rush" & uberData$Status=="Cancelled",] ,aes(x=factor(Status),fill=factor(Pickup.point) ,y=(..count../sum(..count..))))

pickUpPlot+ geom_bar() + geom_text(aes(label = scales::percent((..count..)/sum(..count..))), stat = "count",vjust=0.9)+  scale_y_continuous(labels=percent)


#Plot 2

morningRush_PickupCity <-  subset (uberData,Time_Slot == "Morning_Rush" & Pickup.point =="City")

EveningRush_PickupAirport <-  subset (uberData,Time_Slot == "Evening_Rush" & Pickup.point =="Airport")

requestNumbers <- aggregate(Request.id~Request.time+Status,morningRush_PickupCity,length)

requestNumbers_onlyTimeslot_Eve <- aggregate(Request.id~Status,EveningRush_PickupAirport,length)
requestNumbers_onlyTimeslot <- aggregate(Request.id~Status,morningRush_PickupCity,length)  

ggplot( requestNumbers, aes( x=Request.time ,y=Request.id,fill =factor(Status))) +geom_bar(stat="identity",position="dodge" )



# Analysis for reason of suppli demand gap

completedTrip <- subset(uberData,Status=="Trip Completed")

returningdriver <- completedTrip[which(duplicated(completedTrip$Driver.id)),]

gg<- as.POSIXct(returningdriver$Dropoff.time, format='%I:%M %p')


returningdriver$Hour<- as.integer(returningdriver$Hour)


returningdriver$Dropoff.time<- substr(strptime(returningdriver$Dropoff.time, "%I:%M:%S %p" ),12,19)

library(scales)

pickUpPlot_Eve <- ggplot(uberData[uberData$Time_Slot=="Evening_Rush" & uberData$Status=="No Cars Available",] ,aes(x=factor(Status),fill=factor(Pickup.point) ,y=(..count../sum(..count..))))

pickUpPlot_Eve+ geom_bar() + geom_text(aes(label = scales::percent((..count..)/sum(..count..))), stat = "count",vjust=1,position = position_stack())+  scale_y_continuous(labels=percent)



